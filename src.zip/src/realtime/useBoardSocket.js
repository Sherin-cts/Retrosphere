import { useEffect, useRef, useState } from 'react';
import { Client } from '@stomp/stompjs';
import SockJS from 'sockjs-client';
import { tokenStore } from '../api/tokenStore';

/**
 * Opens a STOMP-over-SockJS connection to /ws, authenticates with the JWT in the CONNECT
 * frame, and subscribes to /topic/board/{boardId}. Calls onEvent(event) for each BoardEvent.
 * Returns helpers to publish reaction / hand-raise messages.
 */
export function useBoardSocket(boardId, onEvent) {
  const clientRef = useRef(null);
  const onEventRef = useRef(onEvent);
  const [connected, setConnected] = useState(false);

  // Always call the latest handler without re-subscribing.
  useEffect(() => {
    onEventRef.current = onEvent;
  }, [onEvent]);

  useEffect(() => {
    if (!boardId) return undefined;
    const token = tokenStore.getAccess();

    const client = new Client({
      webSocketFactory: () => new SockJS('/ws'),
      connectHeaders: { Authorization: `Bearer ${token}` },
      reconnectDelay: 4000,
      onConnect: () => {
        setConnected(true);
        client.subscribe(`/topic/board/${boardId}`, (message) => {
          try {
            const event = JSON.parse(message.body);
            onEventRef.current?.(event);
          } catch {
            /* ignore malformed frames */
          }
        });
      },
      onDisconnect: () => setConnected(false),
      onWebSocketClose: () => setConnected(false),
    });

    client.activate();
    clientRef.current = client;

    return () => {
      client.deactivate();
      clientRef.current = null;
      setConnected(false);
    };
  }, [boardId]);

  const publish = (suffix, body) => {
    const client = clientRef.current;
    if (client?.connected) {
      client.publish({ destination: `/app/board/${boardId}/${suffix}`, body: JSON.stringify(body) });
    }
  };

  return {
    connected,
    sendReaction: (emoji, cardId) => publish('reaction', { emoji, cardId: cardId ?? null }),
    sendHand: (raised) => publish('hand', { raised }),
  };
}
