import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom';
import { LayoutGrid, ListChecks, LogOut, Moon, Sun, Building2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { Avatar } from './ui';

function Brand() {
  return (
    <Link to="/" className="flex items-center gap-2">
      <span className="flex h-8 w-8 items-center justify-center rounded-md font-extrabold text-white shadow-md"
        style={{ background: 'linear-gradient(135deg,#2B8FE8,#9B27AF)' }}>
        T
      </span>
      <span className="text-lg font-extrabold tracking-tight text-white drop-shadow-sm">Retrosphere</span>
    </Link>
  );
}

function navClass({ isActive }) {
  return `flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all duration-150 ${
    isActive
      ? 'text-white font-semibold shadow-lg'
      : 'text-white/60 hover:bg-white/10 hover:text-white'
  }`;
}

// Active nav item gets a vivid gradient bg — passed as inline style via a wrapper trick.
// We use a data attribute approach instead.
function NavItem({ to, children }) {
  return (
    <NavLink to={to}
      className={({ isActive }) =>
        `flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all duration-150 ${
          isActive
            ? 'text-white font-semibold shadow-md'
            : 'text-white/60 hover:bg-white/10 hover:text-white'
        }`
      }
      style={({ isActive }) => isActive
        ? { background: 'linear-gradient(90deg, rgba(43,143,232,0.45) 0%, rgba(155,39,175,0.35) 100%)', boxShadow: '0 0 12px rgba(43,143,232,0.25)' }
        : {}
      }
    >
      {children}
    </NavLink>
  );
}

export default function Layout() {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const navigate = useNavigate();

  const onLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside
        className="relative hidden w-60 flex-col overflow-hidden p-4 md:flex"
        style={theme === 'dark'
          /* Dark: deep charcoal-purple, clearly darker than navy-900 main bg */
          ? {
              background: 'linear-gradient(180deg, #12082a 0%, #1a0e3a 50%, #0e1528 100%)',
              borderRight: '1px solid rgba(155,39,175,0.35)',
            }
          /* Light: vivid blue-to-purple */
          : {
              background: 'linear-gradient(160deg, #1d3353 0%, #2B8FE8 55%, #9B27AF 100%)',
            }
        }
      >
        {/* ── LIGHT MODE: pink + green orbs ── */}
        {theme !== 'dark' && <>
          <div className="pointer-events-none absolute left-0 top-0 h-48 w-full opacity-25"
            style={{ background: 'radial-gradient(circle at 25% 15%, #F25C6E 0%, transparent 55%)' }} />
          <div className="pointer-events-none absolute bottom-0 left-0 h-36 w-full opacity-20"
            style={{ background: 'radial-gradient(circle at 75% 85%, #22C55E 0%, transparent 55%)' }} />
        </>}

        {/* ── DARK MODE: rainbow left strip + vivid color blobs ── */}
        {theme === 'dark' && <>
          {/* Rainbow left edge */}
          <div className="pointer-events-none absolute left-0 top-0 h-full w-[3px]"
            style={{ background: 'linear-gradient(180deg,#2B8FE8 0%,#9B27AF 35%,#F25C6E 65%,#F5A020 100%)' }} />
          {/* Blue glow top-right */}
          <div className="pointer-events-none absolute -right-8 -top-8 h-40 w-40 rounded-full opacity-20"
            style={{ background: 'radial-gradient(circle, #2B8FE8 0%, transparent 70%)' }} />
          {/* Purple glow bottom-left */}
          <div className="pointer-events-none absolute -bottom-6 -left-4 h-36 w-36 rounded-full opacity-25"
            style={{ background: 'radial-gradient(circle, #9B27AF 0%, transparent 70%)' }} />
          {/* Pink accent mid-right */}
          <div className="pointer-events-none absolute right-0 top-1/2 h-24 w-24 -translate-y-1/2 opacity-10"
            style={{ background: 'radial-gradient(circle, #F25C6E 0%, transparent 70%)' }} />
        </>}

        {/* Brand */}
        <div className="relative mb-8 px-1">
          <Brand />
        </div>

        {/* Nav links */}
        <nav className="relative flex flex-1 flex-col gap-1.5">
          <NavItem to="/workspaces">
            <Building2 className="h-4 w-4" /> Workspaces
          </NavItem>
          <NavItem to="/action-items">
            <ListChecks className="h-4 w-4" /> My Action Items
          </NavItem>
        </nav>

        {/* User footer */}
        <div className="relative mt-auto flex items-center gap-2 pt-4"
          style={{ borderTop: '1px solid rgba(255,255,255,0.12)' }}>
          <Avatar name={user?.displayName} />
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold text-white">{user?.displayName}</p>
            <p className="truncate text-xs text-white/40">{user?.email}</p>
          </div>
        </div>
      </aside>

      {/* Main */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between border-b border-navy-200 bg-white px-4 py-3 dark:border-navy-800 dark:bg-navy-900 md:px-6">
          <div className="md:hidden">
            <Link to="/" className="flex items-center gap-2">
              <span className="flex h-7 w-7 items-center justify-center rounded bg-accent-600 text-sm font-extrabold text-white">T</span>
              <span className="font-extrabold text-navy-900 dark:text-white">Retrosphere</span>
            </Link>
          </div>
          <div className="hidden md:flex md:items-center md:gap-2 md:text-sm md:text-navy-400">
            <LayoutGrid className="h-4 w-4" /> Collaborative Agile Retrospectives
          </div>
          <div className="flex items-center gap-2">
            <button onClick={toggleTheme} className="btn-ghost p-2" title="Toggle theme">
              {theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>
            <button onClick={onLogout} className="btn-secondary">
              <LogOut className="h-4 w-4" /> <span className="hidden sm:inline">Sign out</span>
            </button>
          </div>
        </header>

        <main className="flex-1 overflow-x-hidden p-4 md:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
