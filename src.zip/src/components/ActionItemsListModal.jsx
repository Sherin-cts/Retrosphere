import { useEffect, useState } from 'react';
import { Calendar, Trash2, ListChecks } from 'lucide-react';
import { actionItemApi } from '../api/endpoints';
import { errorMessage } from '../api/client';
import { Modal, Spinner, ErrorBanner, Avatar, EmptyState } from './ui';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

const STATUSES = ['OPEN', 'IN_PROGRESS', 'DONE', 'CANCELLED'];
const PRIORITY_STYLE = {
  HIGH: 'bg-red-100 text-red-700 dark:bg-red-950/50 dark:text-red-300',
  MED: 'bg-amber-100 text-amber-700 dark:bg-amber-950/50 dark:text-amber-300',
  LOW: 'bg-navy-100 text-navy-600 dark:bg-navy-700 dark:text-navy-200',
};
const STATUS_STYLE = {
  OPEN: 'bg-navy-100 text-navy-700 dark:bg-navy-700 dark:text-navy-100',
  IN_PROGRESS: 'bg-accent-100 text-accent-800 dark:bg-accent-900/40 dark:text-accent-200',
  DONE: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300',
  CANCELLED: 'bg-navy-100 text-navy-400 line-through dark:bg-navy-700',
};

/** Lists every action item belonging to one board/session (workspace -> board card). */
export default function ActionItemsListModal({ boardId, boardName, isFacilitator, onClose }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [items, setItems] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    actionItemApi.dashboard({ boardId }).then(setItems).catch((e) => setError(errorMessage(e)));
  }, [boardId]);

  const updateStatus = async (id, status) => {
    try {
      const updated = await actionItemApi.update(id, { status });
      setItems((arr) => arr.map((i) => (i.id === id ? updated : i)));
    } catch (e) { toast(errorMessage(e), 'error'); }
  };

  const remove = async (id) => {
    if (!confirm('Delete this action item?')) return;
    try {
      await actionItemApi.remove(id);
      setItems((arr) => arr.filter((i) => i.id !== id));
      toast('Action item deleted');
    } catch (e) { toast(errorMessage(e), 'error'); }
  };

  return (
    <Modal open onClose={onClose} title={`Action items · ${boardName}`} width="max-w-2xl">
      <ErrorBanner message={error} />
      {items === null ? (
        <div className="flex justify-center py-8"><Spinner className="h-6 w-6" /></div>
      ) : items.length === 0 ? (
        <EmptyState icon={ListChecks} title="No action items" message="This session has no action items yet." />
      ) : (
        <div className="space-y-2">
          {items.map((it) => (
            <div key={it.id} className="card flex items-start gap-3 border border-navy-100 p-3 dark:border-navy-700">
              <span className={`badge ${PRIORITY_STYLE[it.priority]}`}>{it.priority}</span>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-navy-900 dark:text-white">{it.title}</p>
                <div className="mt-1 flex flex-wrap items-center gap-3 text-xs text-navy-500">
                  {it.dueDate && <span className="flex items-center gap-1"><Calendar className="h-3 w-3" /> {it.dueDate}</span>}
                  <div className="flex items-center gap-1">
                    {it.assignees.map((a) => <span key={a.userId} title={a.displayName}><Avatar name={a.displayName} size="h-5 w-5" /></span>)}
                    {it.assignees.length === 0 && <span className="text-navy-400">Unassigned</span>}
                  </div>
                </div>
              </div>
              <select className={`rounded-md border-0 px-2 py-1 text-xs font-semibold ${STATUS_STYLE[it.status]}`}
                value={it.status} onChange={(e) => updateStatus(it.id, e.target.value)}>
                {STATUSES.map((s) => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
              </select>
              {(isFacilitator || it.createdByUserId === user?.id) && (
                <button onClick={() => remove(it.id)} title="Delete"
                  className="rounded p-1 text-navy-400 hover:bg-red-50 hover:text-red-600 dark:hover:bg-navy-700">
                  <Trash2 className="h-4 w-4" />
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </Modal>
  );
}
