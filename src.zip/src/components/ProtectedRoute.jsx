import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { tokenStore } from '../api/tokenStore';

export default function ProtectedRoute({ children }) {
  const { user } = useAuth();
  const location = useLocation();
  // Authenticated if we have both a user and a token.
  if (!user || !tokenStore.getAccess()) {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }
  return children;
}
