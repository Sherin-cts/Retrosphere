import { useState } from 'react';
import {
  ThumbsUp, ThumbsDown, MessageSquare, Pencil, Trash2, CheckSquare, X, Check,
} from 'lucide-react';
import { cardApi, voteApi } from '../../api/endpoints';
import { errorMessage } from '../../api/client';
import { Avatar } from '../ui';
import CommentsPanel from './CommentsPanel';
import ActionItemModal from './ActionItemModal';

export default function RetroCard({ card, board, user, isFacilitator, hasActionItem,
  patchCard, removeCard, setError, onActionItemCreated, accentColor }) {
  const [editing, setEditing] = useState(false);
  const [text, setText] = useState(card.text);
  const [showComments, setShowComments] = useState(false);
  const [actionOpen, setActionOpen] = useState(false);

  const canEdit = isFacilitator || card.authorUserId === user?.id;
  const votesHidden = card.upvotes === null || card.upvotes === undefined;
  const allowDownvote = board.allowDownvote;
  const commentCount = card.commentCount || 0;

  const vote = async (direction) => {
    try {
      const res = await voteApi.cast(card.id, direction);
      patchCard(card.id, { myVote: res.myVote, upvotes: res.upvotes, downvotes: res.downvotes });
    } catch (err) { setError(errorMessage(err)); }
  };

  const withdraw = async () => {
    try {
      const res = await voteApi.withdraw(card.id);
      patchCard(card.id, { myVote: null, upvotes: res.upvotes, downvotes: res.downvotes });
    } catch (err) { setError(errorMessage(err)); }
  };

  const onVoteClick = (direction) => {
    if (card.myVote === direction) withdraw();
    else vote(direction);
  };

  const saveEdit = async () => {
    if (!text.trim()) return;
    try {
      const updated = await cardApi.update(card.id, { text: text.trim() });
      patchCard(card.id, updated);
      setEditing(false);
    } catch (err) { setError(errorMessage(err)); }
  };

  const del = async () => {
    if (!confirm('Delete this card?')) return;
    try { await cardApi.remove(card.id); removeCard(card.id); }
    catch (err) { setError(errorMessage(err)); }
  };

  return (
    <div className="card border border-navy-100 p-3 dark:border-navy-700 retro-card-accent"
      style={{ '--card-accent': accentColor || '#2B8FE8' }}>
      {hasActionItem && (
        <span className="mb-2 inline-flex items-center gap-1 rounded-full bg-accent-50 px-2 py-0.5 text-[11px] font-semibold text-accent-700 dark:bg-accent-900/40 dark:text-accent-200">
          <CheckSquare className="h-3 w-3" /> Action item
        </span>
      )}
      {editing ? (
        <div className="space-y-2">
          <textarea className="input min-h-[60px] resize-none" value={text} onChange={(e) => setText(e.target.value)} autoFocus />
          <div className="flex justify-end gap-1">
            <button className="btn-ghost px-2 py-1" onClick={() => { setEditing(false); setText(card.text); }}><X className="h-4 w-4" /></button>
            <button className="btn-primary px-2 py-1" onClick={saveEdit}><Check className="h-4 w-4" /></button>
          </div>
        </div>
      ) : (
        <p className="whitespace-pre-wrap break-words text-sm text-navy-800 dark:text-navy-100">{card.text}</p>
      )}

      <div className="mt-2 flex items-center gap-2 text-navy-400">
        <Avatar name={card.authorName} size="h-5 w-5" />
        <span className="truncate text-xs">{card.authorName}</span>
      </div>

      <div className="mt-2 flex items-center justify-between border-t border-navy-100 pt-2 dark:border-navy-700">
        <div className="flex items-center gap-1">
          <button onClick={() => onVoteClick('up')}
            className={`flex items-center gap-1 rounded px-2 py-1 text-xs font-semibold ${card.myVote === 'up' ? 'bg-emerald-100 text-emerald-700' : 'text-navy-500 hover:bg-navy-100 dark:hover:bg-navy-700'}`}>
            <ThumbsUp className="h-3.5 w-3.5" /> {votesHidden ? '·' : card.upvotes}
          </button>
          {allowDownvote && (
            <button onClick={() => onVoteClick('down')}
              className={`flex items-center gap-1 rounded px-2 py-1 text-xs font-semibold ${card.myVote === 'down' ? 'bg-rose-100 text-rose-700' : 'text-navy-500 hover:bg-navy-100 dark:hover:bg-navy-700'}`}>
              <ThumbsDown className="h-3.5 w-3.5" /> {votesHidden ? '·' : card.downvotes}
            </button>
          )}
          <button onClick={() => setShowComments((s) => !s)}
            className={`flex items-center gap-1 rounded px-2 py-1 text-xs font-semibold hover:bg-navy-100 dark:hover:bg-navy-700 ${commentCount > 0 ? 'text-accent-600' : 'text-navy-500'}`}
            title={`${commentCount} comment(s)`}>
            <MessageSquare className="h-3.5 w-3.5" /> {commentCount > 0 ? commentCount : ''}
          </button>
        </div>
        <div className="flex items-center gap-0.5">
          {isFacilitator && (
            <button onClick={() => setActionOpen(true)} className="rounded p-1 text-navy-400 hover:bg-navy-100 hover:text-accent-600 dark:hover:bg-navy-700" title="Create action item">
              <CheckSquare className="h-3.5 w-3.5" />
            </button>
          )}
          {canEdit && (
            <>
              <button onClick={() => setEditing(true)} className="rounded p-1 text-navy-400 hover:bg-navy-100 dark:hover:bg-navy-700" title="Edit"><Pencil className="h-3.5 w-3.5" /></button>
              <button onClick={del} className="rounded p-1 text-navy-400 hover:bg-navy-100 hover:text-red-600 dark:hover:bg-navy-700" title="Delete"><Trash2 className="h-3.5 w-3.5" /></button>
            </>
          )}
        </div>
      </div>

      {showComments && <CommentsPanel cardId={card.id} setError={setError} />}
      {actionOpen && (
        <ActionItemModal cardId={card.id} cardText={card.text} workspaceId={board.workspaceId}
          onClose={() => setActionOpen(false)} setError={setError} onCreated={onActionItemCreated} />
      )}
    </div>
  );
}
