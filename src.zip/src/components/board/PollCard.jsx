import { Eye, Lock, EyeOff } from 'lucide-react';

export const POLL_EMOJI = { 1: '😞', 2: '😕', 3: '😐', 4: '🙂', 5: '😄' };

const STATUS_STYLE = {
  OPEN: 'bg-accent-100 text-accent-800 dark:bg-accent-900/40 dark:text-accent-200',
  REVEALED: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300',
  CLOSED: 'bg-navy-100 text-navy-500 dark:bg-navy-700 dark:text-navy-300',
};

/**
 * One poll: emoji scale to respond (until closed), plus results.
 * The Facilitator sees results from the start; members only after reveal.
 */
export default function PollCard({ poll, isFacilitator, onRespond, onReveal, onClose, readOnly }) {
  const revealedToAll = poll.status === 'REVEALED' || poll.status === 'CLOSED';
  const showResults = (isFacilitator || revealedToAll) && poll.distribution != null;
  const canRespond = !readOnly && poll.status !== 'CLOSED';
  const maxBar = poll.distribution ? Math.max(1, ...poll.distribution) : 1;

  return (
    <div className="card border border-navy-100 p-4 dark:border-navy-700">
      <div className="mb-3 flex items-start justify-between gap-2">
        <h3 className="font-semibold text-navy-900 dark:text-white">{poll.title}</h3>
        <span className={`badge shrink-0 ${STATUS_STYLE[poll.status]}`}>{poll.status}</span>
      </div>

      {/* Respond (1-5 emoji scale) */}
      {canRespond && (
        <div className="mb-3 flex justify-between gap-1">
          {[1, 2, 3, 4, 5].map((n) => (
            <button key={n} onClick={() => onRespond(poll.id, n)}
              className={`flex flex-1 flex-col items-center rounded-lg border-2 py-2 transition ${
                poll.myScore === n
                  ? 'border-accent-500 bg-accent-50 dark:bg-navy-700'
                  : 'border-transparent hover:bg-navy-50 dark:hover:bg-navy-700'}`}>
              <span className="text-2xl">{POLL_EMOJI[n]}</span>
            </button>
          ))}
        </div>
      )}

      {/* Members: hidden until reveal */}
      {!showResults && !revealedToAll && (
        <div className="flex items-center gap-1 rounded-md bg-navy-50 px-3 py-2 text-sm text-navy-500 dark:bg-navy-700/50">
          <Lock className="h-4 w-4" /> {poll.myScore ? 'Response recorded' : 'Pick a score'} · hidden until reveal
        </div>
      )}

      {/* Results (Facilitator sees pre-reveal; everyone after reveal) */}
      {showResults && (
        <div className="space-y-3">
          {isFacilitator && !revealedToAll && (
            <p className="flex items-center gap-1 text-[11px] font-medium text-amber-600">
              <EyeOff className="h-3.5 w-3.5" /> Visible only to you until you reveal
            </p>
          )}
          <div className="flex items-end gap-2">
            <span className="text-3xl font-extrabold text-navy-900 dark:text-white">
              {poll.average != null ? poll.average.toFixed(1) : '—'}
            </span>
            <span className="pb-1 text-xs text-navy-400">avg · {poll.responseCount ?? 0} responses</span>
          </div>

          {/* Distribution bar chart */}
          <div className="space-y-1">
            {[5, 4, 3, 2, 1].map((n) => {
              const count = poll.distribution ? poll.distribution[n - 1] : 0;
              return (
                <div key={n} className="flex items-center gap-2">
                  <span className="w-5 text-center text-base">{POLL_EMOJI[n]}</span>
                  <div className="h-3 flex-1 overflow-hidden rounded-full bg-navy-100 dark:bg-navy-700">
                    <div className="h-full rounded-full bg-accent-500" style={{ width: `${(count / maxBar) * 100}%` }} />
                  </div>
                  <span className="w-5 text-right text-xs text-navy-500">{count}</span>
                </div>
              );
            })}
          </div>

          {/* Anonymous individual responses */}
          {poll.scores && poll.scores.length > 0 && (
            <div className="flex flex-wrap gap-1 border-t border-navy-100 pt-2 dark:border-navy-700">
              {poll.scores.map((s, i) => <span key={i} className="text-lg" title="Anonymous">{POLL_EMOJI[s]}</span>)}
            </div>
          )}
        </div>
      )}

      {/* Facilitator controls */}
      {!readOnly && isFacilitator && poll.status === 'OPEN' && (
        <button onClick={() => onReveal(poll.id)} className="btn-primary mt-3 w-full py-1.5 text-xs">
          <Eye className="h-3.5 w-3.5" /> Reveal to everyone
        </button>
      )}
      {!readOnly && isFacilitator && poll.status === 'REVEALED' && (
        <button onClick={() => onClose(poll.id)} className="btn-secondary mt-3 w-full py-1.5 text-xs">
          <Lock className="h-3.5 w-3.5" /> Close &amp; archive poll
        </button>
      )}
    </div>
  );
}
