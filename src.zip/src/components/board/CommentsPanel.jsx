import { useEffect, useState } from 'react';
import { Send, CornerDownRight } from 'lucide-react';
import { cardApi } from '../../api/endpoints';
import { errorMessage } from '../../api/client';
import { Avatar, Spinner } from '../ui';

export default function CommentsPanel({ cardId, setError }) {
  const [comments, setComments] = useState(null);
  const [text, setText] = useState('');
  const [replyTo, setReplyTo] = useState(null);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    try { setComments(await cardApi.comments(cardId)); }
    catch (err) { setError(errorMessage(err)); }
  };
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [cardId]);

  const submit = async (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    setBusy(true);
    try {
      await cardApi.addComment(cardId, { text: text.trim(), parentCommentId: replyTo });
      setText(''); setReplyTo(null);
      load();
    } catch (err) { setError(errorMessage(err)); }
    finally { setBusy(false); }
  };

  const topLevel = (comments || []).filter((c) => !c.parentCommentId);
  const repliesOf = (id) => (comments || []).filter((c) => c.parentCommentId === id);

  return (
    <div className="mt-2 border-t border-navy-100 pt-2 dark:border-navy-700">
      {comments === null ? (
        <div className="flex justify-center py-2"><Spinner className="h-4 w-4" /></div>
      ) : (
        <div className="space-y-2">
          {topLevel.length === 0 && <p className="text-xs text-navy-400">No comments yet.</p>}
          {topLevel.map((c) => (
            <div key={c.id}>
              <Comment c={c} onReply={() => setReplyTo(c.id)} />
              {repliesOf(c.id).map((r) => (
                <div key={r.id} className="ml-4 mt-1 flex gap-1">
                  <CornerDownRight className="mt-1 h-3 w-3 shrink-0 text-navy-300" />
                  <Comment c={r} />
                </div>
              ))}
            </div>
          ))}
        </div>
      )}

      <form onSubmit={submit} className="mt-2 flex items-center gap-1">
        <input className="input py-1 text-xs" value={text} onChange={(e) => setText(e.target.value)}
          placeholder={replyTo ? 'Write a reply…' : 'Add a comment…'} />
        <button type="submit" className="btn-primary px-2 py-1.5" disabled={busy}>
          {busy ? <Spinner className="h-3 w-3 text-white" /> : <Send className="h-3.5 w-3.5" />}
        </button>
      </form>
      {replyTo && (
        <button onClick={() => setReplyTo(null)} className="mt-1 text-[11px] text-navy-400 hover:text-accent-600">Cancel reply</button>
      )}
    </div>
  );
}

function Comment({ c, onReply }) {
  return (
    <div className="flex gap-2">
      <Avatar name={c.authorName} size="h-5 w-5" />
      <div className="min-w-0 flex-1">
        <p className="text-xs">
          <span className="font-semibold text-navy-800 dark:text-navy-100">{c.authorName}</span>{' '}
          <span className="break-words text-navy-600 dark:text-navy-300">{c.text}</span>
        </p>
        {onReply && (
          <button onClick={onReply} className="text-[11px] font-medium text-navy-400 hover:text-accent-600">Reply</button>
        )}
      </div>
    </div>
  );
}
