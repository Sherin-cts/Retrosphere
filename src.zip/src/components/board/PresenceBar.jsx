import { useState } from 'react';
import { Users, X, Shield } from 'lucide-react';
import { Avatar } from '../ui';

/**
 * Live roster of who is currently in the board (like the avatar row in a video call).
 * Hover an avatar for name + role; Facilitators can remove a participant.
 */
export default function PresenceBar({ participants, currentUserId, isFacilitator, onRemove }) {
  const [open, setOpen] = useState(false);
  const list = participants || [];
  const shown = list.slice(0, 4);
  const extra = list.length - shown.length;

  return (
    <div className="relative">
      <button onClick={() => setOpen((o) => !o)}
        className="flex items-center gap-2 rounded-full border border-navy-200 bg-white py-1 pl-1 pr-3 dark:border-navy-700 dark:bg-navy-800">
        <div className="flex -space-x-2">
          {shown.map((p) => (
            <span key={p.userId} title={`${p.displayName} · ${p.role}`} className="ring-2 ring-white dark:ring-navy-800 rounded-full">
              <Avatar name={p.displayName} size="h-7 w-7" />
            </span>
          ))}
          {extra > 0 && (
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-navy-200 text-xs font-semibold text-navy-700 ring-2 ring-white dark:bg-navy-700 dark:text-navy-100 dark:ring-navy-800">
              +{extra}
            </span>
          )}
          {list.length === 0 && (
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-navy-100 text-navy-400 dark:bg-navy-700">
              <Users className="h-4 w-4" />
            </span>
          )}
        </div>
        <span className="text-xs font-semibold text-navy-600 dark:text-navy-300">{list.length} in retro</span>
      </button>

      {open && (
        <div className="absolute right-0 z-30 mt-2 w-64 rounded-lg border border-navy-200 bg-white p-2 shadow-card-hover dark:border-navy-700 dark:bg-navy-800">
          <p className="px-2 py-1 text-xs font-semibold uppercase tracking-wide text-navy-400">In this retro</p>
          {list.length === 0 && <p className="px-2 py-2 text-sm text-navy-400">No one connected.</p>}
          {list.map((p) => (
            <div key={p.userId} className="flex items-center gap-2 rounded-md px-2 py-1.5 hover:bg-navy-50 dark:hover:bg-navy-700">
              <Avatar name={p.displayName} size="h-6 w-6" />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-navy-800 dark:text-navy-100">
                  {p.displayName}{p.userId === currentUserId && <span className="text-navy-400"> (you)</span>}
                </p>
              </div>
              {p.role === 'FACILITATOR' && (
                <span title="Facilitator" className="text-accent-600"><Shield className="h-3.5 w-3.5" /></span>
              )}
              {isFacilitator && p.userId !== currentUserId && (
                <button onClick={() => onRemove(p)} title="Remove from workspace"
                  className="rounded p-1 text-navy-400 hover:bg-red-50 hover:text-red-600 dark:hover:bg-navy-600">
                  <X className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
