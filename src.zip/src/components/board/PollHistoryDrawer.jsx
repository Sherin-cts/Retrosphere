import { X, History } from 'lucide-react';
import PollCard from './PollCard';

/** Slide-out drawer listing closed (archived) polls with their final results. */
export default function PollHistoryDrawer({ polls, open, onClose }) {
  return (
    <div className={`fixed inset-y-0 right-0 z-40 w-full max-w-md transform border-l border-navy-200 bg-white shadow-2xl transition-transform dark:border-navy-700 dark:bg-navy-900 ${open ? 'translate-x-0' : 'translate-x-full'}`}>
      <div className="flex items-center justify-between border-b border-navy-200 px-4 py-3 dark:border-navy-700">
        <h2 className="flex items-center gap-2 font-bold text-navy-900 dark:text-white">
          <History className="h-5 w-5 text-accent-600" /> Poll history
          <span className="badge bg-navy-100 text-navy-600 dark:bg-navy-700 dark:text-navy-200">{polls.length}</span>
        </h2>
        <button onClick={onClose} className="rounded p-1 text-navy-400 hover:bg-navy-100 dark:hover:bg-navy-700"><X className="h-5 w-5" /></button>
      </div>
      <div className="h-[calc(100%-3.5rem)] space-y-3 overflow-y-auto p-4">
        {polls.length === 0 ? (
          <p className="mt-10 text-center text-sm text-navy-400">No closed polls yet.</p>
        ) : (
          polls.map((p) => <PollCard key={p.id} poll={p} isFacilitator={false} readOnly />)
        )}
      </div>
    </div>
  );
}
