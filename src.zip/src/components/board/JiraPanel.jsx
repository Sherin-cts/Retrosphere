import { useEffect, useState } from 'react';
import { ExternalLink, RefreshCw, Bug, CheckSquare, BookOpen, X } from 'lucide-react';
import { jiraApi } from '../../api/endpoints';
import { errorMessage } from '../../api/client';

export default function JiraPanel({ onClose }) {
  const [data,    setData]    = useState(null);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState('');

  const load = async () => {
    setLoading(true); setError('');
    try {
      const result = await jiraApi.summary();
      if (result.error) setError(result.error);
      else setData(result);
    } catch (e) {
      setError(errorMessage(e, 'Could not reach Jira'));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div className="w-full max-w-md rounded-2xl bg-white dark:bg-navy-800 shadow-2xl overflow-hidden">

        {/* Header */}
        <div className="flex items-center justify-between bg-[#0052CC] px-5 py-4">
          <div className="flex items-center gap-2">
            <img src="https://wac-cdn.atlassian.com/assets/img/favicons/jira/favicon.png"
                 alt="Jira" className="h-5 w-5" onError={(e) => e.target.style.display='none'} />
            <span className="font-bold text-white text-lg">Jira Dashboard</span>
            <span className="text-blue-200 text-sm font-mono">TRAF Sprint 1</span>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={load} className="text-blue-200 hover:text-white" title="Refresh">
              <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button onClick={onClose} className="text-blue-200 hover:text-white">
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="p-5">
          {loading && !data && (
            <div className="flex flex-col items-center py-10 gap-3 text-navy-400">
              <RefreshCw className="h-6 w-6 animate-spin" />
              <span className="text-sm">Fetching from Jira...</span>
            </div>
          )}

          {error && (
            <div className="rounded-lg bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700 p-4 text-red-700 dark:text-red-300 text-sm">
              {error}
            </div>
          )}

          {data && !error && (
            <>
              {/* Summary stats */}
              <div className="grid grid-cols-2 gap-3 mb-4">
                <StatCard icon={<Bug className="h-4 w-4 text-red-500" />}
                          label="Bugs" value={data.bugs} color="red" />
                <StatCard icon={<CheckSquare className="h-4 w-4 text-blue-500" />}
                          label="Tasks" value={data.tasks} color="blue" />
                <StatCard icon={<BookOpen className="h-4 w-4 text-purple-500" />}
                          label="Stories" value={data.stories} color="purple" />
                <StatCard icon={<span className="text-navy-500 font-bold text-xs">ALL</span>}
                          label="Total Issues" value={data.total} color="navy" />
              </div>

              {/* Status breakdown */}
              <div className="rounded-xl border border-navy-200 dark:border-navy-600 overflow-hidden mb-4">
                <div className="bg-navy-50 dark:bg-navy-700 px-4 py-2 text-xs font-semibold text-navy-500 dark:text-navy-300 uppercase tracking-wide">
                  By Status
                </div>
                <div className="divide-y divide-navy-100 dark:divide-navy-600">
                  <StatusRow label="To Do"       value={data.toDo}       color="bg-gray-400" />
                  <StatusRow label="In Progress"  value={data.inProgress} color="bg-blue-500" />
                  <StatusRow label="In Review"    value={data.inReview}   color="bg-yellow-500" />
                  <StatusRow label="Done"         value={data.done}       color="bg-green-500" />
                </div>
              </div>

              {/* Progress bar */}
              {data.total > 0 && (
                <div className="mb-4">
                  <div className="flex justify-between text-xs text-navy-500 dark:text-navy-400 mb-1">
                    <span>Sprint progress</span>
                    <span>{Math.round((data.done / data.total) * 100)}% done</span>
                  </div>
                  <div className="h-2 rounded-full bg-navy-100 dark:bg-navy-600 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-green-500 transition-all duration-500"
                      style={{ width: `${(data.done / data.total) * 100}%` }}
                    />
                  </div>
                </div>
              )}

              {/* Open in Jira */}
              <a href={data.boardUrl} target="_blank" rel="noopener noreferrer"
                 className="flex items-center justify-center gap-2 w-full rounded-lg bg-[#0052CC] hover:bg-[#0747A6] text-white text-sm font-medium py-2.5 transition-colors">
                <ExternalLink className="h-4 w-4" />
                Open in Jira
              </a>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, color }) {
  const colors = {
    red:    'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-700',
    blue:   'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-700',
    purple: 'bg-purple-50 dark:bg-purple-900/20 border-purple-200 dark:border-purple-700',
    navy:   'bg-navy-50 dark:bg-navy-700 border-navy-200 dark:border-navy-600',
  };
  return (
    <div className={`rounded-xl border p-3 flex items-center gap-3 ${colors[color]}`}>
      <div className="flex-shrink-0">{icon}</div>
      <div>
        <p className="text-xl font-bold text-navy-900 dark:text-white">{value}</p>
        <p className="text-xs text-navy-500 dark:text-navy-400">{label}</p>
      </div>
    </div>
  );
}

function StatusRow({ label, value, color }) {
  return (
    <div className="flex items-center justify-between px-4 py-2.5">
      <div className="flex items-center gap-2">
        <span className={`h-2.5 w-2.5 rounded-full ${color}`} />
        <span className="text-sm text-navy-700 dark:text-navy-300">{label}</span>
      </div>
      <span className="text-sm font-semibold text-navy-900 dark:text-white">{value}</span>
    </div>
  );
}
