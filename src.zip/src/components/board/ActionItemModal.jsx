import { useEffect, useState } from 'react';
import { actionItemApi, workspaceApi } from '../../api/endpoints';
import { errorMessage } from '../../api/client';
import { Modal, ErrorBanner, Spinner } from '../ui';

export default function ActionItemModal({ cardId, cardText, workspaceId, onClose, setError, onCreated }) {
  const [members, setMembers] = useState([]);
  const [title, setTitle] = useState(cardText?.slice(0, 200) || '');
  const [dueDate, setDueDate] = useState('');
  const [priority, setPriority] = useState('MED');
  const [assigneeIds, setAssigneeIds] = useState([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  useEffect(() => {
    workspaceApi.members(workspaceId).then(setMembers).catch(() => {});
  }, [workspaceId]);

  const toggle = (id) => setAssigneeIds((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setErr('');
    try {
      const created = await actionItemApi.createFromCard(cardId, {
        title,
        assigneeIds,
        dueDate: dueDate || null,
        priority,
      });
      onCreated?.(created);
      onClose();
    } catch (e2) {
      setErr(errorMessage(e2, 'Could not create action item'));
    } finally { setBusy(false); }
  };

  return (
    <Modal open onClose={onClose} title="Create action item">
      <form onSubmit={submit} className="space-y-4">
        <ErrorBanner message={err} />
        <div>
          <label className="label">Title</label>
          <input className="input" required value={title} onChange={(e) => setTitle(e.target.value)} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">Due date</label>
            <input className="input" type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
          </div>
          <div>
            <label className="label">Priority</label>
            <select className="input" value={priority} onChange={(e) => setPriority(e.target.value)}>
              <option value="LOW">Low</option>
              <option value="MED">Medium</option>
              <option value="HIGH">High</option>
            </select>
          </div>
        </div>
        <div>
          <label className="label">Assignees</label>
          <div className="max-h-40 space-y-1 overflow-y-auto rounded-md border border-navy-200 p-2 dark:border-navy-700">
            {members.length === 0 && <p className="text-sm text-navy-400">No members found.</p>}
            {members.map((m) => (
              <label key={m.userId} className="flex cursor-pointer items-center gap-2 rounded p-1 text-sm hover:bg-navy-50 dark:hover:bg-navy-700">
                <input type="checkbox" checked={assigneeIds.includes(m.userId)} onChange={() => toggle(m.userId)} />
                {m.displayName} <span className="text-navy-400">({m.email})</span>
              </label>
            ))}
          </div>
        </div>
        <div className="flex justify-end gap-2">
          <button type="button" className="btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn-primary" disabled={busy}>{busy ? <Spinner className="h-4 w-4 text-white" /> : 'Create'}</button>
        </div>
      </form>
    </Modal>
  );
}
