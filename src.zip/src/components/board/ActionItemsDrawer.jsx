import { X, ListChecks, Calendar, FileText, Trash2 } from 'lucide-react';
import { Avatar } from '../ui';

const STATUSES = ['OPEN', 'IN_PROGRESS', 'DONE', 'CANCELLED'];
const PRIORITY_STYLE = {
  HIGH: 'text-white',
  MED:  'text-white',
  LOW:  'text-white',
};
const PRIORITY_BG = {
  HIGH: '#F25C6E',
  MED:  '#F5A020',
  LOW:  '#2B8FE8',
};
const STATUS_STYLE = {
  OPEN:        'bg-vivid-blue-50   text-vivid-blue   dark:bg-vivid-blue-900   dark:text-blue-200',
  IN_PROGRESS: 'bg-vivid-purple-50 text-vivid-purple dark:bg-vivid-purple-900 dark:text-purple-200',
  DONE:        'bg-vivid-green-50  text-vivid-green  dark:bg-vivid-green-900  dark:text-green-200',
  CANCELLED:   'bg-navy-100 text-navy-400 line-through dark:bg-navy-700',
};

/**
 * Slide-out panel listing this board's action items with owners, due dates, priority,
 * and a status dropdown — visibly distinct from feedback cards. Presentational only;
 * state is owned by the board page.
 */
export default function ActionItemsDrawer({ items, open, onClose, onUpdateStatus, onDelete, isFacilitator, currentUserId }) {
  return (
    <div className={`fixed inset-y-0 right-0 z-40 w-full max-w-md transform border-l border-navy-200 bg-white shadow-2xl transition-transform dark:border-navy-700 dark:bg-navy-900 ${open ? 'translate-x-0' : 'translate-x-full'}`}>
      <div className="flex items-center justify-between border-b border-navy-200 px-4 py-3 dark:border-navy-700">
        <h2 className="flex items-center gap-2 font-bold text-navy-900 dark:text-white">
          <ListChecks className="h-5 w-5 text-accent-600" /> Action Items
          {items && <span className="badge bg-navy-100 text-navy-600 dark:bg-navy-700 dark:text-navy-200">{items.length}</span>}
        </h2>
        <button onClick={onClose} className="rounded p-1 text-navy-400 hover:bg-navy-100 dark:hover:bg-navy-700"><X className="h-5 w-5" /></button>
      </div>

      <div className="h-[calc(100%-3.5rem)] overflow-y-auto p-4">
        {!items || items.length === 0 ? (
          <div className="mt-10 text-center text-sm text-navy-400">
            <ListChecks className="mx-auto mb-2 h-8 w-8 text-navy-300" />
            No action items yet. A Facilitator can create one from any card (the ✓ icon).
          </div>
        ) : (
          <div className="space-y-3">
            {items.map((it) => (
              <div key={it.id} className="card border border-navy-100 p-3 dark:border-navy-700">
                <div className="flex items-start gap-2">
                  <span className={`badge ${PRIORITY_STYLE[it.priority]}`}
                    style={{ background: PRIORITY_BG[it.priority] }}>{it.priority}</span>
                  <p className="flex-1 text-sm font-medium text-navy-900 dark:text-white">{it.title}</p>
                  {(isFacilitator || it.createdByUserId === currentUserId) && (
                    <button onClick={() => onDelete(it.id)} title="Delete action item"
                      className="rounded p-1 text-navy-400 hover:bg-red-50 hover:text-red-600 dark:hover:bg-navy-700">
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
                {it.sourceCardId && (
                  <p className="mt-1 flex items-center gap-1 text-xs text-navy-400"><FileText className="h-3 w-3" /> from a card</p>
                )}
                <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2 text-xs text-navy-500">
                    {it.dueDate && <span className="flex items-center gap-1"><Calendar className="h-3 w-3" /> {it.dueDate}</span>}
                    <div className="flex -space-x-1">
                      {it.assignees.map((a) => <span key={a.userId} title={a.displayName}><Avatar name={a.displayName} size="h-5 w-5" /></span>)}
                      {it.assignees.length === 0 && <span className="text-navy-400">Unassigned</span>}
                    </div>
                  </div>
                  <select className={`rounded-md border-0 px-2 py-1 text-xs font-semibold ${STATUS_STYLE[it.status]}`}
                    value={it.status} onChange={(e) => onUpdateStatus(it.id, e.target.value)}>
                    {STATUSES.map((s) => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
                  </select>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
