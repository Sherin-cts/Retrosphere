import { useState } from 'react';
import { BarChart3 } from 'lucide-react';
import { Modal, ErrorBanner, Spinner } from '../ui';
import { POLL_EMOJI } from './PollCard';

export default function CreatePollModal({ onCreate, onClose }) {
  const [title, setTitle] = useState('How are you feeling?');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    if (!title.trim()) return;
    setBusy(true); setErr('');
    try {
      await onCreate(title.trim());
      onClose();
    } catch (e2) {
      setErr(e2?.message || 'Could not create poll');
    } finally { setBusy(false); }
  };

  return (
    <Modal open onClose={onClose} title="Create a poll">
      <form onSubmit={submit} className="space-y-4">
        <ErrorBanner message={err} />
        <div>
          <label className="label">Question</label>
          <input className="input" autoFocus value={title} onChange={(e) => setTitle(e.target.value)}
            placeholder="How are you feeling?" />
        </div>
        <div className="rounded-md bg-navy-50 p-3 dark:bg-navy-700/50">
          <p className="mb-2 flex items-center gap-1 text-xs font-medium text-navy-500">
            <BarChart3 className="h-3.5 w-3.5" /> Members answer on a 1–5 scale
          </p>
          <div className="flex justify-between">
            {[1, 2, 3, 4, 5].map((n) => <span key={n} className="text-2xl">{POLL_EMOJI[n]}</span>)}
          </div>
        </div>
        <div className="flex justify-end gap-2">
          <button type="button" className="btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn-primary" disabled={busy}>
            {busy ? <Spinner className="h-4 w-4 text-white" /> : 'Create poll'}
          </button>
        </div>
      </form>
    </Modal>
  );
}
