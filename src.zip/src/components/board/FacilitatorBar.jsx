import { useEffect, useRef, useState } from 'react';
import {
  Play, Pause, RotateCcw, Eye, Settings, UserPlus, Clock, AlertTriangle, ChevronDown, Timer, Smile, Search, X,
} from 'lucide-react';
import { sessionApi, voteApi, boardApi } from '../../api/endpoints';
import { errorMessage } from '../../api/client';
import InviteModal from './InviteModal';
import { Modal } from '../ui';
import { useToast } from '../../context/ToastContext';

const PHASES = ['GATHER', 'VOTE', 'DISCUSS', 'CLOSED'];

const PRESETS = [
  { label: '5m', h: 0, m: 5 }, { label: '10m', h: 0, m: 10 }, { label: '15m', h: 0, m: 15 },
  { label: '30m', h: 0, m: 30 }, { label: '45m', h: 0, m: 45 }, { label: '1h', h: 1, m: 0 },
  { label: '1h 30m', h: 1, m: 30 }, { label: '2h', h: 2, m: 0 },
];

const REACTIONS = ['👍', '❤️', '🎉', '😄', '🚀', '😟'];

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, Number(v) || 0));

// mm:ss, or h:mm:ss once it's an hour or more.
function fmt(seconds) {
  if (seconds == null) return '--:--';
  const s = Math.max(0, Math.round(seconds));
  const h = Math.floor(s / 3600);
  const mm = String(Math.floor((s % 3600) / 60)).padStart(2, '0');
  const ss = String(s % 60).padStart(2, '0');
  return h > 0 ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
}

export default function FacilitatorBar({ board, isFacilitator, timerEvent, onChanged, setError, sendReaction,
  searchText, setSearchText, filterUserId, setFilterUserId, members = [] }) {
  const { toast } = useToast();
  const [remaining, setRemaining] = useState(null);
  const [running, setRunning] = useState(false);
  const [setupOpen, setSetupOpen] = useState(false);
  const [hours, setHours] = useState(0);
  const [mins, setMins] = useState(15);
  const [reactionsOpen, setReactionsOpen] = useState(false);
  const [inviteOpen, setInviteOpen] = useState(false);
  const [configOpen, setConfigOpen] = useState(false);
  const timeUpFired = useRef(false); // so the "time's up" toast fires only once per run

  // Derive the countdown from the latest timer event.
  useEffect(() => {
    if (!timerEvent) { setRemaining(null); setRunning(false); return undefined; }
    const { action, durationSeconds, serverTime } = timerEvent;
    if (action === 'START') {
      timeUpFired.current = false; // a fresh run can fire again
      const endMs = new Date(serverTime).getTime() + (durationSeconds || 0) * 1000;
      setRunning(true);
      let handle;
      const tick = () => {
        const rem = (endMs - Date.now()) / 1000;
        if (rem <= 0) {
          setRemaining(0);
          setRunning(false);
          clearInterval(handle);
          if (!timeUpFired.current) {
            timeUpFired.current = true;
            toast("⏰ Time's up! Time to wrap up the discussion.", 'error');
          }
        } else {
          setRemaining(rem);
        }
      };
      tick();
      handle = setInterval(tick, 1000);
      return () => clearInterval(handle);
    }
    if (action === 'PAUSE') { setRunning(false); setRemaining(durationSeconds ?? null); return undefined; }
    timeUpFired.current = false;
    setRunning(false); setRemaining(null); // RESET
    return undefined;
  }, [timerEvent, toast]);

  const warn = running && remaining != null && remaining <= 600; // last 10 minutes

  const setPhase = async (phase) => {
    try { const detail = await sessionApi.phase(board.id, phase); onChanged(detail); }
    catch (err) { setError(errorMessage(err)); }
  };

  const startWith = async (h, m) => {
    const total = clamp(h, 0, 12) * 3600 + clamp(m, 0, 59) * 60;
    if (total <= 0) { setError('Set at least 1 minute'); return; }
    setHours(h); setMins(m); setSetupOpen(false);
    try { await sessionApi.timer(board.id, 'START', total); }
    catch (err) { setError(errorMessage(err)); }
  };
  const pauseTimer = async () => {
    try { await sessionApi.timer(board.id, 'PAUSE', Math.max(0, Math.round(remaining || 0))); }
    catch (err) { setError(errorMessage(err)); }
  };
  const resetTimer = async () => {
    try { await sessionApi.timer(board.id, 'RESET', null); }
    catch (err) { setError(errorMessage(err)); }
  };

  const reveal = async () => {
    try { await voteApi.reveal(board.id); onChanged((b) => b && { ...b, votesRevealed: true }); }
    catch (err) { setError(errorMessage(err)); }
  };

  return (
    <div className="flex flex-wrap items-center gap-3 border-b border-navy-200 bg-white px-4 py-2 dark:border-navy-800 dark:bg-navy-900">
      {/* Phase */}
      <div className="flex items-center gap-1">
        {PHASES.map((p) => (
          <button key={p} disabled={!isFacilitator} onClick={() => setPhase(p)}
            className={`rounded px-2.5 py-1 text-xs font-semibold capitalize transition ${
              board.phase === p
                ? `phase-btn-${p}`
                : 'text-navy-500 hover:bg-navy-100 disabled:hover:bg-transparent dark:text-navy-400 dark:hover:bg-navy-800'
            } ${!isFacilitator ? 'cursor-default' : ''}`}>
            {p.toLowerCase()}
          </button>
        ))}
      </div>

      <div className="h-5 w-px bg-navy-200 dark:bg-navy-700" />

      {/* Timer */}
      <div className="relative flex items-center gap-1.5">
        <div className={`flex items-center gap-2 rounded-lg px-3 py-1.5 transition-colors ${
          warn ? 'bg-red-100 text-red-700 dark:bg-red-950/50 dark:text-red-300'
               : remaining != null ? 'bg-accent-50 text-accent-700 dark:bg-navy-800 dark:text-accent-200'
               : 'bg-navy-100 text-navy-500 dark:bg-navy-800 dark:text-navy-400'}`}>
          {warn ? <AlertTriangle className="h-4 w-4" /> : <Clock className="h-4 w-4" />}
          <span className="font-mono text-base font-bold tabular-nums">{fmt(remaining)}</span>
        </div>

        {isFacilitator && (
          <>
            {running ? (
              <button onClick={pauseTimer} className="btn-secondary px-2 py-1.5" title="Pause"><Pause className="h-4 w-4" /></button>
            ) : (
              <button onClick={() => setSetupOpen((o) => !o)} className="btn-secondary px-2 py-1.5" title="Set & start timer">
                <Play className="h-4 w-4" /> <ChevronDown className="h-3 w-3" />
              </button>
            )}
            {(running || remaining != null) && (
              <button onClick={resetTimer} className="btn-ghost px-2 py-1.5" title="Reset"><RotateCcw className="h-4 w-4" /></button>
            )}
          </>
        )}

        {setupOpen && isFacilitator && (
          <div className="absolute left-0 top-full z-30 mt-2 w-72 rounded-lg border border-navy-200 bg-white p-3 shadow-card-hover dark:border-navy-700 dark:bg-navy-800">
            <p className="mb-2 flex items-center gap-1 text-xs font-semibold uppercase tracking-wide text-navy-400">
              <Timer className="h-3.5 w-3.5" /> Set timer
            </p>
            <div className="mb-3 flex flex-wrap gap-1.5">
              {PRESETS.map((p) => (
                <button key={p.label} onClick={() => startWith(p.h, p.m)}
                  className="rounded-full bg-navy-100 px-2.5 py-1 text-xs font-semibold text-navy-700 transition hover:bg-accent-600 hover:text-white dark:bg-navy-700 dark:text-navy-200">
                  {p.label}
                </button>
              ))}
            </div>
            <div className="flex items-end gap-2">
              <div className="flex-1">
                <label className="mb-1 block text-[11px] font-medium text-navy-500">Hours</label>
                <input type="number" min="0" max="12" value={hours}
                  onChange={(e) => setHours(clamp(e.target.value, 0, 12))} className="input py-1.5" />
              </div>
              <span className="pb-2 text-navy-400">:</span>
              <div className="flex-1">
                <label className="mb-1 block text-[11px] font-medium text-navy-500">Minutes</label>
                <input type="number" min="0" max="59" value={mins}
                  onChange={(e) => setMins(clamp(e.target.value, 0, 59))} className="input py-1.5" />
              </div>
              <button onClick={() => startWith(hours, mins)} className="btn-primary py-1.5"><Play className="h-4 w-4" /> Start</button>
            </div>
          </div>
        )}
      </div>

      {/* Reactions (expandable) — available to all participants, alongside the timer */}
      <div className="relative">
        <button onClick={() => setReactionsOpen((o) => !o)} className="btn-secondary px-2 py-1.5" title="Send a reaction">
          <Smile className="h-4 w-4" /> <ChevronDown className="h-3 w-3" />
        </button>
        {reactionsOpen && (
          <div className="absolute left-0 top-full z-30 mt-2 flex gap-1 rounded-lg border border-navy-200 bg-white p-2 shadow-card-hover dark:border-navy-700 dark:bg-navy-800">
            {REACTIONS.map((emoji) => (
              <button key={emoji} onClick={() => { sendReaction?.(emoji, null); setReactionsOpen(false); }}
                className="rounded px-1.5 py-1 text-xl transition hover:scale-125">{emoji}</button>
            ))}
          </div>
        )}
      </div>

      <div className="h-5 w-px bg-navy-200 dark:bg-navy-700" />

      {/* Search cards by description */}
      <div className="relative flex items-center">
        <Search className="pointer-events-none absolute left-2 h-4 w-4 text-navy-400" />
        <input value={searchText} onChange={(e) => setSearchText(e.target.value)}
          placeholder="Search cards…"
          className="input w-44 py-1.5 pl-7 pr-7 text-sm" />
        {searchText && (
          <button onClick={() => setSearchText('')} className="absolute right-2 text-navy-400 hover:text-navy-600" title="Clear">
            <X className="h-3.5 w-3.5" />
          </button>
        )}
      </div>

      {/* Filter by member name */}
      <select value={filterUserId} onChange={(e) => setFilterUserId(e.target.value)}
        className="input w-40 py-1.5 text-sm" title="Filter by member">
        <option value="">All members</option>
        {members.map((m) => (
          <option key={m.userId} value={m.userId}>{m.name}</option>
        ))}
      </select>

      {isFacilitator && (
        <>
          <div className="h-5 w-px bg-navy-200 dark:bg-navy-700" />
          <button onClick={reveal} className={board.votesRevealed ? 'btn-ghost' : 'btn-secondary'} disabled={board.votesRevealed}>
            <Eye className="h-4 w-4" /> {board.votesRevealed ? 'Votes revealed' : 'Reveal votes'}
          </button>
          <button onClick={() => setConfigOpen(true)} className="btn-ghost" title="Vote settings"><Settings className="h-4 w-4" /></button>
          <button onClick={() => setInviteOpen(true)} className="btn-secondary ml-auto"><UserPlus className="h-4 w-4" /> Invite</button>
        </>
      )}

      {inviteOpen && <InviteModal boardId={board.id} workspaceId={board.workspaceId} onClose={() => setInviteOpen(false)} />}
      {configOpen && (
        <VoteConfigModal board={board} onClose={() => setConfigOpen(false)}
          onSaved={(cfg) => onChanged((b) => b && { ...b, allowDownvote: cfg.allowDownvote, hideVotesUntilReveal: cfg.hideVotesUntilReveal })}
          setError={setError} />
      )}
    </div>
  );
}

function VoteConfigModal({ board, onClose, onSaved, setError }) {
  const [allowDownvote, setAllowDownvote] = useState(board.allowDownvote);
  const [hideUntilReveal, setHideUntilReveal] = useState(board.hideVotesUntilReveal);

  const save = async () => {
    try {
      const cfg = await voteApi.config(board.id, { allowDownvote, hideUntilReveal });
      onSaved(cfg);
      onClose();
    } catch (err) { setError(errorMessage(err)); }
  };

  return (
    <Modal open onClose={onClose} title="Vote settings">
      <div className="space-y-3">
        <label className="flex items-center justify-between rounded-md bg-navy-50 p-3 dark:bg-navy-700">
          <span className="text-sm font-medium">Allow downvotes</span>
          <input type="checkbox" checked={allowDownvote} onChange={(e) => setAllowDownvote(e.target.checked)} />
        </label>
        <label className="flex items-center justify-between rounded-md bg-navy-50 p-3 dark:bg-navy-700">
          <span className="text-sm font-medium">Hide vote totals from members until reveal</span>
          <input type="checkbox" checked={hideUntilReveal} onChange={(e) => setHideUntilReveal(e.target.checked)} />
        </label>
        <div className="flex justify-end gap-2">
          <button className="btn-secondary" onClick={onClose}>Cancel</button>
          <button className="btn-primary" onClick={save}>Save</button>
        </div>
      </div>
    </Modal>
  );
}
