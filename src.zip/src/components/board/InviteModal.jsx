import { useState, useEffect } from 'react';
import { Link2, Mail, Copy, Check, UserSearch, Plus } from 'lucide-react';
import { sessionApi, userApi, workspaceApi } from '../../api/endpoints';
import { errorMessage } from '../../api/client';
import { Modal, ErrorBanner, Spinner, Avatar } from '../ui';
import { useToast } from '../../context/ToastContext';

export default function InviteModal({ boardId, workspaceId, onClose, onAdded }) {
  const { toast } = useToast();
  const [tab, setTab] = useState('search');
  const [link, setLink] = useState('');
  const [copied, setCopied] = useState(false);
  const [emails, setEmails] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');

  // --- people search ---
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [addedEmails, setAddedEmails] = useState([]);

  useEffect(() => {
    if (tab !== 'search') return undefined;
    if (query.trim().length < 2) { setResults([]); return undefined; }
    setSearching(true);
    const t = setTimeout(async () => {
      try { setResults(await userApi.search(query.trim())); }
      catch { /* ignore */ }
      finally { setSearching(false); }
    }, 300); // debounce
    return () => clearTimeout(t);
  }, [query, tab]);

  const addPerson = async (person) => {
    setErr('');
    try {
      await workspaceApi.invite(workspaceId, person.email, 'MEMBER');
      setAddedEmails((a) => [...a, person.email]);
      toast(`${person.displayName} added to the workspace`);
      onAdded?.();
    } catch (e) { setErr(errorMessage(e, 'Could not add person')); }
  };

  const genLink = async () => {
    setBusy(true); setErr('');
    try {
      const res = await sessionApi.inviteLink(boardId, 1440);
      setLink(`${window.location.origin}/boards/${boardId}/join?token=${res.token}`);
    } catch (e) { setErr(errorMessage(e)); }
    finally { setBusy(false); }
  };

  const copy = () => {
    navigator.clipboard?.writeText(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const sendEmails = async (e) => {
    e.preventDefault();
    setBusy(true); setErr(''); setMsg('');
    try {
      const list = emails.split(/[\s,]+/).map((x) => x.trim()).filter(Boolean);
      await sessionApi.inviteEmail(boardId, list);
      setMsg(`Invitations sent to ${list.length} address(es).`);
      setEmails('');
    } catch (e2) { setErr(errorMessage(e2)); }
    finally { setBusy(false); }
  };

  return (
    <Modal open onClose={onClose} title="Invite participants">
      <div className="mb-4 flex gap-1 rounded-md bg-navy-100 p-1 dark:bg-navy-800">
        {[['search', 'Add by name', UserSearch], ['link', 'Link', Link2], ['email', 'Email', Mail]].map(([k, l, Icon]) => (
          <button key={k} onClick={() => setTab(k)}
            className={`flex flex-1 items-center justify-center gap-2 rounded px-3 py-1.5 text-sm font-medium ${tab === k ? 'bg-white text-navy-900 shadow-sm dark:bg-navy-700 dark:text-white' : 'text-navy-500'}`}>
            <Icon className="h-4 w-4" /> {l}
          </button>
        ))}
      </div>

      <ErrorBanner message={err} />
      <p className="mb-3 text-xs text-navy-500">People you add join the workspace as a <strong>Member</strong>.</p>

      {tab === 'search' && (
        <div className="space-y-3">
          <input className="input" autoFocus value={query} onChange={(e) => setQuery(e.target.value)}
            placeholder="Search people by name or email…" />
          <div className="max-h-64 space-y-1 overflow-y-auto">
            {searching && <div className="flex justify-center py-3"><Spinner className="h-4 w-4" /></div>}
            {!searching && query.trim().length >= 2 && results.length === 0 && (
              <p className="py-3 text-center text-sm text-navy-400">No matching users.</p>
            )}
            {results.map((p) => {
              const added = addedEmails.includes(p.email);
              return (
                <div key={p.id} className="flex items-center gap-2 rounded-md p-2 hover:bg-navy-50 dark:hover:bg-navy-700">
                  <Avatar name={p.displayName} size="h-7 w-7" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-navy-800 dark:text-navy-100">{p.displayName}</p>
                    <p className="truncate text-xs text-navy-400">{p.email}</p>
                  </div>
                  <button disabled={added} onClick={() => addPerson(p)}
                    className={added ? 'btn-ghost text-emerald-600' : 'btn-primary px-2 py-1'}>
                    {added ? <Check className="h-4 w-4" /> : <><Plus className="h-4 w-4" /> Add</>}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {tab === 'link' && (
        <div className="space-y-3">
          {!link ? (
            <button className="btn-primary w-full" onClick={genLink} disabled={busy}>
              {busy ? <Spinner className="h-4 w-4 text-white" /> : 'Generate link'}
            </button>
          ) : (
            <div className="flex gap-2">
              <input className="input font-mono text-xs" readOnly value={link} />
              <button className="btn-secondary" onClick={copy}>{copied ? <Check className="h-4 w-4 text-emerald-600" /> : <Copy className="h-4 w-4" />}</button>
            </div>
          )}
          <p className="text-xs text-navy-400">Link expires in 24 hours.</p>
        </div>
      )}

      {tab === 'email' && (
        <form onSubmit={sendEmails} className="space-y-3">
          <textarea className="input min-h-[90px]" value={emails} onChange={(e) => setEmails(e.target.value)}
            placeholder="alice@company.com, bob@company.com" />
          {msg && <p className="text-sm text-emerald-600">{msg}</p>}
          <button type="submit" className="btn-primary w-full" disabled={busy}>
            {busy ? <Spinner className="h-4 w-4 text-white" /> : 'Send invitations'}
          </button>
        </form>
      )}
    </Modal>
  );
}
