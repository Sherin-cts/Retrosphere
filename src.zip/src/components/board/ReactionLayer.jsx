import { useEffect } from 'react';

// Renders transient emotes that float up from the bottom of the board.
export default function ReactionLayer({ reactions, onDone }) {
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-16 z-40 h-0">
      {reactions.map((r) => (
        <FloatingReaction key={r.id} reaction={r} onDone={onDone} />
      ))}
    </div>
  );
}

function FloatingReaction({ reaction, onDone }) {
  useEffect(() => {
    const t = setTimeout(() => onDone(reaction.id), 2400);
    return () => clearTimeout(t);
  }, [reaction.id, onDone]);

  const left = 10 + Math.random() * 80; // random horizontal position
  return (
    <span className="reaction-float absolute text-3xl" style={{ left: `${left}%` }}>
      {reaction.emoji}
    </span>
  );
}
