import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import {
  Document, Packer, Paragraph, TextRun, HeadingLevel,
  Table, TableRow, TableCell, WidthType, AlignmentType,
  BorderStyle, ShadingType, PageBreak,
} from 'docx';

// ── shared helpers ────────────────────────────────────────────────────────────

function fmtDate() {
  return new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' });
}
function fmtTime() {
  return new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true });
}
function fmtDateTime() { return `${fmtDate()}  •  ${fmtTime()}`; }

function sortedCards(board) {
  return [...(board.cards || [])].sort((a, b) =>
    a.columnId !== b.columnId ? a.columnId - b.columnId : a.position - b.position
  );
}

function getCardsForColumn(board, colId) {
  return sortedCards(board).filter((c) => c.columnId === colId);
}

function topVoted(board, n = 3) {
  return [...(board.cards || [])]
    .sort((a, b) => (b.upvotes ?? 0) - (a.upvotes ?? 0))
    .slice(0, n);
}

function phaseName(p) {
  const map = { GATHER: 'Gather', VOTE: 'Vote', DISCUSS: 'Discuss', CLOSED: 'Closed' };
  return map[p] || p;
}

// ── PDF Meeting Minutes ───────────────────────────────────────────────────────

export function exportToPdf(board, actionItems = [], participants = [], polls = []) {
  const doc  = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const W    = doc.internal.pageSize.getWidth();
  const H    = doc.internal.pageSize.getHeight();
  let y      = 0;

  const newPage = () => { doc.addPage(); y = 20; };
  const checkY  = (need = 30) => { if (y + need > H - 15) newPage(); };

  // ── Cover / Header ──────────────────────────────────────────────────────────
  // Dark header band
  doc.setFillColor(27, 43, 74);
  doc.rect(0, 0, W, 42, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(22);
  doc.setFont('helvetica', 'bold');
  doc.text('RETROSPECTIVE MEETING MINUTES', W / 2, 16, { align: 'center' });

  doc.setFontSize(13);
  doc.setFont('helvetica', 'normal');
  doc.text(board.name || 'Sprint Retro', W / 2, 26, { align: 'center' });

  doc.setFontSize(9);
  doc.setTextColor(180, 200, 230);
  doc.text(fmtDateTime(), W / 2, 35, { align: 'center' });

  // Colour strip
  const strip = [
    [43, 143, 232], [242, 92, 110], [34, 197, 94], [155, 39, 175], [245, 160, 32],
  ];
  strip.forEach(([r, g, b], i) => {
    doc.setFillColor(r, g, b);
    doc.rect((W / strip.length) * i, 42, W / strip.length, 3, 'F');
  });

  doc.setTextColor(0, 0, 0);
  y = 55;

  // ── Meeting Overview box ────────────────────────────────────────────────────
  doc.setFillColor(245, 247, 252);
  doc.roundedRect(12, y, W - 24, 32, 3, 3, 'F');
  doc.setDrawColor(200, 210, 230);
  doc.roundedRect(12, y, W - 24, 32, 3, 3, 'S');

  const facilitator = participants.find((p) => p.role === 'FACILITATOR')?.displayName || '—';
  const memberCount = participants.length;
  const totalCards  = (board.cards || []).length;
  const aiCount     = actionItems.length;

  const overviewItems = [
    ['Phase', phaseName(board.phase)],
    ['Facilitator', facilitator],
    ['Participants', String(memberCount)],
    ['Total Cards', String(totalCards)],
    ['Action Items', String(aiCount)],
    ['Exported', fmtDate()],
  ];

  const colW = (W - 24) / 3;
  overviewItems.forEach(([label, val], i) => {
    const col = i % 3;
    const row = Math.floor(i / 3);
    const ox  = 18 + col * colW;
    const oy  = y + 8 + row * 14;

    doc.setFontSize(7);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(120);
    doc.text(label.toUpperCase(), ox, oy);

    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(30);
    doc.text(val, ox, oy + 5);
  });
  y += 40;

  // ── Participants ────────────────────────────────────────────────────────────
  if (participants.length > 0) {
    checkY(20);
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(27, 43, 74);
    doc.text('1.  Participants', 14, y);
    y += 4;

    autoTable(doc, {
      startY: y,
      margin: { left: 14, right: 14 },
      head: [['#', 'Name', 'Role']],
      body: participants.map((p, i) => [
        i + 1,
        p.displayName || p.email || '—',
        p.role || 'MEMBER',
      ]),
      styles: { fontSize: 8, cellPadding: 2.5 },
      headStyles: { fillColor: [27, 43, 74], textColor: 255, fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [245, 247, 252] },
      theme: 'grid',
    });
    y = doc.lastAutoTable.finalY + 10;
  }

  // ── Cards by Column ─────────────────────────────────────────────────────────
  checkY(20);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(27, 43, 74);
  doc.text('2.  Retrospective Cards', 14, y);
  y += 6;

  const colColors = [
    [43, 143, 232], [242, 92, 110], [34, 197, 94], [155, 39, 175], [245, 160, 32],
  ];

  (board.columns || []).forEach((col, idx) => {
    const cards = getCardsForColumn(board, col.id);
    checkY(25);

    const [r, g, b] = colColors[idx % colColors.length];
    doc.setFillColor(r, g, b);
    doc.rect(14, y - 4, 3, 10, 'F');

    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(r, g, b);
    doc.text(`${col.name}  (${cards.length} card${cards.length !== 1 ? 's' : ''})`, 20, y + 2);
    doc.setTextColor(0);
    y += 8;

    if (cards.length === 0) {
      doc.setFontSize(8);
      doc.setFont('helvetica', 'italic');
      doc.setTextColor(150);
      doc.text('No cards added', 20, y);
      doc.setTextColor(0);
      y += 8;
    } else {
      autoTable(doc, {
        startY: y,
        margin: { left: 14, right: 14 },
        head: [['#', 'Card Text', 'Author', 'Up', 'Down']],
        body: cards.map((c, i) => [
          i + 1,
          c.text || '',
          c.authorName || '—',
          c.upvotes ?? 0,
          c.downvotes ?? 0,
        ]),
        styles: { fontSize: 8, cellPadding: 2.5 },
        headStyles: { fillColor: [r, g, b], textColor: 255 },
        columnStyles: {
          0: { cellWidth: 8 },
          1: { cellWidth: 'auto' },
          3: { cellWidth: 14, halign: 'center' },
          4: { cellWidth: 14, halign: 'center' },
        },
        alternateRowStyles: { fillColor: [248, 249, 252] },
        theme: 'grid',
      });
      y = doc.lastAutoTable.finalY + 10;
    }
  });

  // ── Top Voted Cards ─────────────────────────────────────────────────────────
  const topCards = topVoted(board, 5);
  if (topCards.length > 0) {
    checkY(25);
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(27, 43, 74);
    doc.text('3.  Top Voted Cards', 14, y);
    y += 4;

    autoTable(doc, {
      startY: y,
      margin: { left: 14, right: 14 },
      head: [['Rank', 'Card Text', 'Upvotes', 'Downvotes']],
      body: topCards.map((c, i) => [
        `#${i + 1}`,
        c.text || '',
        c.upvotes ?? 0,
        c.downvotes ?? 0,
      ]),
      styles: { fontSize: 8, cellPadding: 2.5 },
      headStyles: { fillColor: [245, 160, 32], textColor: 255 },
      alternateRowStyles: { fillColor: [255, 252, 242] },
      theme: 'grid',
    });
    y = doc.lastAutoTable.finalY + 10;
  }

  // ── Polls ───────────────────────────────────────────────────────────────────
  const revealedPolls = polls.filter((p) => p.average != null);
  if (revealedPolls.length > 0) {
    checkY(25);
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(27, 43, 74);
    doc.text('4.  Team Sentiment Polls', 14, y);
    y += 4;

    autoTable(doc, {
      startY: y,
      margin: { left: 14, right: 14 },
      head: [['Poll Question', 'Avg Score', 'Responses']],
      body: revealedPolls.map((p) => [
        p.title || '—',
        p.average != null ? p.average.toFixed(1) + ' / 5' : '—',
        p.responseCount ?? 0,
      ]),
      styles: { fontSize: 8, cellPadding: 2.5 },
      headStyles: { fillColor: [34, 197, 94], textColor: 255 },
      alternateRowStyles: { fillColor: [242, 252, 245] },
      theme: 'grid',
    });
    y = doc.lastAutoTable.finalY + 10;
  }

  // ── Action Items ────────────────────────────────────────────────────────────
  if (actionItems.length > 0) {
    checkY(25);
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(27, 43, 74);
    const sectionNo = revealedPolls.length > 0 ? '5' : '4';
    doc.text(`${sectionNo}.  Action Items`, 14, y);
    y += 4;

    autoTable(doc, {
      startY: y,
      margin: { left: 14, right: 14 },
      head: [['#', 'Action Item', 'Priority', 'Status', 'Assignee(s)', 'Due Date']],
      body: actionItems.map((a, i) => [
        i + 1,
        a.title || '',
        a.priority || '—',
        (a.status || '').replace('_', ' '),
        (a.assignees || []).map((u) => u.displayName).join(', ') || '—',
        a.dueDate || '—',
      ]),
      styles: { fontSize: 8, cellPadding: 2.5 },
      headStyles: { fillColor: [155, 39, 175], textColor: 255 },
      columnStyles: {
        0: { cellWidth: 8 },
        2: { cellWidth: 18, halign: 'center' },
        3: { cellWidth: 22, halign: 'center' },
        5: { cellWidth: 22, halign: 'center' },
      },
      alternateRowStyles: { fillColor: [250, 245, 255] },
      theme: 'grid',
    });
    y = doc.lastAutoTable.finalY + 10;
  }

  // ── Footer on every page ────────────────────────────────────────────────────
  const pageCount = doc.internal.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFillColor(27, 43, 74);
    doc.rect(0, H - 10, W, 10, 'F');
    doc.setTextColor(180, 200, 230);
    doc.setFontSize(7);
    doc.setFont('helvetica', 'normal');
    doc.text(`${board.name} — Meeting Minutes — ${fmtDate()}`, 14, H - 4);
    doc.text(`Page ${i} of ${pageCount}`, W - 14, H - 4, { align: 'right' });
  }

  doc.save(`${board.name.replace(/\s+/g, '_')}_meeting_minutes.pdf`);
}

// ── Excel Meeting Minutes ─────────────────────────────────────────────────────

export function exportToExcel(board, actionItems = [], participants = [], polls = []) {
  const wb = XLSX.utils.book_new();

  // ── Sheet 1: Meeting Overview ──────────────────────────────────────────────
  const facilitator = participants.find((p) => p.role === 'FACILITATOR')?.displayName || '—';
  const overviewData = [
    ['RETROSPECTIVE MEETING MINUTES'],
    [],
    ['Board Name',     board.name || '—'],
    ['Phase',          phaseName(board.phase)],
    ['Facilitator',    facilitator],
    ['Date Exported',  fmtDate()],
    ['Time',           fmtTime()],
    ['Participants',   participants.length],
    ['Total Cards',    (board.cards || []).length],
    ['Action Items',   actionItems.length],
    ['Polls',          polls.filter((p) => p.average != null).length],
  ];
  const ws0 = XLSX.utils.aoa_to_sheet(overviewData);
  ws0['!cols'] = [{ wch: 20 }, { wch: 40 }];
  XLSX.utils.book_append_sheet(wb, ws0, 'Overview');

  // ── Sheet 2: Participants ──────────────────────────────────────────────────
  const partRows = [['#', 'Name', 'Role']];
  participants.forEach((p, i) => partRows.push([i + 1, p.displayName || p.email || '—', p.role || 'MEMBER']));
  const ws1 = XLSX.utils.aoa_to_sheet(partRows);
  ws1['!cols'] = [{ wch: 5 }, { wch: 30 }, { wch: 15 }];
  XLSX.utils.book_append_sheet(wb, ws1, 'Participants');

  // ── Sheet 3: Retro Cards ───────────────────────────────────────────────────
  const cardRows = [['Column', 'Card Text', 'Author', 'Upvotes', 'Downvotes']];
  (board.columns || []).forEach((col) => {
    getCardsForColumn(board, col.id).forEach((c) => {
      cardRows.push([col.name, c.text || '', c.authorName || '—', c.upvotes ?? 0, c.downvotes ?? 0]);
    });
  });
  const ws2 = XLSX.utils.aoa_to_sheet(cardRows);
  ws2['!cols'] = [{ wch: 18 }, { wch: 55 }, { wch: 20 }, { wch: 10 }, { wch: 10 }];
  XLSX.utils.book_append_sheet(wb, ws2, 'Retro Cards');

  // ── Sheet 4: Top Voted ─────────────────────────────────────────────────────
  const topRows = [['Rank', 'Card Text', 'Column', 'Upvotes', 'Downvotes']];
  const colMap  = Object.fromEntries((board.columns || []).map((c) => [c.id, c.name]));
  topVoted(board, 10).forEach((c, i) => {
    topRows.push([`#${i + 1}`, c.text || '', colMap[c.columnId] || '—', c.upvotes ?? 0, c.downvotes ?? 0]);
  });
  const ws3 = XLSX.utils.aoa_to_sheet(topRows);
  ws3['!cols'] = [{ wch: 8 }, { wch: 55 }, { wch: 18 }, { wch: 10 }, { wch: 10 }];
  XLSX.utils.book_append_sheet(wb, ws3, 'Top Voted');

  // ── Sheet 5: Polls ─────────────────────────────────────────────────────────
  const pollRows = [['Poll Question', 'Avg Score', 'Responses', 'Status']];
  polls.forEach((p) => {
    pollRows.push([p.title || '—', p.average != null ? p.average.toFixed(1) : '—', p.responseCount ?? 0, p.status || '—']);
  });
  const ws4 = XLSX.utils.aoa_to_sheet(pollRows);
  ws4['!cols'] = [{ wch: 45 }, { wch: 12 }, { wch: 12 }, { wch: 12 }];
  XLSX.utils.book_append_sheet(wb, ws4, 'Polls');

  // ── Sheet 6: Action Items ──────────────────────────────────────────────────
  const aiRows = [['#', 'Action Item', 'Priority', 'Status', 'Assignee(s)', 'Due Date', 'Source Card']];
  actionItems.forEach((a, i) => {
    aiRows.push([
      i + 1,
      a.title || '',
      a.priority || '—',
      (a.status || '').replace('_', ' '),
      (a.assignees || []).map((u) => u.displayName).join(', ') || '—',
      a.dueDate || '—',
      a.sourceCardText || '—',
    ]);
  });
  const ws5 = XLSX.utils.aoa_to_sheet(aiRows);
  ws5['!cols'] = [{ wch: 5 }, { wch: 45 }, { wch: 10 }, { wch: 15 }, { wch: 25 }, { wch: 12 }, { wch: 40 }];
  XLSX.utils.book_append_sheet(wb, ws5, 'Action Items');

  XLSX.writeFile(wb, `${board.name.replace(/\s+/g, '_')}_meeting_minutes.xlsx`);
}

// ── Word Meeting Minutes ──────────────────────────────────────────────────────

export async function exportToWord(board, actionItems = [], participants = [], polls = []) {
  const DARK   = '1B2B4A';
  const BLUE   = '2B8FE8';
  const PINK   = 'F25C6E';
  const GREEN  = '22C55E';
  const PURPLE = '9B27AF';
  const YELLOW = 'F5A020';

  const h1 = (text, color = DARK) => new Paragraph({
    children: [new TextRun({ text, bold: true, size: 28, color })],
    spacing: { before: 400, after: 150 },
    border: { bottom: { color: color, size: 6, style: BorderStyle.SINGLE } },
  });

  const h2 = (text, color = BLUE) => new Paragraph({
    children: [new TextRun({ text, bold: true, size: 22, color })],
    spacing: { before: 250, after: 100 },
  });

  const para = (text, opts = {}) => new Paragraph({
    children: [new TextRun({ text, size: 20, ...opts })],
    spacing: { after: 80 },
  });

  const bullet = (text) => new Paragraph({
    children: [new TextRun({ text, size: 20 })],
    bullet: { level: 0 },
    spacing: { after: 60 },
  });

  const mkTable = (headers, rows, headerColor = DARK) => new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: [
      new TableRow({
        tableHeader: true,
        children: headers.map((h) => new TableCell({
          children: [new Paragraph({ children: [new TextRun({ text: h, bold: true, color: 'FFFFFF', size: 18 })] })],
          shading: { type: ShadingType.SOLID, color: headerColor, fill: headerColor },
        })),
      }),
      ...rows.map((row, ri) => new TableRow({
        children: row.map((cell) => new TableCell({
          children: [new Paragraph({ children: [new TextRun({ text: String(cell ?? '—'), size: 18 })] })],
          shading: ri % 2 === 0
            ? { type: ShadingType.CLEAR, fill: 'F5F7FC' }
            : { type: ShadingType.CLEAR, fill: 'FFFFFF' },
        })),
      })),
    ],
  });

  const facilitator = participants.find((p) => p.role === 'FACILITATOR')?.displayName || '—';
  const colMap      = Object.fromEntries((board.columns || []).map((c) => [c.id, c.name]));
  const colHex      = [BLUE, PINK, GREEN, PURPLE, YELLOW];

  const children = [
    // ── Title ──────────────────────────────────────────────────────────────
    new Paragraph({
      children: [new TextRun({ text: 'RETROSPECTIVE MEETING MINUTES', bold: true, size: 40, color: DARK })],
      alignment: AlignmentType.CENTER,
      spacing: { after: 100 },
    }),
    new Paragraph({
      children: [new TextRun({ text: board.name || 'Sprint Retro', bold: true, size: 28, color: BLUE })],
      alignment: AlignmentType.CENTER,
      spacing: { after: 80 },
    }),
    new Paragraph({
      children: [new TextRun({ text: fmtDateTime(), size: 18, color: '777777' })],
      alignment: AlignmentType.CENTER,
      spacing: { after: 400 },
    }),

    // ── Overview ───────────────────────────────────────────────────────────
    h1('Meeting Overview'),
    mkTable(
      ['Field', 'Details'],
      [
        ['Board Name',   board.name || '—'],
        ['Phase',        phaseName(board.phase)],
        ['Facilitator',  facilitator],
        ['Participants', String(participants.length)],
        ['Total Cards',  String((board.cards || []).length)],
        ['Action Items', String(actionItems.length)],
        ['Date',         fmtDate()],
        ['Time',         fmtTime()],
      ],
      DARK
    ),

    // ── Participants ───────────────────────────────────────────────────────
    h1('1.  Participants'),
    mkTable(
      ['#', 'Name', 'Role'],
      participants.map((p, i) => [i + 1, p.displayName || p.email || '—', p.role || 'MEMBER']),
      BLUE
    ),

    // ── Retro Cards ────────────────────────────────────────────────────────
    h1('2.  Retrospective Cards'),
    ...(board.columns || []).flatMap((col, idx) => {
      const cards = getCardsForColumn(board, col.id);
      const color = colHex[idx % colHex.length];
      return [
        h2(`${col.name}  (${cards.length} card${cards.length !== 1 ? 's' : ''})`, color),
        cards.length === 0
          ? para('No cards added', { italics: true, color: '999999' })
          : mkTable(
              ['#', 'Card Text', 'Author', 'Up', 'Down'],
              cards.map((c, i) => [i + 1, c.text || '', c.authorName || '—', c.upvotes ?? 0, c.downvotes ?? 0]),
              color
            ),
      ];
    }),

    // ── Top Voted ──────────────────────────────────────────────────────────
    h1('3.  Top Voted Cards'),
    mkTable(
      ['Rank', 'Card Text', 'Column', 'Upvotes', 'Downvotes'],
      topVoted(board, 5).map((c, i) => [
        `#${i + 1}`, c.text || '', colMap[c.columnId] || '—', c.upvotes ?? 0, c.downvotes ?? 0,
      ]),
      YELLOW
    ),

    // ── Polls ──────────────────────────────────────────────────────────────
    ...(polls.filter((p) => p.average != null).length > 0 ? [
      h1('4.  Team Sentiment Polls'),
      mkTable(
        ['Poll Question', 'Avg Score', 'Responses', 'Status'],
        polls.filter((p) => p.average != null).map((p) => [
          p.title || '—',
          p.average != null ? `${p.average.toFixed(1)} / 5` : '—',
          p.responseCount ?? 0,
          p.status || '—',
        ]),
        GREEN
      ),
    ] : []),

    // ── Action Items ───────────────────────────────────────────────────────
    h1('5.  Action Items'),
    actionItems.length === 0
      ? para('No action items recorded.', { italics: true, color: '999999' })
      : mkTable(
          ['#', 'Action Item', 'Priority', 'Status', 'Assignee(s)', 'Due Date'],
          actionItems.map((a, i) => [
            i + 1,
            a.title || '',
            a.priority || '—',
            (a.status || '').replace('_', ' '),
            (a.assignees || []).map((u) => u.displayName).join(', ') || '—',
            a.dueDate || '—',
          ]),
          PURPLE
        ),

    // ── Footer note ────────────────────────────────────────────────────────
    new Paragraph({ spacing: { before: 600 } }),
    new Paragraph({
      children: [new TextRun({ text: `Generated by Retrosphere  •  ${fmtDateTime()}`, size: 16, color: 'AAAAAA', italics: true })],
      alignment: AlignmentType.CENTER,
    }),
  ];

  const doc  = new Document({ sections: [{ properties: {}, children }] });
  const blob = await Packer.toBlob(doc);
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = `${board.name.replace(/\s+/g, '_')}_meeting_minutes.docx`;
  a.click();
  URL.revokeObjectURL(url);
}
