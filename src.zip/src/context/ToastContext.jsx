import { createContext, useContext, useState, useCallback } from 'react';
import { CheckCircle2, AlertCircle, X } from 'lucide-react';

const ToastContext = createContext(null);

let nextId = 0;

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);

  const dismiss = useCallback((id) => setToasts((t) => t.filter((x) => x.id !== id)), []);

  const toast = useCallback((message, type = 'success') => {
    const id = ++nextId;
    setToasts((t) => [...t, { id, message, type }]);
    setTimeout(() => dismiss(id), 3500);
  }, [dismiss]);

  return (
    <ToastContext.Provider value={{ toast }}>
      {children}
      <div className="pointer-events-none fixed bottom-4 right-4 z-[60] flex flex-col gap-2">
        {toasts.map((t) => (
          <div key={t.id}
            className="pointer-events-auto flex items-center gap-2 rounded-lg bg-navy-900 px-4 py-3 text-sm font-medium text-white shadow-lg dark:bg-navy-800">
            {t.type === 'error'
              ? <AlertCircle className="h-4 w-4 text-red-400" />
              : <CheckCircle2 className="h-4 w-4 text-emerald-400" />}
            <span>{t.message}</span>
            <button onClick={() => dismiss(t.id)} className="ml-2 text-navy-400 hover:text-white">
              <X className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  // Fall back to a no-op so components don't crash if used outside the provider.
  return ctx || { toast: () => {} };
}
