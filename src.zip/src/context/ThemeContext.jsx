import { createContext, useContext, useEffect, useState } from 'react';
import { tokenStore } from '../api/tokenStore';
import { authApi } from '../api/endpoints';

const ThemeContext = createContext(null);

function initialTheme() {
  const user = tokenStore.getUser();
  if (user?.themePref) return user.themePref;
  // Fall back to the OS preference (system-preference detection per HLD accessibility).
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

export function ThemeProvider({ children }) {
  const [theme, setTheme] = useState(initialTheme);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
  }, [theme]);

  const toggleTheme = async () => {
    const next = theme === 'dark' ? 'light' : 'dark';
    setTheme(next);
    // Persist as a per-user preference if logged in (best-effort).
    if (tokenStore.getAccess()) {
      try {
        const updated = await authApi.updatePreferences({ theme: next });
        tokenStore.setUser(updated);
      } catch {
        /* ignore */
      }
    }
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>{children}</ThemeContext.Provider>
  );
}

export function useTheme() {
  return useContext(ThemeContext);
}
