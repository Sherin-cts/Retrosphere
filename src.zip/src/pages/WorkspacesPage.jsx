import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Building2, ChevronRight } from 'lucide-react';
import { workspaceApi } from '../api/endpoints';
import { errorMessage } from '../api/client';
import { PageLoader, EmptyState, Modal, ErrorBanner, Spinner } from '../components/ui';

export default function WorkspacesPage() {
  const navigate = useNavigate();
  const [workspaces, setWorkspaces] = useState(null);
  const [error, setError] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);

  const load = async () => {
    try {
      setWorkspaces(await workspaceApi.list());
    } catch (err) {
      setError(errorMessage(err));
    }
  };

  useEffect(() => {
    load();
  }, []);

  const create = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const ws = await workspaceApi.create(name);
      setModalOpen(false);
      setName('');
      navigate(`/workspaces/${ws.id}`);
    } catch (err) {
      setError(errorMessage(err, 'Could not create workspace'));
    } finally {
      setBusy(false);
    }
  };

  if (workspaces === null) return <PageLoader />;

  return (
    <div className="mx-auto max-w-5xl">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-navy-900 dark:text-white">Workspaces</h1>
          <p className="text-sm text-navy-500 dark:text-navy-400">Your teams and their retrospective boards.</p>
        </div>
        <button className="btn-primary" onClick={() => setModalOpen(true)}>
          <Plus className="h-4 w-4" /> New workspace
        </button>
      </div>

      <ErrorBanner message={error} />

      {workspaces.length === 0 ? (
        <EmptyState
          icon={Building2}
          title="No workspaces yet"
          message="Create a workspace to invite your team and start running retrospectives."
          action={<button className="btn-primary" onClick={() => setModalOpen(true)}><Plus className="h-4 w-4" /> New workspace</button>}
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {workspaces.map((ws) => (
            <button
              key={ws.id}
              onClick={() => navigate(`/workspaces/${ws.id}`)}
              className="card group flex items-center justify-between p-5 text-left transition hover:shadow-card-hover"
            >
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-navy-900 text-white">
                  <Building2 className="h-5 w-5" />
                </span>
                <div>
                  <p className="font-semibold text-navy-900 dark:text-white">{ws.name}</p>
                  <span className={`badge mt-1 ${ws.myRole === 'FACILITATOR' ? 'bg-accent-100 text-accent-800' : 'bg-navy-100 text-navy-600'}`}>
                    {ws.myRole}
                  </span>
                </div>
              </div>
              <ChevronRight className="h-5 w-5 text-navy-300 transition group-hover:translate-x-1 group-hover:text-accent-600" />
            </button>
          ))}
        </div>
      )}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="Create workspace">
        <form onSubmit={create} className="space-y-4">
          <ErrorBanner message={error} />
          <div>
            <label className="label">Workspace name</label>
            <input className="input" autoFocus required value={name} onChange={(e) => setName(e.target.value)} placeholder="Platform Team" />
          </div>
          <div className="flex justify-end gap-2">
            <button type="button" className="btn-secondary" onClick={() => setModalOpen(false)}>Cancel</button>
            <button type="submit" className="btn-primary" disabled={busy}>
              {busy ? <Spinner className="h-4 w-4 text-white" /> : 'Create'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
