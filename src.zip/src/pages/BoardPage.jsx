import { useEffect, useState, useCallback, useRef } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import {
  ArrowLeft, Plus, Wifi, WifiOff, Hand, BarChart3, History, FileText, ListChecks, Shield, Pencil, Check, X, Download,
} from 'lucide-react';
import { exportToPdf, exportToExcel, exportToWord } from '../utils/exportBoard';
import { boardApi, cardApi, actionItemApi, workspaceApi, pollApi } from '../api/endpoints';
import JiraPanel from '../components/board/JiraPanel';
import { errorMessage } from '../api/client';
import { useBoardSocket } from '../realtime/useBoardSocket';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { PageLoader, ErrorBanner, Avatar, Spinner } from '../components/ui';
import RetroCard from '../components/board/RetroCard';
import FacilitatorBar from '../components/board/FacilitatorBar';
import ReactionLayer from '../components/board/ReactionLayer';
import PresenceBar from '../components/board/PresenceBar';
import ActionItemsDrawer from '../components/board/ActionItemsDrawer';
import PollCard from '../components/board/PollCard';
import CreatePollModal from '../components/board/CreatePollModal';
import PollHistoryDrawer from '../components/board/PollHistoryDrawer';

export default function BoardPage() {
  const { boardId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();

  const [board, setBoard] = useState(null);
  const [error, setError] = useState('');
  const [timerEvent, setTimerEvent] = useState(null);
  const [flyingReactions, setFlyingReactions] = useState([]);
  const [raisedHands, setRaisedHands] = useState({}); // userId -> displayName
  const [participants, setParticipants] = useState([]); // live roster
  const [actionItems, setActionItems] = useState([]);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [polls, setPolls] = useState([]);
  const [searchText, setSearchText] = useState('');
  const [filterUserId, setFilterUserId] = useState('');
  const [createPollOpen, setCreatePollOpen] = useState(false);
  const [pollHistoryOpen, setPollHistoryOpen] = useState(false);
  const [editingName, setEditingName] = useState(false);
  const [nameDraft, setNameDraft] = useState('');
  const [savingName, setSavingName] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const [jiraPanelOpen, setJiraPanelOpen] = useState(false); //added
  const [sprintInput,   setSprintInput]   = useState('');
  const [activeSprint,  setActiveSprint]  = useState(null);

  const exportRef = useRef(null);
  const reactionId = useRef(0);
  const autoOpenedPhase = useRef(null);

  const isFacilitator = board?.myRole === 'FACILITATOR';
  const actionItemCardIds = new Set(actionItems.map((a) => a.sourceCardId).filter(Boolean));
  const activePolls = polls.filter((p) => p.status !== 'CLOSED');
  const closedPolls = polls.filter((p) => p.status === 'CLOSED');

  const loadPolls = useCallback(() => {
    pollApi.list(boardId).then(setPolls).catch(() => {});
  }, [boardId]);

  // ---- Initial load ----
  const load = useCallback(async () => {
    try {
      setBoard(await boardApi.get(boardId));
    } catch (err) {
      setError(errorMessage(err));
    }
  }, [boardId]);

  useEffect(() => { load(); }, [load]);

  // Action items for this board (powers the drawer + card badges).
  useEffect(() => {
    actionItemApi.dashboard({ boardId }).then(setActionItems).catch(() => {});
  }, [boardId]);

  // Polls for this board (right-side panel + history drawer).
  useEffect(() => { loadPolls(); }, [loadPolls]);

  // ---- Card state helpers ----
  const upsertCard = useCallback((card) => {
    setBoard((b) => {
      if (!b) return b;
      const exists = b.cards.some((c) => c.id === card.id);
      const cards = exists ? b.cards.map((c) => (c.id === card.id ? { ...c, ...card } : c)) : [...b.cards, card];
      return { ...b, cards };
    });
  }, []);

  const patchCard = useCallback((cardId, patch) => {
    setBoard((b) => b && { ...b, cards: b.cards.map((c) => (c.id === cardId ? { ...c, ...patch } : c)) });
  }, []);

  const removeCard = useCallback((cardId) => {
    setBoard((b) => b && { ...b, cards: b.cards.filter((c) => c.id !== cardId) });
  }, []);

  const upsertActionItem = useCallback((item) => {
    setActionItems((arr) => {
      const exists = arr.some((i) => i.id === item.id);
      return exists ? arr.map((i) => (i.id === item.id ? item : i)) : [...arr, item];
    });
  }, []);

  // ---- Real-time events ----
  const onEvent = useCallback((event) => {
    const { type, payload } = event;
    switch (type) {
      case 'card.created':
      case 'card.updated':
      case 'card.moved':
        upsertCard(payload);
        break;
      case 'card.deleted':
        removeCard(payload.cardId);
        break;
      case 'comment.added':
        setBoard((b) => b && {
          ...b,
          cards: b.cards.map((c) => (c.id === payload.cardId ? { ...c, commentCount: (c.commentCount || 0) + 1 } : c)),
        });
        break;
      case 'vote.changed':
        if (payload.upvotes !== undefined) {
          patchCard(payload.cardId, { upvotes: payload.upvotes, downvotes: payload.downvotes });
        }
        break;
      case 'vote.revealed':
        setBoard((b) => {
          if (!b) return b;
          const map = Object.fromEntries((payload.tallies || []).map((t) => [t.cardId, t]));
          return {
            ...b, votesRevealed: true,
            cards: b.cards.map((c) => (map[c.id] ? { ...c, upvotes: map[c.id].upvotes, downvotes: map[c.id].downvotes } : c)),
          };
        });
        break;
      case 'phase.changed':
        setBoard((b) => b && { ...b, phase: payload.phase });
        break;
      case 'voteconfig.changed':
        setBoard((b) => b && { ...b, allowDownvote: payload.allowDownvote, hideVotesUntilReveal: payload.hideVotesUntilReveal });
        break;
      case 'timer.tick':
        setTimerEvent(payload);
        break;
      case 'reaction.added':
        reactionId.current += 1;
        setFlyingReactions((r) => [...r, { id: reactionId.current, emoji: payload.emoji }]);
        break;
      case 'hand.raised':
        setRaisedHands((h) => {
          const next = { ...h };
          if (payload.raised) next[payload.userId] = payload.displayName;
          else delete next[payload.userId];
          return next;
        });
        break;
      case 'presence.updated':
        setParticipants(Array.isArray(payload) ? payload : []);
        break;
      case 'actionitem.created':
      case 'actionitem.updated':
        upsertActionItem(payload);
        break;
      case 'actionitem.deleted':
        setActionItems((arr) => arr.filter((i) => i.id !== payload.actionItemId));
        break;
      case 'poll.created':
      case 'poll.response':
      case 'poll.revealed':
      case 'poll.closed':
        // Lightweight ping -> refetch the permission-filtered poll list.
        loadPolls();
        if (type === 'poll.revealed') toast('Poll results revealed');
        break;
      default:
        break;
    }
  }, [upsertCard, patchCard, removeCard, upsertActionItem, loadPolls, toast]);

  const { connected, sendReaction, sendHand } = useBoardSocket(boardId, onEvent);
  const [handUp, setHandUp] = useState(false);

  // Surface the Action Items panel automatically when discussing / closing out.
  useEffect(() => {
    const phase = board?.phase;
    if ((phase === 'DISCUSS' || phase === 'CLOSED') && autoOpenedPhase.current !== phase) {
      autoOpenedPhase.current = phase;
      setDrawerOpen(true);
    }
  }, [board?.phase]);

  const startEditName = () => { setNameDraft(board.name); setEditingName(true); };
  const saveName = async () => {
    const name = nameDraft.trim();
    if (!name || name === board.name) { setEditingName(false); return; }
    setSavingName(true); setError('');
    try {
      const updated = await boardApi.update(boardId, { name });
      setBoard((b) => b && { ...b, name: updated.name });
      setEditingName(false);
    } catch (err) {
      setError(errorMessage(err, 'Could not rename board'));
    } finally { setSavingName(false); }
  };

  const toggleHand = () => { const next = !handUp; setHandUp(next); sendHand(next); };
  const popReaction = (id) => setFlyingReactions((r) => r.filter((x) => x.id !== id));

  // Close export dropdown on outside click
  useEffect(() => {
    const handler = (e) => { if (exportRef.current && !exportRef.current.contains(e.target)) setExportOpen(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleExport = async (format) => {
    setExportOpen(false);
    if (format === 'pdf') exportToPdf(board, actionItems, participants, polls);
    else if (format === 'excel') exportToExcel(board, actionItems, participants, polls);
    else if (format === 'word') await exportToWord(board, actionItems, participants, polls);
  };

  const onActionItemCreated = useCallback((item) => {
    upsertActionItem(item);
    toast('Action item created');
    setDrawerOpen(true);
  }, [upsertActionItem, toast]);

  const updateActionItemStatus = async (id, status) => {
    try {
      const updated = await actionItemApi.update(id, { status });
      upsertActionItem(updated);
    } catch (err) { toast(errorMessage(err), 'error'); }
  };

  const deleteActionItem = async (id) => {
    if (!confirm('Delete this action item?')) return;
    try {
      await actionItemApi.remove(id);
      setActionItems((arr) => arr.filter((i) => i.id !== id));
      toast('Action item deleted');
    } catch (err) { toast(errorMessage(err), 'error'); }
  };

  const removeParticipant = async (p) => {
    if (!confirm(`Remove ${p.displayName} from this workspace?`)) return;
    try {
      await workspaceApi.removeMember(board.workspace?.id ?? board.workspaceId, p.userId);
      toast(`${p.displayName} removed`);
    } catch (err) { toast(errorMessage(err), 'error'); }
  };

  // ---- Poll handlers ----
  const createPoll = async (title) => {
    await pollApi.create(boardId, title);
    loadPolls();
    toast('Poll created');
  };
  const respondPoll = async (pollId, score) => {
    try { await pollApi.respond(pollId, score); loadPolls(); }
    catch (err) { toast(errorMessage(err), 'error'); }
  };
  const revealPoll = async (pollId) => {
    try { await pollApi.reveal(pollId); loadPolls(); }
    catch (err) { toast(errorMessage(err), 'error'); }
  };
  const closePoll = async (pollId) => {
    try { await pollApi.close(pollId); loadPolls(); }
    catch (err) { toast(errorMessage(err), 'error'); }
  };

  if (error && !board) return (
    <div className="p-8"><ErrorBanner message={error} /><Link className="btn-secondary" to="/workspaces"><ArrowLeft className="h-4 w-4" /> Back</Link></div>
  );
  if (!board) return <div className="flex h-screen items-center justify-center"><PageLoader /></div>;

  const columns = board.columns;
  // Distinct members who authored cards (powers the name filter dropdown).
  const members = Array.from(
    new Map(board.cards.map((c) => [c.authorUserId, c.authorName])).entries()
  ).map(([userId, name]) => ({ userId, name }));
  const q = searchText.trim().toLowerCase();
  const cardsByColumn = (colId) => board.cards
    .filter((c) => c.columnId === colId
      && (!q || (c.text || '').toLowerCase().includes(q))
      && (!filterUserId || String(c.authorUserId) === String(filterUserId)))
    .sort((a, b) => a.position - b.position);
  const handNames = Object.values(raisedHands);

  const addCard = async (columnId, text) => {
    try { upsertCard(await boardApi.addCard(boardId, { columnId, text })); }
    catch (err) { setError(errorMessage(err)); }
  };

  const onDragEnd = async (result) => {
    const { source, destination, draggableId } = result;
    if (!destination) return;
    if (source.droppableId === destination.droppableId && source.index === destination.index) return;
    const cardId = Number(draggableId);
    const destColumnId = Number(destination.droppableId);
    patchCard(cardId, { columnId: destColumnId, position: destination.index });
    try { await cardApi.update(cardId, { columnId: destColumnId, position: destination.index }); }
    catch (err) { setError(errorMessage(err)); load(); }
  };

  return (
    <div className="flex h-screen flex-col bg-navy-50 dark:bg-navy-950">
      {/* Rainbow gradient accent bar */}
      <div className="gradient-bar h-1 w-full shrink-0" />
      {/* Top bar */}
      <header className="flex items-center justify-between gap-3 border-b border-navy-200 bg-white px-4 py-3 dark:border-navy-800 dark:bg-navy-900">
        <div className="flex min-w-0 items-center gap-3">
          <button onClick={() => navigate('/workspaces')} className="btn-ghost px-2"><ArrowLeft className="h-4 w-4" /></button>
          <div className="min-w-0">
            {editingName ? (
              <div className="flex items-center gap-1">
                <input className="input py-1 text-lg font-bold" autoFocus value={nameDraft}
                  onChange={(e) => setNameDraft(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') saveName(); if (e.key === 'Escape') setEditingName(false); }} />
                <button className="btn-primary px-2 py-1" onClick={saveName} disabled={savingName} title="Save">
                  {savingName ? <Spinner className="h-4 w-4 text-white" /> : <Check className="h-4 w-4" />}
                </button>
                <button className="btn-secondary px-2 py-1" onClick={() => setEditingName(false)} title="Cancel"><X className="h-4 w-4" /></button>
              </div>
            ) : (
              <div className="flex items-center gap-1">
                <h1 className="truncate text-lg font-bold text-navy-900 dark:text-white">{board.name}</h1>
                {isFacilitator && (
                  <button className="btn-ghost px-1.5 py-1 text-navy-500" onClick={startEditName} title="Rename board"><Pencil className="h-3.5 w-3.5" /></button>
                )}
                <Link to={`/boards/${boardId}/summary`}
                  className="ml-1 flex items-center gap-1 rounded px-2 py-0.5 text-xs font-medium text-navy-500 hover:bg-navy-100 hover:text-navy-800 dark:hover:bg-navy-700 dark:hover:text-white"
                  title="View summary">
                  <FileText className="h-3.5 w-3.5" /><span className="hidden sm:inline">Summary</span>
                </Link>
              </div>
            )}
            <div className="flex items-center gap-2 text-xs">
              <span className="badge bg-accent-100 text-accent-800">{board.phase}</span>
              <span className={`flex items-center gap-1 ${connected ? 'text-emerald-600' : 'text-navy-400'}`}>
                {connected ? <Wifi className="h-3 w-3" /> : <WifiOff className="h-3 w-3" />}
                {connected ? 'Live' : 'Connecting…'}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Current user identity + role */}
          <div className="hidden items-center gap-2 rounded-full border border-navy-200 bg-white py-1 pl-1 pr-3 dark:border-navy-700 dark:bg-navy-800 md:flex">
            <Avatar name={user?.displayName} size="h-7 w-7" />
            <div className="leading-tight">
              <p className="text-xs font-semibold text-navy-800 dark:text-navy-100">{user?.displayName}</p>
              <p className={`flex items-center gap-0.5 text-[11px] font-medium ${isFacilitator ? 'text-accent-600' : 'text-navy-400'}`}>
                {isFacilitator && <Shield className="h-3 w-3" />}{board.myRole}
              </p>
            </div>
          </div>

          {/* Live presence roster */}
          <PresenceBar participants={participants} currentUserId={user?.id}
            isFacilitator={isFacilitator} onRemove={removeParticipant} />

          {/* Raised hands with hover list */}
          {handNames.length > 0 && (
            <div className="group relative hidden sm:block">
              <span className="flex items-center gap-1 rounded-full bg-amber-100 px-3 py-1 text-xs font-medium text-amber-800">
                <Hand className="h-3 w-3" /> {handNames.length}
              </span>
              <div className="invisible absolute right-0 z-30 mt-1 w-48 rounded-md border border-navy-200 bg-white p-2 text-sm shadow-card-hover group-hover:visible dark:border-navy-700 dark:bg-navy-800">
                <p className="mb-1 text-xs font-semibold uppercase text-navy-400">Hands raised</p>
                {handNames.map((n, i) => <p key={i} className="truncate text-navy-700 dark:text-navy-200">✋ {n}</p>)}
              </div>
            </div>
          )}

          <button onClick={toggleHand} className={handUp ? 'btn-primary' : 'btn-secondary'} title="Raise hand">
            <Hand className="h-4 w-4" />
          </button>
          {isFacilitator && (
            <button onClick={() => setCreatePollOpen(true)} className="btn-secondary" title="Create a poll">
              <BarChart3 className="h-4 w-4" /> <span className="hidden lg:inline">Poll</span>
            </button>
          )}
          <button onClick={() => setPollHistoryOpen(true)} className="btn-secondary" title="Poll history">
            <History className="h-4 w-4" />
            {closedPolls.length > 0 && <span className="ml-1">{closedPolls.length}</span>}
          </button>
          <button onClick={() => setDrawerOpen(true)} className="btn-secondary" title="Action items">
            <ListChecks className="h-4 w-4" />
            {actionItems.length > 0 && <span className="ml-1">{actionItems.length}</span>}
          </button>
          {/* Export dropdown */}
          <button
            onClick={() => setJiraPanelOpen(true)}
            className="btn-secondary flex items-center gap-1.5"
            title="Jira Dashboard"
          >
            <img src="https://wac-cdn.atlassian.com/assets/img/favicons/jira/favicon.png"
                 alt="Jira" className="h-4 w-4"
                 onError={(e) => { e.target.style.display='none'; }} />
            <span className="hidden md:inline">Jira</span>
          </button>

          <div className="relative" ref={exportRef}>
            <button onClick={() => setExportOpen((v) => !v)} className="btn-secondary" title="Export board">
              <Download className="h-4 w-4" /> <span className="hidden md:inline">Export</span>
            </button>
            {exportOpen && (
              <div className="absolute right-0 z-50 mt-1 w-40 overflow-hidden rounded-md border border-navy-200 bg-white shadow-lg dark:border-navy-700 dark:bg-navy-800">
                {[
                  { label: '📄 PDF', fmt: 'pdf' },
                  { label: '📝 Word', fmt: 'word' },
                  { label: '📊 Excel', fmt: 'excel' },
                ].map(({ label, fmt }) => (
                  <button key={fmt} onClick={() => handleExport(fmt)}
                    className="flex w-full items-center gap-2 px-4 py-2 text-left text-sm text-navy-700 hover:bg-navy-100 dark:text-navy-200 dark:hover:bg-navy-700">
                    {label}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </header>

      <FacilitatorBar board={board} isFacilitator={isFacilitator} timerEvent={timerEvent}
        onChanged={setBoard} setError={setError} sendReaction={sendReaction}
        searchText={searchText} setSearchText={setSearchText}
        filterUserId={filterUserId} setFilterUserId={setFilterUserId} members={members} />

      <ErrorBanner message={error} />

      {/* Board area: columns (left/center) + fixed poll panel (right) */}
      <div className="flex flex-1 overflow-hidden">
        <div className="flex-1 overflow-x-auto overflow-y-hidden p-4">
          <DragDropContext onDragEnd={onDragEnd}>
            {/* w-fit + mx-auto centers the columns when they don't fill the width,
                yet still allows horizontal scrolling when there are many columns. */}
            <div className="mx-auto flex h-full w-fit gap-4">
              {columns.map((col, colIndex) => (
                <Column key={col.id} column={col} cards={cardsByColumn(col.id)} board={board}
                  user={user} isFacilitator={isFacilitator} actionItemCardIds={actionItemCardIds}
                  onAddCard={addCard} patchCard={patchCard} removeCard={removeCard}
                  onActionItemCreated={onActionItemCreated} setError={setError} colIndex={colIndex} />
              ))}
            </div>
          </DragDropContext>
        </div>

        {activePolls.length > 0 && (
          <aside className="flex w-80 shrink-0 flex-col border-l border-navy-200 bg-navy-50 dark:border-navy-800 dark:bg-navy-950">
            <div className="flex items-center justify-between border-b border-navy-200 px-4 py-2 dark:border-navy-800">
              <h2 className="flex items-center gap-2 text-sm font-bold text-navy-800 dark:text-navy-100">
                <BarChart3 className="h-4 w-4 text-accent-600" /> Live Polls
              </h2>
              {isFacilitator && (
                <button onClick={() => setCreatePollOpen(true)} className="btn-ghost px-2 py-1 text-xs">
                  <Plus className="h-3.5 w-3.5" /> New
                </button>
              )}
            </div>
            <div className="flex-1 space-y-3 overflow-y-auto p-3">
              {activePolls.map((p) => (
                <PollCard key={p.id} poll={p} isFacilitator={isFacilitator}
                  onRespond={respondPoll} onReveal={revealPoll} onClose={closePoll} />
              ))}
            </div>
          </aside>
        )}
      </div>

      <ReactionLayer reactions={flyingReactions} onDone={popReaction} />
      <ActionItemsDrawer items={actionItems} open={drawerOpen}
        isFacilitator={isFacilitator} currentUserId={user?.id}
        onClose={() => setDrawerOpen(false)} onUpdateStatus={updateActionItemStatus}
        onDelete={deleteActionItem} />
      <PollHistoryDrawer polls={closedPolls} open={pollHistoryOpen} onClose={() => setPollHistoryOpen(false)} />
      {createPollOpen && <CreatePollModal onCreate={createPoll} onClose={() => setCreatePollOpen(false)} />}
      {jiraPanelOpen && <JiraPanel onClose={() => setJiraPanelOpen(false)} />}
    </div>
  );
}

/* ----------------------------- Column ----------------------------- */
const COL_COLORS = ['#2B8FE8', '#F25C6E', '#22C55E', '#9B27AF', '#F5A020'];

function Column({ column, cards, board, user, isFacilitator, actionItemCardIds,
  onAddCard, patchCard, removeCard, onActionItemCreated, setError, colIndex = 0 }) {
  const [adding, setAdding] = useState(false);
  const [text, setText] = useState('');
  const idx = colIndex % 5;
  const accentColor = COL_COLORS[idx];

  const submit = (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    onAddCard(column.id, text.trim());
    setText('');
    setAdding(false);
  };

  return (
    <div className="flex h-full w-80 shrink-0 flex-col rounded-lg bg-navy-100/60 dark:bg-navy-900/60 overflow-hidden">
      <div className={`col-header-${idx} flex items-center justify-between px-3 py-2`}>
        <h3 className="text-sm font-bold uppercase tracking-wide text-navy-700 dark:text-navy-200">{column.name}</h3>
        <span className="badge bg-white text-navy-500 dark:bg-navy-800">{cards.length}</span>
      </div>

      <Droppable droppableId={String(column.id)}>
        {(provided, snapshot) => (
          <div ref={provided.innerRef} {...provided.droppableProps}
            className={`flex-1 space-y-2 overflow-y-auto px-2 pb-2 ${snapshot.isDraggingOver ? 'rounded-md bg-accent-50 dark:bg-navy-800/60' : ''}`}>
            {cards.map((card, idx) => (
              <Draggable key={card.id} draggableId={String(card.id)} index={idx}>
                {(prov, snap) => (
                  <div ref={prov.innerRef} {...prov.draggableProps} {...prov.dragHandleProps}
                    className={snap.isDragging ? 'rotate-1' : ''}>
                    <RetroCard card={card} board={board} user={user} isFacilitator={isFacilitator}
                      hasActionItem={actionItemCardIds.has(card.id)}
                      patchCard={patchCard} removeCard={removeCard}
                      onActionItemCreated={onActionItemCreated} setError={setError}
                      accentColor={accentColor} />
                  </div>
                )}
              </Draggable>
            ))}
            {provided.placeholder}
          </div>
        )}
      </Droppable>

      <div className="p-2">
        {adding ? (
          <form onSubmit={submit} className="space-y-2">
            <textarea autoFocus className="input min-h-[60px] resize-none" value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) submit(e); }}
              placeholder="What's on your mind?" />
            <div className="flex gap-2">
              <button type="submit" className="btn-primary flex-1 py-1.5">Add</button>
              <button type="button" className="btn-secondary py-1.5" onClick={() => { setAdding(false); setText(''); }}>Cancel</button>
            </div>
          </form>
        ) : (
          <button onClick={() => setAdding(true)} className="flex w-full items-center justify-center gap-1 rounded-md border border-dashed border-navy-300 py-2 text-sm font-medium text-navy-500 hover:border-accent-500 hover:text-accent-600 dark:border-navy-700">
            <Plus className="h-4 w-4" /> Add card
          </button>
        )}
      </div>
    </div>
  );
}
