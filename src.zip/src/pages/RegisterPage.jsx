import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { errorMessage } from '../api/client';
import { ErrorBanner, Spinner } from '../components/ui';
import AuthShell from './AuthShell';

export default function RegisterPage() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ displayName: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const onSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      await register(form.email, form.password, form.displayName);
      navigate('/workspaces', { replace: true });
    } catch (err) {
      setError(errorMessage(err, 'Registration failed'));
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthShell>
      <h2 className="text-2xl font-bold text-navy-900 dark:text-white">Create your account</h2>
      <p className="mt-1 text-sm text-navy-500 dark:text-navy-400">Start running retrospectives in minutes.</p>
      <form onSubmit={onSubmit} className="mt-6 space-y-4">
        <ErrorBanner message={error} />
        <div>
          <label className="label">Display name</label>
          <input className="input" required value={form.displayName} onChange={set('displayName')} placeholder="Alex Morgan" />
        </div>
        <div>
          <label className="label">Email</label>
          <input className="input" type="email" autoComplete="email" required value={form.email} onChange={set('email')} placeholder="you@company.com" />
        </div>
        <div>
          <label className="label">Password</label>
          <input className="input" type="password" autoComplete="new-password" minLength={8} required value={form.password} onChange={set('password')} placeholder="At least 8 characters" />
        </div>
        <button type="submit" className="btn-primary w-full" disabled={busy}>
          {busy ? <Spinner className="h-4 w-4 text-white" /> : 'Create account'}
        </button>
      </form>
      <p className="mt-6 text-center text-sm text-navy-500 dark:text-navy-400">
        Already have an account?{' '}
        <Link to="/login" className="font-semibold text-accent-600 hover:text-accent-700">Sign in</Link>
      </p>
    </AuthShell>
  );
}
