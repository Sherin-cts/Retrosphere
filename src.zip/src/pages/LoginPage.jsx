import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { errorMessage } from '../api/client';
import { ErrorBanner, Spinner } from '../components/ui';
import AuthShell from './AuthShell';

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const onSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      await login(email, password);
      const dest = location.state?.from?.pathname || '/workspaces';
      navigate(dest, { replace: true });
    } catch (err) {
      setError(errorMessage(err, 'Login failed'));
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthShell>
      <h2 className="text-2xl font-bold text-navy-900 dark:text-white">Welcome back</h2>
      <p className="mt-1 text-sm text-navy-500 dark:text-navy-400">Sign in to your Retrosphere account.</p>
      <form onSubmit={onSubmit} className="mt-6 space-y-4">
        <ErrorBanner message={error} />
        <div>
          <label className="label">Email</label>
          <input className="input" type="email" autoComplete="email" required
            value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@company.com" />
        </div>
        <div>
          <label className="label">Password</label>
          <input className="input" type="password" autoComplete="current-password" required
            value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
        </div>
        <button type="submit" className="btn-primary w-full" disabled={busy}>
          {busy ? <Spinner className="h-4 w-4 text-white" /> : 'Sign in'}
        </button>
      </form>
      <p className="mt-6 text-center text-sm text-navy-500 dark:text-navy-400">
        New to Retrosphere?{' '}
        <Link to="/register" className="font-semibold text-accent-600 hover:text-accent-700">
          Create an account
        </Link>
      </p>
    </AuthShell>
  );
}
