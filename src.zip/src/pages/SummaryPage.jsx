import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, ThumbsUp, ThumbsDown, Trophy, ListChecks, Calendar, BarChart3, Sparkles, Tag, ChevronDown, ChevronUp, AlertCircle } from 'lucide-react';
import { sessionApi } from '../api/endpoints';
import { errorMessage } from '../api/client';
import { PageLoader, EmptyState, ErrorBanner, Spinner } from '../components/ui';
import { POLL_EMOJI } from '../components/board/PollCard';

const PRIORITY_STYLE = {
  HIGH: 'bg-red-100 text-red-700',
  MED: 'bg-amber-100 text-amber-700',
  LOW: 'bg-navy-100 text-navy-600',
};

// Column accent colours — same 5-colour palette used on the board
const COL_COLORS  = ['#2B8FE8', '#F25C6E', '#22C55E', '#9B27AF', '#F5A020'];
const COL_LIGHT   = ['rgba(43,143,232,0.10)', 'rgba(242,92,110,0.10)', 'rgba(34,197,94,0.10)', 'rgba(155,39,175,0.10)', 'rgba(245,160,32,0.10)'];

export default function SummaryPage() {
  const { boardId } = useParams();
  const navigate = useNavigate();
  const [summary, setSummary]       = useState(null);
  const [error, setError]           = useState('');
  const [aiResult, setAiResult]     = useState(null);   // AI summary result
  const [aiLoading, setAiLoading]   = useState(false);
  const [aiError, setAiError]       = useState('');
  const [aiExpanded, setAiExpanded] = useState(true);

  useEffect(() => {
    sessionApi.summary(boardId).then(setSummary).catch((e) => setError(errorMessage(e)));
  }, [boardId]);

  const generateAiSummary = async () => {
    setAiLoading(true);
    setAiError('');
    setAiResult(null);
    try {
      const result = await sessionApi.aiSummary(boardId);
      setAiResult(result);
      setAiExpanded(true);
    } catch (e) {
      setAiError(errorMessage(e, 'AI summary failed. Check that ANTHROPIC_API_KEY is configured.'));
    } finally {
      setAiLoading(false);
    }
  };

  if (error) return <div className="p-8"><ErrorBanner message={error} /><button className="btn-secondary" onClick={() => navigate(-1)}><ArrowLeft className="h-4 w-4" /> Back</button></div>;
  if (!summary) return <div className="flex h-screen items-center justify-center"><PageLoader /></div>;

  return (
    <div className="min-h-screen bg-navy-50 dark:bg-navy-950">
      <header className="border-b border-navy-200 bg-white px-4 py-4 dark:border-navy-800 dark:bg-navy-900">
        <div className="mx-auto flex max-w-4xl items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate(`/boards/${boardId}`)} className="btn-ghost px-2"><ArrowLeft className="h-4 w-4" /></button>
            <div>
              <p className="text-xs uppercase tracking-wide text-navy-400">Post-retro summary</p>
              <h1 className="text-xl font-bold text-navy-900 dark:text-white">{summary.name}</h1>
            </div>
          </div>

          {/* ✨ Generate AI Summary button */}
          <button
            onClick={generateAiSummary}
            disabled={aiLoading}
            className="flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold text-white shadow-md transition-all hover:brightness-110 disabled:opacity-60"
            style={{ background: 'linear-gradient(135deg, #2B8FE8 0%, #9B27AF 100%)' }}
          >
            {aiLoading
              ? <><Spinner className="h-4 w-4 text-white" /> Generating…</>
              : <><Sparkles className="h-4 w-4" /> {aiResult ? 'Regenerate AI Summary' : 'Generate AI Summary'}</>
            }
          </button>
        </div>
      </header>

      <div className="mx-auto max-w-4xl space-y-8 p-4 md:p-6">

        {/* ── AI Error ───────────────────────────────────────────────────── */}
        {aiError && (
          <div className="flex items-start gap-3 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700 dark:border-red-800 dark:bg-red-950/40 dark:text-red-300">
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
            <span>{aiError}</span>
          </div>
        )}

        {/* ── AI Summary Result ──────────────────────────────────────────── */}
        {aiResult && (
          <section className="rounded-2xl border border-navy-200 dark:border-navy-700 overflow-hidden"
            style={{ background: 'linear-gradient(135deg, rgba(43,143,232,0.06) 0%, rgba(155,39,175,0.06) 100%)' }}>

            {/* Header row */}
            <div className="flex items-center justify-between px-5 py-4"
              style={{ borderBottom: '1px solid rgba(155,39,175,0.15)' }}>
              <h2 className="flex items-center gap-2 text-lg font-bold text-navy-900 dark:text-white">
                <span className="flex h-7 w-7 items-center justify-center rounded-lg text-white"
                  style={{ background: 'linear-gradient(135deg,#2B8FE8,#9B27AF)' }}>
                  <Sparkles className="h-4 w-4" />
                </span>
                AI-Generated Summary
                <span className="rounded-full bg-purple-100 px-2 py-0.5 text-xs font-medium text-purple-700 dark:bg-purple-900/40 dark:text-purple-300">
                  Claude AI
                </span>
              </h2>
              <button onClick={() => setAiExpanded(v => !v)}
                className="rounded p-1 text-navy-400 hover:bg-navy-100 dark:hover:bg-navy-700">
                {aiExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
              </button>
            </div>

            {aiExpanded && (
              <div className="p-5 space-y-5">

                {/* Per-column summaries */}
                {aiResult.columns && aiResult.columns.length > 0 ? (
                  <div className="grid gap-4 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
                    {aiResult.columns.map((col, idx) => {
                      const color = COL_COLORS[idx % COL_COLORS.length];
                      const bg    = COL_LIGHT[idx % COL_LIGHT.length];
                      return (
                        <div key={col.columnName}
                          className="rounded-xl p-4 dark:bg-navy-800/50"
                          style={{ background: bg, borderLeft: `3px solid ${color}` }}>

                          {/* Column name + card count */}
                          <div className="mb-2 flex items-center justify-between">
                            <span className="text-xs font-bold uppercase tracking-wider"
                              style={{ color }}>
                              {col.columnName}
                            </span>
                            <span className="rounded-full px-2 py-0.5 text-xs font-medium text-white"
                              style={{ background: color }}>
                              {col.cardCount} cards
                            </span>
                          </div>

                          {/* Themes */}
                          {col.themes && col.themes.length > 0 && (
                            <div className="mb-3 flex flex-wrap gap-1.5">
                              {col.themes.map((theme) => (
                                <span key={theme}
                                  className="flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-xs font-medium"
                                  style={{ borderColor: color, color }}>
                                  <Tag className="h-2.5 w-2.5" />{theme}
                                </span>
                              ))}
                            </div>
                          )}

                          {/* Summary paragraph */}
                          <p className="text-sm leading-relaxed text-navy-700 dark:text-navy-200">
                            {col.summary}
                          </p>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-sm italic text-navy-500">{aiResult.overallInsight}</p>
                )}

                {/* Overall insight */}
                {aiResult.columns && aiResult.columns.length > 0 && aiResult.overallInsight && (
                  <div className="rounded-xl border border-navy-200 bg-white p-4 dark:border-navy-700 dark:bg-navy-800">
                    <p className="mb-1 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-navy-500 dark:text-navy-400">
                      <Sparkles className="h-3 w-3" /> Overall Team Insight
                    </p>
                    <p className="text-sm leading-relaxed text-navy-800 dark:text-navy-100">
                      {aiResult.overallInsight}
                    </p>
                  </div>
                )}

              </div>
            )}
          </section>
        )}

        {/* ── Loading skeleton while AI is thinking ──────────────────────── */}
        {aiLoading && (
          <section className="rounded-2xl border border-navy-200 p-6 dark:border-navy-700">
            <div className="flex flex-col items-center gap-3 py-6 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full"
                style={{ background: 'linear-gradient(135deg,#2B8FE8,#9B27AF)' }}>
                <Sparkles className="h-6 w-6 animate-pulse text-white" />
              </div>
              <p className="font-semibold text-navy-800 dark:text-navy-100">Claude is reading your retro…</p>
              <p className="text-sm text-navy-500">Grouping themes and crafting insights — usually takes 5–10 seconds</p>
              <div className="mt-2 flex gap-1">
                {[0,1,2].map(i => (
                  <div key={i} className="h-2 w-2 rounded-full animate-bounce"
                    style={{ background: COL_COLORS[i], animationDelay: `${i * 0.15}s` }} />
                ))}
              </div>
            </div>
          </section>
        )}

        <section>
          <h2 className="mb-3 flex items-center gap-2 text-lg font-bold text-navy-900 dark:text-white">
            <Trophy className="h-5 w-5 text-amber-500" /> Top-voted cards
          </h2>
          {summary.topVotedCards.length === 0 ? (
            <EmptyState title="No cards" message="This board has no cards to rank." />
          ) : (
            <ol className="space-y-2">
              {summary.topVotedCards.map((c, i) => (
                <li key={c.cardId} className="card flex items-center gap-4 p-4">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-navy-900 text-sm font-bold text-white">{i + 1}</span>
                  <p className="flex-1 text-sm text-navy-800 dark:text-navy-100">{c.text}</p>
                  <div className="flex items-center gap-3 text-sm font-semibold">
                    <span className="flex items-center gap-1 text-emerald-600"><ThumbsUp className="h-4 w-4" /> {c.upvotes}</span>
                    <span className="flex items-center gap-1 text-rose-500"><ThumbsDown className="h-4 w-4" /> {c.downvotes}</span>
                  </div>
                </li>
              ))}
            </ol>
          )}
        </section>

        <section>
          <h2 className="mb-3 flex items-center gap-2 text-lg font-bold text-navy-900 dark:text-white">
            <BarChart3 className="h-5 w-5 text-accent-600" /> Team sentiment polls
          </h2>
          {(summary.polls || []).length === 0 ? (
            <EmptyState title="No poll results" message="No polls were revealed in this session." />
          ) : (
            <div className="space-y-3">
              {summary.polls.map((p) => {
                const max = Math.max(1, ...(p.distribution || [1]));
                return (
                  <div key={p.id} className="card p-4">
                    <div className="flex items-center justify-between gap-3">
                      <h3 className="font-semibold text-navy-900 dark:text-white">{p.title}</h3>
                      <span className="shrink-0 text-right">
                        <span className="text-2xl font-extrabold text-navy-900 dark:text-white">{p.average != null ? p.average.toFixed(1) : '—'}</span>
                        <span className="ml-1 text-xs text-navy-400">avg · {p.responseCount}</span>
                      </span>
                    </div>
                    <div className="mt-3 space-y-1">
                      {[5, 4, 3, 2, 1].map((n) => {
                        const count = p.distribution ? p.distribution[n - 1] : 0;
                        return (
                          <div key={n} className="flex items-center gap-2">
                            <span className="w-5 text-center text-base">{POLL_EMOJI[n]}</span>
                            <div className="h-3 flex-1 overflow-hidden rounded-full bg-navy-100 dark:bg-navy-700">
                              <div className="h-full rounded-full bg-accent-500" style={{ width: `${(count / max) * 100}%` }} />
                            </div>
                            <span className="w-5 text-right text-xs text-navy-500">{count}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>

        <section>
          <h2 className="mb-3 flex items-center gap-2 text-lg font-bold text-navy-900 dark:text-white">
            <ListChecks className="h-5 w-5 text-accent-600" /> Action items
          </h2>
          {summary.actionItems.length === 0 ? (
            <EmptyState title="No action items" message="Convert cards into action items during the retro to track follow-ups." />
          ) : (
            <div className="space-y-2">
              {summary.actionItems.map((it) => (
                <div key={it.id} className="card flex items-center gap-3 p-4">
                  <span className={`badge ${PRIORITY_STYLE[it.priority]}`}>{it.priority}</span>
                  <p className="flex-1 text-sm text-navy-800 dark:text-navy-100">{it.title}</p>
                  <span className="badge bg-navy-100 text-navy-600 dark:bg-navy-700 dark:text-navy-200">{it.status.replace('_', ' ')}</span>
                  {it.dueDate && <span className="flex items-center gap-1 text-xs text-navy-400"><Calendar className="h-3 w-3" /> {it.dueDate}</span>}
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
