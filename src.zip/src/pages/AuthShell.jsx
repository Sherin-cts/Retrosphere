import { CheckCircle2 } from 'lucide-react';

// Split-screen shell shared by Login and Register: brand panel + form.
export default function AuthShell({ children }) {
  return (
    <div className="flex min-h-screen">
      <div className="relative hidden w-1/2 flex-col justify-between p-12 text-white lg:flex overflow-hidden"
        style={{ background: 'linear-gradient(135deg, #0f2238 0%, #1d3353 30%, #2B8FE8 60%, #9B27AF 100%)' }}>
        {/* Decorative blobs */}
        <div style={{ position: 'absolute', width: 320, height: 320, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(242,92,110,0.25) 0%, transparent 70%)',
          top: '10%', left: '5%', pointerEvents: 'none' }} />
        <div style={{ position: 'absolute', width: 240, height: 240, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(34,197,94,0.20) 0%, transparent 70%)',
          bottom: '15%', right: '8%', pointerEvents: 'none' }} />

        <div className="relative flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl text-lg font-extrabold shadow-lg"
            style={{ background: 'linear-gradient(135deg,#2B8FE8,#9B27AF)' }}>T</span>
          <span className="text-xl font-extrabold tracking-tight">Retrosphere</span>
        </div>
        <div className="relative">
          <h1 className="text-4xl font-extrabold leading-tight">
            Run better<br />
            <span style={{ background: 'linear-gradient(90deg,#F25C6E,#F5A020)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
              retrospectives,
            </span>{' '}
            together.
          </h1>
          <p className="mt-4 max-w-md text-navy-200 opacity-90">
            Structured boards, real-time collaboration, voting, and trackable action items —
            everything your team needs to turn feedback into change.
          </p>
          <ul className="mt-8 space-y-3 text-navy-100">
            {[
              { text: 'Real-time boards & cards',         color: '#2B8FE8' },
              { text: 'Vote and prioritize what matters', color: '#22C55E' },
              { text: 'Track action items across sprints',color: '#F5A020' },
            ].map(({ text, color }) => (
              <li key={text} className="flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5 shrink-0" style={{ color }} /> {text}
              </li>
            ))}
          </ul>

          {/* Colour strip preview */}
          <div className="mt-10 flex gap-2">
            {['#2B8FE8','#9B27AF','#F25C6E','#22C55E','#F5A020'].map((c) => (
              <span key={c} className="h-2 flex-1 rounded-full opacity-80" style={{ background: c }} />
            ))}
          </div>
        </div>
        <p className="relative text-xs text-navy-400">© {new Date().getFullYear()} Retrosphere · Cognizant</p>
      </div>

      <div className="flex w-full items-center justify-center p-6 lg:w-1/2">
        <div className="w-full max-w-sm">{children}</div>
      </div>
    </div>
  );
}
