import { useEffect, useState, useCallback, useRef } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  Plus, LayoutGrid, Users, FileStack, Archive, Trash2, ArrowLeft, UserPlus, Shield, Check, ListChecks, Pencil, X, GripVertical,
} from 'lucide-react';
import { workspaceApi, boardApi, userApi } from '../api/endpoints';
import { errorMessage } from '../api/client';
import { PageLoader, EmptyState, Modal, ErrorBanner, Spinner, Avatar } from '../components/ui';
import { useAuth } from '../context/AuthContext';
import ActionItemsListModal from '../components/ActionItemsListModal';

const TABS = [
  { key: 'boards', label: 'Boards', icon: LayoutGrid },
  { key: 'members', label: 'Members', icon: Users },
  { key: 'templates', label: 'Templates', icon: FileStack },
];

export default function WorkspacePage() {
  const { workspaceId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [ws, setWs] = useState(null);
  const [tab, setTab] = useState('boards');
  const [error, setError] = useState('');
  const [editing, setEditing] = useState(false);
  const [nameDraft, setNameDraft] = useState('');
  const [savingName, setSavingName] = useState(false);

  const isFacilitator = ws?.myRole === 'FACILITATOR';

  const startEdit = () => { setNameDraft(ws.name); setEditing(true); };

  const saveName = async () => {
    const name = nameDraft.trim();
    if (!name || name === ws.name) { setEditing(false); return; }
    setSavingName(true); setError('');
    try {
      const updated = await workspaceApi.update(workspaceId, name);
      setWs((w) => ({ ...w, name: updated.name }));
      setEditing(false);
    } catch (err) {
      setError(errorMessage(err, 'Could not rename workspace'));
    } finally { setSavingName(false); }
  };

  const load = useCallback(async () => {
    try {
      const all = await workspaceApi.list();
      const found = all.find((w) => String(w.id) === String(workspaceId));
      if (!found) { setError('Workspace not found or you are not a member.'); return; }
      setWs(found);
    } catch (err) {
      setError(errorMessage(err));
    }
  }, [workspaceId]);

  useEffect(() => { load(); }, [load]);

  if (error && !ws) return <div className="mx-auto max-w-5xl"><ErrorBanner message={error} /><Link to="/workspaces" className="btn-secondary"><ArrowLeft className="h-4 w-4" /> Back</Link></div>;
  if (!ws) return <PageLoader />;

  return (
    <div className="mx-auto max-w-5xl">
      <Link to="/workspaces" className="mb-3 inline-flex items-center gap-1 text-sm text-navy-500 hover:text-accent-600">
        <ArrowLeft className="h-4 w-4" /> All workspaces
      </Link>
      <div className="mb-6 flex items-center gap-3">
        <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-navy-900 text-white"><LayoutGrid className="h-5 w-5" /></span>
        <div>
          {editing ? (
            <div className="flex items-center gap-2">
              <input className="input text-2xl font-bold" autoFocus value={nameDraft}
                onChange={(e) => setNameDraft(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') saveName(); if (e.key === 'Escape') setEditing(false); }} />
              <button className="btn-primary px-2" onClick={saveName} disabled={savingName} title="Save">
                {savingName ? <Spinner className="h-4 w-4 text-white" /> : <Check className="h-4 w-4" />}
              </button>
              <button className="btn-secondary px-2" onClick={() => setEditing(false)} title="Cancel"><X className="h-4 w-4" /></button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-navy-900 dark:text-white">{ws.name}</h1>
              {isFacilitator && (
                <button className="btn-ghost px-2 text-navy-500" onClick={startEdit} title="Rename workspace"><Pencil className="h-4 w-4" /></button>
              )}
            </div>
          )}
          <span className={`badge ${isFacilitator ? 'bg-accent-100 text-accent-800' : 'bg-navy-100 text-navy-600'}`}>You are {ws.myRole}</span>
        </div>
      </div>

      <div className="mb-6 flex gap-1 border-b border-navy-200 dark:border-navy-800">
        {TABS.map((t) => (
          <button key={t.key} onClick={() => setTab(t.key)}
            className={`flex items-center gap-2 border-b-2 px-4 py-2 text-sm font-medium ${
              tab === t.key ? 'border-accent-600 text-accent-700 dark:text-accent-400' : 'border-transparent text-navy-500 hover:text-navy-800 dark:hover:text-navy-200'
            }`}>
            <t.icon className="h-4 w-4" /> {t.label}
          </button>
        ))}
      </div>

      <ErrorBanner message={error} />

      {tab === 'boards' && <BoardsTab workspaceId={workspaceId} isFacilitator={isFacilitator} navigate={navigate} />}
      {tab === 'members' && <MembersTab workspaceId={workspaceId} isFacilitator={isFacilitator} currentUserId={user?.id} />}
      {tab === 'templates' && <TemplatesTab workspaceId={workspaceId} isFacilitator={isFacilitator} />}
    </div>
  );
}

/* ----------------------------- Boards ----------------------------- */
function BoardsTab({ workspaceId, isFacilitator, navigate }) {
  const [status, setStatus] = useState('active');
  const [boards, setBoards] = useState(null);
  const [error, setError] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [actionsBoard, setActionsBoard] = useState(null); // board whose action items are shown

  const load = useCallback(async () => {
    try { setBoards(await workspaceApi.boards(workspaceId, status)); }
    catch (err) { setError(errorMessage(err)); }
  }, [workspaceId, status]);

  useEffect(() => { setBoards(null); load(); }, [load]);

  const archive = async (id) => {
    if (!confirm('Archive this board?')) return;
    try { await boardApi.archive(id); load(); } catch (err) { setError(errorMessage(err)); }
  };

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <div className="flex gap-1 rounded-md bg-navy-100 p-1 dark:bg-navy-800">
          {['active', 'archived'].map((s) => (
            <button key={s} onClick={() => setStatus(s)}
              className={`rounded px-3 py-1 text-sm font-medium capitalize ${status === s ? 'bg-white text-navy-900 shadow-sm dark:bg-navy-700 dark:text-white' : 'text-navy-500'}`}>
              {s}
            </button>
          ))}
        </div>
        {isFacilitator && <button className="btn-primary" onClick={() => setModalOpen(true)}><Plus className="h-4 w-4" /> New board</button>}
      </div>

      <ErrorBanner message={error} />
      {boards === null ? <PageLoader /> : boards.length === 0 ? (
        <EmptyState icon={LayoutGrid} title={`No ${status} boards`}
          message={isFacilitator ? 'Create a board to start a retrospective session.' : 'No boards to show yet.'}
          action={isFacilitator && status === 'active' ? <button className="btn-primary" onClick={() => setModalOpen(true)}><Plus className="h-4 w-4" /> New board</button> : null} />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {boards.map((b) => (
            <div key={b.id} className="card flex flex-col p-5">
              <button onClick={() => navigate(`/boards/${b.id}`)} className="flex-1 text-left">
                <p className="font-semibold text-navy-900 dark:text-white">{b.name}</p>
                <div className="mt-2 flex items-center gap-2">
                  <span className="badge bg-navy-100 text-navy-600 dark:bg-navy-700 dark:text-navy-200">{b.phase}</span>
                  <span className="text-xs text-navy-400">{new Date(b.createdAt).toLocaleDateString()}</span>
                </div>
              </button>
              <div className="mt-4 flex gap-2">
                <button className="btn-secondary flex-1" onClick={() => navigate(`/boards/${b.id}`)}>Open</button>
                <button className="btn-secondary px-2" onClick={() => setActionsBoard(b)} title="Action items for this session"><ListChecks className="h-4 w-4" /></button>
                <button className="btn-secondary px-2" onClick={() => navigate(`/boards/${b.id}/summary`)} title="Summary"><FileStack className="h-4 w-4" /></button>
                {isFacilitator && status === 'active' && (
                  <button className="btn-ghost px-2 text-red-600" onClick={() => archive(b.id)} title="Archive"><Archive className="h-4 w-4" /></button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {modalOpen && <CreateBoardModal workspaceId={workspaceId} onClose={() => setModalOpen(false)} onCreated={(id) => navigate(`/boards/${id}`)} />}
      {actionsBoard && (
        <ActionItemsListModal boardId={actionsBoard.id} boardName={actionsBoard.name}
          isFacilitator={isFacilitator} onClose={() => setActionsBoard(null)} />
      )}
    </div>
  );
}

function CreateBoardModal({ workspaceId, onClose, onCreated }) {
  const [name, setName] = useState('');
  const [mode, setMode] = useState('template');
  const [templates, setTemplates] = useState([]);
  const [templateId, setTemplateId] = useState('');
  const [columnsText, setColumnsText] = useState('Start, Stop, Continue');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    workspaceApi.templates(workspaceId).then((t) => {
      setTemplates(t);
      if (t[0]) setTemplateId(String(t[0].id));
    }).catch(() => {});
  }, [workspaceId]);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setError('');
    try {
      const body = { name, workspaceId: Number(workspaceId) };
      if (mode === 'template') body.templateId = Number(templateId);
      else body.columns = columnsText.split(',').map((c) => c.trim()).filter(Boolean);
      const board = await boardApi.create(body);
      onCreated(board.id);
    } catch (err) {
      setError(errorMessage(err, 'Could not create board'));
    } finally { setBusy(false); }
  };

  return (
    <Modal open onClose={onClose} title="New retrospective board">
      <form onSubmit={submit} className="space-y-4">
        <ErrorBanner message={error} />
        <div>
          <label className="label">Board name</label>
          <input className="input" autoFocus required value={name} onChange={(e) => setName(e.target.value)} placeholder="Sprint 24 Retro" />
        </div>
        <div className="flex gap-1 rounded-md bg-navy-100 p-1 dark:bg-navy-800">
          {[['template', 'Use a template'], ['custom', 'Custom columns']].map(([k, l]) => (
            <button type="button" key={k} onClick={() => setMode(k)}
              className={`flex-1 rounded px-3 py-1 text-sm font-medium ${mode === k ? 'bg-white text-navy-900 shadow-sm dark:bg-navy-700 dark:text-white' : 'text-navy-500'}`}>{l}</button>
          ))}
        </div>
        {mode === 'template' ? (
          <div>
            <label className="label">Template</label>
            <select className="input" value={templateId} onChange={(e) => setTemplateId(e.target.value)}>
              {templates.map((t) => (
                <option key={t.id} value={t.id}>{t.name} — {t.columns.join(' / ')}</option>
              ))}
            </select>
          </div>
        ) : (
          <div>
            <label className="label">Columns (comma-separated)</label>
            <input className="input" value={columnsText} onChange={(e) => setColumnsText(e.target.value)} />
          </div>
        )}
        <div className="flex justify-end gap-2">
          <button type="button" className="btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn-primary" disabled={busy}>{busy ? <Spinner className="h-4 w-4 text-white" /> : 'Create board'}</button>
        </div>
      </form>
    </Modal>
  );
}

/* ----------------------------- Members ----------------------------- */
function MembersTab({ workspaceId, isFacilitator, currentUserId }) {
  const [members, setMembers] = useState(null);
  const [error, setError] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [role, setRole] = useState('MEMBER');
  // name-search picker state
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [addedIds, setAddedIds] = useState([]);

  const load = useCallback(async () => {
    try { setMembers(await workspaceApi.members(workspaceId)); }
    catch (err) { setError(errorMessage(err)); }
  }, [workspaceId]);
  useEffect(() => { load(); }, [load]);

  // Debounced user search: names starting with the typed text.
  useEffect(() => {
    if (!modalOpen) return undefined;
    if (query.trim().length < 1) { setResults([]); return undefined; }
    setSearching(true);
    const t = setTimeout(async () => {
      try { setResults(await userApi.search(query.trim())); }
      catch { /* ignore */ }
      finally { setSearching(false); }
    }, 250);
    return () => clearTimeout(t);
  }, [query, modalOpen]);

  const existingIds = new Set((members || []).map((m) => m.userId));

  const addPerson = async (person) => {
    setError('');
    try {
      await workspaceApi.invite(workspaceId, person.email, role);
      setAddedIds((a) => [...a, person.id]);
      load();
    } catch (err) { setError(errorMessage(err, 'Could not add member')); }
  };

  const openModal = () => { setQuery(''); setResults([]); setAddedIds([]); setRole('MEMBER'); setModalOpen(true); };

  const changeRole = async (userId, newRole) => {
    try { await workspaceApi.changeRole(workspaceId, userId, newRole); load(); }
    catch (err) { setError(errorMessage(err)); }
  };
  const remove = async (userId) => {
    if (!confirm('Remove this member?')) return;
    try { await workspaceApi.removeMember(workspaceId, userId); load(); }
    catch (err) { setError(errorMessage(err)); }
  };

  if (members === null) return <PageLoader />;
  return (
    <div>
      {isFacilitator && (
        <div className="mb-4 flex justify-end">
          <button className="btn-primary" onClick={openModal}><UserPlus className="h-4 w-4" /> Add member</button>
        </div>
      )}
      <ErrorBanner message={error} />
      <div className="card divide-y divide-navy-100 dark:divide-navy-700">
        {members.map((m) => (
          <div key={m.userId} className="flex items-center gap-3 p-4">
            <Avatar name={m.displayName} />
            <div className="min-w-0 flex-1">
              <p className="truncate font-medium text-navy-900 dark:text-white">{m.displayName}{m.userId === currentUserId && <span className="ml-2 text-xs text-navy-400">(you)</span>}</p>
              <p className="truncate text-sm text-navy-500">{m.email}</p>
            </div>
            {isFacilitator ? (
              <select className="input w-36" value={m.role} onChange={(e) => changeRole(m.userId, e.target.value)}>
                <option value="MEMBER">Member</option>
                <option value="FACILITATOR">Facilitator</option>
              </select>
            ) : (
              <span className={`badge ${m.role === 'FACILITATOR' ? 'bg-accent-100 text-accent-800' : 'bg-navy-100 text-navy-600'}`}>
                <Shield className="mr-1 h-3 w-3" />{m.role}
              </span>
            )}
            {isFacilitator && m.userId !== currentUserId && (
              <button className="btn-ghost px-2 text-red-600" onClick={() => remove(m.userId)} title="Remove"><Trash2 className="h-4 w-4" /></button>
            )}
          </div>
        ))}
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="Add member">
        <div className="space-y-4">
          <ErrorBanner message={error} />
          <div>
            <label className="label">Add as</label>
            <select className="input" value={role} onChange={(e) => setRole(e.target.value)}>
              <option value="MEMBER">Member</option>
              <option value="FACILITATOR">Facilitator</option>
            </select>
          </div>
          <div>
            <label className="label">Search people by name</label>
            <input className="input" autoFocus value={query} onChange={(e) => setQuery(e.target.value)}
              placeholder="Start typing a name… e.g. Ra" />
          </div>

          <div className="max-h-64 space-y-1 overflow-y-auto">
            {searching && <div className="flex justify-center py-3"><Spinner className="h-4 w-4" /></div>}
            {!searching && query.trim().length >= 1 && results.length === 0 && (
              <p className="py-3 text-center text-sm text-navy-400">No users whose name starts with “{query.trim()}”.</p>
            )}
            {results.map((p) => {
              const already = existingIds.has(p.id) || addedIds.includes(p.id);
              return (
                <div key={p.id} className="flex items-center gap-2 rounded-md p-2 hover:bg-navy-50 dark:hover:bg-navy-700">
                  <Avatar name={p.displayName} size="h-7 w-7" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-navy-800 dark:text-navy-100">{p.displayName}</p>
                    <p className="truncate text-xs text-navy-400">{p.email}</p>
                  </div>
                  <button disabled={already} onClick={() => addPerson(p)}
                    className={already ? 'btn-ghost text-emerald-600' : 'btn-primary px-2 py-1'}>
                    {already ? <><Check className="h-4 w-4" /> Added</> : <><Plus className="h-4 w-4" /> Add</>}
                  </button>
                </div>
              );
            })}
          </div>

          <div className="flex justify-end">
            <button type="button" className="btn-secondary" onClick={() => setModalOpen(false)}>Done</button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

/* ── ColumnEditor — drag-to-reorder list of column name inputs ── */
function ColumnEditor({ columns, onChange }) {
  const dragIdx = useRef(null);
  const dragOverIdx = useRef(null);

  const addColumn = () => onChange([...columns, '']);

  const updateColumn = (i, val) => {
    const next = [...columns];
    next[i] = val;
    onChange(next);
  };

  const removeColumn = (i) => onChange(columns.filter((_, idx) => idx !== i));

  const onDragStart = (i) => { dragIdx.current = i; };

  const onDragEnter = (i) => { dragOverIdx.current = i; };

  const onDragEnd = () => {
    const from = dragIdx.current;
    const to   = dragOverIdx.current;
    if (from === null || to === null || from === to) return;
    const next = [...columns];
    const [moved] = next.splice(from, 1);
    next.splice(to, 0, moved);
    dragIdx.current     = null;
    dragOverIdx.current = null;
    onChange(next);
  };

  return (
    <div className="space-y-2">
      {columns.map((col, i) => (
        <div
          key={i}
          draggable
          onDragStart={() => onDragStart(i)}
          onDragEnter={() => onDragEnter(i)}
          onDragEnd={onDragEnd}
          onDragOver={(e) => e.preventDefault()}
          className="flex items-center gap-2 rounded-lg border border-navy-200 dark:border-navy-600 bg-white dark:bg-navy-800 px-2 py-1.5 cursor-grab active:cursor-grabbing shadow-sm"
        >
          <GripVertical className="h-4 w-4 text-navy-400 flex-shrink-0" />
          <span className="text-xs font-medium text-navy-400 w-5 text-center flex-shrink-0">{i + 1}</span>
          <input
            className="flex-1 bg-transparent text-sm text-navy-900 dark:text-white outline-none placeholder-navy-400"
            value={col}
            onChange={(e) => updateColumn(i, e.target.value)}
            placeholder={`Column ${i + 1} name`}
            required
            onMouseDown={(e) => e.stopPropagation()}
          />
          {columns.length > 1 && (
            <button
              type="button"
              onClick={() => removeColumn(i)}
              className="text-red-400 hover:text-red-600 flex-shrink-0"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
      ))}
      <button
        type="button"
        onClick={addColumn}
        className="flex items-center gap-1.5 text-sm text-accent-600 hover:text-accent-700 font-medium mt-1"
      >
        <Plus className="h-4 w-4" /> Add column
      </button>
    </div>
  );
}

/* ----------------------------- Templates ----------------------------- */
function TemplatesTab({ workspaceId, isFacilitator }) {
  const [templates, setTemplates] = useState(null);
  const [error, setError]         = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [name, setName]           = useState('');
  const [columns, setColumns]     = useState(['', '', '']);
  const [busy, setBusy]           = useState(false);

  const load = useCallback(async () => {
    try { setTemplates(await workspaceApi.templates(workspaceId)); }
    catch (err) { setError(errorMessage(err)); }
  }, [workspaceId]);
  useEffect(() => { load(); }, [load]);

  const openModal = () => { setName(''); setColumns(['', '', '']); setError(''); setModalOpen(true); };

  const create = async (e) => {
    e.preventDefault();
    const trimmed = columns.map((c) => c.trim()).filter(Boolean);
    if (trimmed.length === 0) { setError('Add at least one column.'); return; }
    setBusy(true); setError('');
    try {
      await workspaceApi.createTemplate(workspaceId, { name, columns: trimmed });
      setModalOpen(false); load();
    } catch (err) { setError(errorMessage(err, 'Could not create template')); }
    finally { setBusy(false); }
  };

  if (templates === null) return <PageLoader />;
  return (
    <div>
      {isFacilitator && (
        <div className="mb-4 flex justify-end">
          <button className="btn-primary" onClick={openModal}><Plus className="h-4 w-4" /> New template</button>
        </div>
      )}
      <ErrorBanner message={error} />
      <div className="grid gap-4 sm:grid-cols-2">
        {templates.map((t) => (
          <div key={t.id} className="card p-5">
            <div className="flex items-center justify-between">
              <p className="font-semibold text-navy-900 dark:text-white">{t.name}</p>
              <span className={`badge ${t.builtIn ? 'bg-navy-100 text-navy-600' : 'bg-emerald-100 text-emerald-700'}`}>{t.builtIn ? 'Built-in' : 'Custom'}</span>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              {t.columns.map((c, i) => (
                <span key={i} className="badge bg-accent-50 text-accent-700 dark:bg-navy-700 dark:text-navy-200">
                  <span className="mr-1 text-accent-400 text-xs">{i + 1}.</span>{c}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="New template">
        <form onSubmit={create} className="space-y-4">
          <ErrorBanner message={error} />
          <div>
            <label className="label">Template name</label>
            <input className="input" required value={name} onChange={(e) => setName(e.target.value)} placeholder="Mad / Sad / Glad" />
          </div>
          <div>
            <label className="label mb-2 block">
              Columns
              <span className="ml-2 text-xs font-normal text-navy-400">drag to reorder</span>
            </label>
            <ColumnEditor columns={columns} onChange={setColumns} />
          </div>
          <div className="flex justify-end gap-2">
            <button type="button" className="btn-secondary" onClick={() => setModalOpen(false)}>Cancel</button>
            <button type="submit" className="btn-primary" disabled={busy}>{busy ? <Spinner className="h-4 w-4 text-white" /> : 'Create'}</button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
