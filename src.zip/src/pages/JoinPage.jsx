import { useEffect, useState, useRef } from 'react';
import { useParams, useSearchParams, useNavigate } from 'react-router-dom';
import { sessionApi } from '../api/endpoints';
import { errorMessage } from '../api/client';
import { Spinner } from '../components/ui';

// Redeems an invite token (link or email) and joins the board, then opens it.
export default function JoinPage() {
  const { boardId } = useParams();
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const token = params.get('token');
  const [error, setError] = useState('');
  const ran = useRef(false);

  useEffect(() => {
    if (ran.current) return; // guard against StrictMode double-invoke
    ran.current = true;
    if (!token) { setError('Missing invite token.'); return; }
    sessionApi.join(boardId, token)
      .then(() => navigate(`/boards/${boardId}`, { replace: true }))
      .catch((e) => setError(errorMessage(e, 'Could not join the board')));
  }, [boardId, token, navigate]);

  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-navy-50 p-6 dark:bg-navy-950">
      {error ? (
        <>
          <p className="text-lg font-semibold text-red-600">{error}</p>
          <button className="btn-secondary" onClick={() => navigate('/workspaces')}>Go to workspaces</button>
        </>
      ) : (
        <>
          <Spinner className="h-8 w-8" />
          <p className="text-navy-500">Joining the board…</p>
        </>
      )}
    </div>
  );
}
