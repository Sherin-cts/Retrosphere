import { useEffect, useState, useCallback } from 'react';
import { ListChecks, Calendar, Trash2 } from 'lucide-react';
import { actionItemApi } from '../api/endpoints';
import { errorMessage } from '../api/client';
import { PageLoader, EmptyState, ErrorBanner, Avatar } from '../components/ui';
import { useAuth } from '../context/AuthContext';

const STATUSES = ['OPEN', 'IN_PROGRESS', 'DONE', 'CANCELLED'];
const PRIORITY_STYLE = {
  HIGH: 'bg-red-100 text-red-700',
  MED: 'bg-amber-100 text-amber-700',
  LOW: 'bg-navy-100 text-navy-600',
};
const STATUS_STYLE = {
  OPEN: 'bg-navy-100 text-navy-700',
  IN_PROGRESS: 'bg-accent-100 text-accent-800',
  DONE: 'bg-emerald-100 text-emerald-700',
  CANCELLED: 'bg-navy-100 text-navy-400 line-through',
};

export default function ActionItemsPage() {
  const { user } = useAuth();
  const [items, setItems] = useState(null);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState('ALL');

  const load = useCallback(async () => {
    try { setItems(await actionItemApi.mine()); }
    catch (err) { setError(errorMessage(err)); }
  }, []);
  useEffect(() => { load(); }, [load]);

  const updateStatus = async (id, status) => {
    try { const updated = await actionItemApi.update(id, { status }); setItems((arr) => arr.map((i) => (i.id === id ? updated : i))); }
    catch (err) { setError(errorMessage(err)); }
  };
  const remove = async (id) => {
    if (!confirm('Delete this action item?')) return;
    try { await actionItemApi.remove(id); setItems((arr) => arr.filter((i) => i.id !== id)); }
    catch (err) { setError(errorMessage(err)); }
  };

  if (items === null) return <PageLoader />;
  const shown = filter === 'ALL' ? items : items.filter((i) => i.status === filter);

  return (
    <div className="mx-auto max-w-4xl">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-navy-900 dark:text-white">My action items</h1>
        <p className="text-sm text-navy-500 dark:text-navy-400">Items assigned to you, across every board.</p>
      </div>

      <div className="mb-4 flex flex-wrap gap-1">
        {['ALL', ...STATUSES].map((s) => (
          <button key={s} onClick={() => setFilter(s)}
            className={`rounded-full px-3 py-1 text-xs font-semibold ${filter === s ? 'bg-accent-600 text-white' : 'bg-navy-100 text-navy-600 hover:bg-navy-200 dark:bg-navy-800 dark:text-navy-300'}`}>
            {s.replace('_', ' ')}
          </button>
        ))}
      </div>

      <ErrorBanner message={error} />

      {shown.length === 0 ? (
        <EmptyState icon={ListChecks} title="Nothing here" message="Action items created from retro cards will appear here." />
      ) : (
        <div className="space-y-3">
          {shown.map((it) => (
            <div key={it.id} className="card flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className={`badge ${PRIORITY_STYLE[it.priority]}`}>{it.priority}</span>
                  <p className="font-medium text-navy-900 dark:text-white">{it.title}</p>
                </div>
                <div className="mt-2 flex flex-wrap items-center gap-3 text-xs text-navy-500">
                  {it.dueDate && <span className="flex items-center gap-1"><Calendar className="h-3 w-3" /> {it.dueDate}</span>}
                  <div className="flex items-center gap-1">
                    {it.assignees.map((a) => <Avatar key={a.userId} name={a.displayName} size="h-5 w-5" />)}
                    {it.assignees.length === 0 && <span className="text-navy-400">Unassigned</span>}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <select className={`input w-36 ${STATUS_STYLE[it.status]}`} value={it.status} onChange={(e) => updateStatus(it.id, e.target.value)}>
                  {STATUSES.map((s) => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
                </select>
                {it.createdByUserId === user?.id && (
                  <button className="btn-ghost px-2 text-red-600" onClick={() => remove(it.id)} title="Delete"><Trash2 className="h-4 w-4" /></button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
