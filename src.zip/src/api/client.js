import axios from 'axios';
import { tokenStore } from './tokenStore';

// All REST calls go through this instance (proxied to the backend in dev).
const api = axios.create({ baseURL: '/api/v1' });

// Attach the access token to every request.
api.interceptors.request.use((config) => {
  const token = tokenStore.getAccess();
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Single-flight refresh: if many requests 401 at once, only one refresh call runs.
let refreshPromise = null;

function notifyLogout() {
  tokenStore.clear();
  window.dispatchEvent(new Event('auth:logout'));
}

async function runRefresh() {
  const refreshToken = tokenStore.getRefresh();
  if (!refreshToken) throw new Error('no refresh token');
  // Use a bare axios call so we don't recurse through these interceptors.
  const { data } = await axios.post('/api/v1/auth/refresh', { refreshToken });
  tokenStore.set(data);
  return data.accessToken;
}

api.interceptors.response.use(
  (res) => res,
  async (error) => {
    const original = error.config;
    const status = error.response?.status;

    // Don't try to refresh the auth endpoints themselves.
    const isAuthCall = original?.url?.includes('/auth/');

    if (status === 401 && !original._retried && !isAuthCall) {
      original._retried = true;
      try {
        if (!refreshPromise) {
          refreshPromise = runRefresh().finally(() => {
            refreshPromise = null;
          });
        }
        const newToken = await refreshPromise;
        original.headers.Authorization = `Bearer ${newToken}`;
        return api(original);
      } catch {
        notifyLogout();
      }
    }
    return Promise.reject(error);
  }
);

// Extracts a human-readable message from an axios error.
export function errorMessage(err, fallback = 'Something went wrong') {
  return err?.response?.data?.message || err?.message || fallback;
}

export default api;
