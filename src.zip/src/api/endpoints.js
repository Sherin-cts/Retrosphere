import api from './client';

// ---- Auth & user (Module 5) ----
export const authApi = {
  register: (body) => api.post('/auth/register', body).then((r) => r.data),
  login: (body) => api.post('/auth/login', body).then((r) => r.data),
  logout: (refreshToken) => api.post('/auth/logout', { refreshToken }),
  me: () => api.get('/users/me').then((r) => r.data),
  updatePreferences: (body) => api.patch('/users/me/preferences', body).then((r) => r.data),
};

export const userApi = {
  search: (q) => api.get('/users/search', { params: { q } }).then((r) => r.data),
};

// ---- Workspaces & members (Module 5) ----
export const workspaceApi = {
  list: () => api.get('/workspaces').then((r) => r.data),
  create: (name) => api.post('/workspaces', { name }).then((r) => r.data),
  update: (id, name) => api.patch(`/workspaces/${id}`, { name }).then((r) => r.data),
  members: (id) => api.get(`/workspaces/${id}/members`).then((r) => r.data),
  invite: (id, email, role) => api.post(`/workspaces/${id}/members`, { email, role }).then((r) => r.data),
  changeRole: (id, userId, role) => api.patch(`/workspaces/${id}/members/${userId}`, { role }).then((r) => r.data),
  removeMember: (id, userId) => api.delete(`/workspaces/${id}/members/${userId}`),
  boards: (id, status) => api.get(`/workspaces/${id}/boards`, { params: { status } }).then((r) => r.data),
  templates: (id) => api.get(`/workspaces/${id}/templates`).then((r) => r.data),
  createTemplate: (id, body) => api.post(`/workspaces/${id}/templates`, body).then((r) => r.data),
};

// ---- Boards & cards (Module 1) ----
export const boardApi = {
  create: (body) => api.post('/boards', body).then((r) => r.data),
  get: (boardId) => api.get(`/boards/${boardId}`).then((r) => r.data),
  update: (boardId, body) => api.patch(`/boards/${boardId}`, body).then((r) => r.data),
  archive: (boardId) => api.delete(`/boards/${boardId}`),
  searchCards: (boardId, params) => api.get(`/boards/${boardId}/cards`, { params }).then((r) => r.data),
  addCard: (boardId, body) => api.post(`/boards/${boardId}/cards`, body).then((r) => r.data),
  submitHappiness: (boardId, body) => api.post(`/boards/${boardId}/happiness`, body),
  happinessSummary: (boardId) => api.get(`/boards/${boardId}/happiness/summary`).then((r) => r.data),
};

export const cardApi = {
  update: (cardId, body) => api.patch(`/cards/${cardId}`, body).then((r) => r.data),
  remove: (cardId) => api.delete(`/cards/${cardId}`),
  comments: (cardId) => api.get(`/cards/${cardId}/comments`).then((r) => r.data),
  addComment: (cardId, body) => api.post(`/cards/${cardId}/comments`, body).then((r) => r.data),
};

// ---- Voting (Module 3) ----
export const voteApi = {
  config: (boardId, body) => api.patch(`/boards/${boardId}/vote-config`, body).then((r) => r.data),
  cast: (cardId, direction) => api.put(`/cards/${cardId}/votes`, { direction }).then((r) => r.data),
  withdraw: (cardId) => api.delete(`/cards/${cardId}/votes`).then((r) => r.data),
  tally: (boardId) => api.get(`/boards/${boardId}/votes/tally`).then((r) => r.data),
  reveal: (boardId) => api.post(`/boards/${boardId}/votes/reveal`).then((r) => r.data),
};

// ---- Action items (Module 4) ----
export const actionItemApi = {
  createFromCard: (cardId, body) => api.post(`/cards/${cardId}/action-items`, body).then((r) => r.data),
  createStandalone: (body) => api.post('/action-items', body).then((r) => r.data),
  dashboard: (params) => api.get('/action-items', { params }).then((r) => r.data),
  update: (id, body) => api.patch(`/action-items/${id}`, body).then((r) => r.data),
  remove: (id) => api.delete(`/action-items/${id}`),
  mine: () => api.get('/users/me/action-items').then((r) => r.data),
};

// ---- Polls (replaces Happiness Index) ----
export const pollApi = {
  list: (boardId) => api.get(`/boards/${boardId}/polls`).then((r) => r.data),
  create: (boardId, title) => api.post(`/boards/${boardId}/polls`, { title }).then((r) => r.data),
  respond: (pollId, score) => api.put(`/polls/${pollId}/respond`, { score }).then((r) => r.data),
  reveal: (pollId) => api.patch(`/polls/${pollId}/reveal`).then((r) => r.data),
  close: (pollId) => api.patch(`/polls/${pollId}/close`).then((r) => r.data),
};

// ---- Jira integration ----
export const jiraApi = {
  summary: (sprintId) => api.get('/jira/summary', { params: sprintId ? { sprintId } : {} }).then((r) => r.data),

  status:  () => api.get('/jira/status').then((r) => r.data),
};

// ---- Collaboration / session (Module 2) ----
export const sessionApi = {
  inviteLink: (boardId, expiresInMinutes) =>
    api.post(`/boards/${boardId}/invite-link`, { expiresInMinutes }).then((r) => r.data),
  inviteEmail: (boardId, emails) => api.post(`/boards/${boardId}/invite-email`, { emails }),
  join: (boardId, token) => api.post(`/boards/${boardId}/join`, null, { params: { token } }).then((r) => r.data),
  timer: (boardId, action, durationSeconds) =>
    api.post(`/boards/${boardId}/timer`, { action, durationSeconds }).then((r) => r.data),
  timerState: (boardId) => api.get(`/boards/${boardId}/timer`).then((r) => r.data),
  phase: (boardId, phase) => api.post(`/boards/${boardId}/phase`, { phase }).then((r) => r.data),
  summary: (boardId) => api.get(`/boards/${boardId}/summary`).then((r) => r.data),
  aiSummary: (boardId) => api.post(`/boards/${boardId}/summary/ai`).then((r) => r.data),
};
