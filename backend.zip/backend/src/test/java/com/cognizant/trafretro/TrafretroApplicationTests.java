package com.cognizant.trafretro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrafretroApplicationTests {

	@Test
	void contextLoads() {
	}

}
