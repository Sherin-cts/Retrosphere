package com.cognizant.trafretro.repository;

import com.cognizant.trafretro.domain.entity.Workspace;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface WorkspaceRepository extends JpaRepository<Workspace, Long> {

    Optional<Workspace> findByIdAndDeletedAtIsNull(Long id);

    /** Workspaces the given user belongs to (via workspace_members). */
    @Query("""
            select w from Workspace w
            join WorkspaceMember m on m.workspace = w
            where m.user.id = :userId and w.deletedAt is null
            order by w.createdAt desc
            """)
    List<Workspace> findAllForUser(Long userId);
}
