package com.cognizant.trafretro.realtime;

import java.time.Instant;

/**
 * Envelope for every live event broadcast to /topic/board/{boardId}.
 * {@code type} is one of: card.created, card.updated, card.moved, card.deleted,
 * vote.changed, vote.revealed, reaction.added, hand.raised, timer.tick, phase.changed, comment.added.
 */
public record BoardEvent(String type, Object payload, Instant at) {
    public static BoardEvent of(String type, Object payload) {
        return new BoardEvent(type, payload, Instant.now());
    }
}
