package com.cognizant.trafretro.repository;

import com.cognizant.trafretro.domain.entity.Comment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CommentRepository extends JpaRepository<Comment, Long> {

    List<Comment> findByCardIdAndDeletedAtIsNullOrderByCreatedAtAsc(Long cardId);

    long countByCardIdAndDeletedAtIsNull(Long cardId);

    /** Comment counts per card for a whole board: rows of [cardId, count]. */
    @Query("""
            select c.card.id, count(c)
            from Comment c
            where c.card.board.id = :boardId and c.deletedAt is null
            group by c.card.id
            """)
    List<Object[]> countsByBoard(@Param("boardId") Long boardId);
}
