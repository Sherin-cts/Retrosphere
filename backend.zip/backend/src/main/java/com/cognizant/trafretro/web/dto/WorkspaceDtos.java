package com.cognizant.trafretro.web.dto;

import com.cognizant.trafretro.domain.entity.WorkspaceMember;
import com.cognizant.trafretro.domain.enums.WorkspaceRole;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.Instant;

public final class WorkspaceDtos {

    private WorkspaceDtos() {
    }

    public record CreateWorkspaceRequest(@NotBlank @Size(max = 150) String name) {
    }

    public record UpdateWorkspaceRequest(@NotBlank @Size(max = 150) String name) {
    }

    /** Includes the caller's own role in this workspace. */
    public record WorkspaceResponse(Long id, String name, Long ownerUserId,
                                    WorkspaceRole myRole, Instant createdAt) {
    }

    public record InviteMemberRequest(@Email @NotBlank String email, @NotNull WorkspaceRole role) {
    }

    public record ChangeRoleRequest(@NotNull WorkspaceRole role) {
    }

    public record MemberResponse(Long userId, String email, String displayName,
                                 WorkspaceRole role, Instant joinedAt) {
        public static MemberResponse from(WorkspaceMember m) {
            return new MemberResponse(m.getUser().getId(), m.getUser().getEmail(),
                    m.getUser().getDisplayName(), m.getRole(), m.getJoinedAt());
        }
    }
}
