package com.cognizant.trafretro.repository;

import com.cognizant.trafretro.domain.entity.Poll;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PollRepository extends JpaRepository<Poll, Long> {

    /** All polls on a board, newest first (used for the panel + history drawer). */
    List<Poll> findByBoardIdOrderByCreatedAtDesc(Long boardId);
}
