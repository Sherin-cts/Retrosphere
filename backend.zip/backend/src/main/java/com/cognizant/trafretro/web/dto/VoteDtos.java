package com.cognizant.trafretro.web.dto;

import jakarta.validation.constraints.NotBlank;

import java.util.List;

public final class VoteDtos {

    private VoteDtos() {
    }

    /** PATCH vote-config. Either field may be null (leave unchanged). */
    public record VoteConfigRequest(Boolean allowDownvote, Boolean hideUntilReveal) {
    }

    public record VoteConfigResponse(Long boardId, boolean allowDownvote,
                                     boolean hideVotesUntilReveal, boolean votesRevealed) {
    }

    /** PUT vote. direction is "up" or "down" (case-insensitive). */
    public record CastVoteRequest(@NotBlank String direction) {
    }

    public record CardTally(Long cardId, Long upvotes, Long downvotes) {
    }

    /** Result of casting/flipping a vote. Totals are null when hidden from the caller. */
    public record VoteResult(Long cardId, String myVote, Long upvotes, Long downvotes) {
    }

    public record TallyResponse(Long boardId, boolean revealed, List<CardTally> tallies) {
    }
}
