package com.cognizant.trafretro.domain.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.Instant;
import java.util.UUID;

/** One row per emailed invite. Maps to {@code invite_emails}. */
@Entity
@Table(name = "trafretro_invite_emails",
        uniqueConstraints = @UniqueConstraint(name = "uk_invite_email_token", columnNames = "token"))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InviteEmail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "board_id", nullable = false)
    private Board board;

    @Column(nullable = false)
    private String email;

    @Column(nullable = false, length = 36)
    private String token;

    @CreationTimestamp
    @Column(name = "sent_at", nullable = false, updatable = false)
    private Instant sentAt;

    @Column(name = "accepted_at")
    private Instant acceptedAt;

    @PrePersist
    void ensureToken() {
        if (token == null) {
            token = UUID.randomUUID().toString();
        }
    }
}
