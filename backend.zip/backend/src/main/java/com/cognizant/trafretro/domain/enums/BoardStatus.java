package com.cognizant.trafretro.domain.enums;

public enum BoardStatus {
    ACTIVE,
    ARCHIVED
}
