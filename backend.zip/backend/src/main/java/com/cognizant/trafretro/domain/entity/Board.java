package com.cognizant.trafretro.domain.entity;

import com.cognizant.trafretro.domain.enums.BoardPhase;
import com.cognizant.trafretro.domain.enums.BoardStatus;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.Instant;

/** A retrospective board/session. Session-level config lives on this row. Maps to {@code boards}. */
@Entity
@Table(name = "trafretro_boards")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Board {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "workspace_id", nullable = false)
    private Workspace workspace;

    @Column(nullable = false)
    private String name;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "template_id")
    private Template template;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 16)
    @Builder.Default
    private BoardStatus status = BoardStatus.ACTIVE;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 16)
    @Builder.Default
    private BoardPhase phase = BoardPhase.GATHER;

    @Column(name = "allow_downvote", nullable = false)
    @Builder.Default
    private boolean allowDownvote = true;

    @Column(name = "hide_votes_until_reveal", nullable = false)
    @Builder.Default
    private boolean hideVotesUntilReveal = false;

    /** True once the Facilitator has revealed votes for this session. */
    @Column(name = "votes_revealed", nullable = false)
    @Builder.Default
    private boolean votesRevealed = false;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "created_by", nullable = false)
    private User createdBy;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "archived_at")
    private Instant archivedAt;
}
