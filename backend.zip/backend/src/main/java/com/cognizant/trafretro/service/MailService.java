package com.cognizant.trafretro.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

/** Sends invite emails via SMTP. Best-effort: if no SMTP server is reachable, it logs the link. */
@Service
public class MailService {

    private static final Logger log = LoggerFactory.getLogger(MailService.class);

    private final JavaMailSender mailSender;
    private final String from;

    public MailService(JavaMailSender mailSender, @Value("${trafretro.mail.from}") String from) {
        this.mailSender = mailSender;
        this.from = from;
    }

    public void sendInvite(String to, String boardName, String joinUrl) {
        String subject = "You're invited to a TrafRetro retrospective: " + boardName;
        String body = """
                You have been invited to join the retrospective board "%s" on TrafRetro.

                Click the link below to join as a participant:
                %s

                If you don't have an account yet, you'll be able to register first.
                """.formatted(boardName, joinUrl);
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(from);
            message.setTo(to);
            message.setSubject(subject);
            message.setText(body);
            mailSender.send(message);
            log.info("Invite email sent to {}", to);
        } catch (Exception e) {
            // No SMTP relay in dev -> log the link so it can still be used.
            log.warn("Could not send invite email to {} ({}). Join link: {}", to, e.getMessage(), joinUrl);
        }
    }
}
