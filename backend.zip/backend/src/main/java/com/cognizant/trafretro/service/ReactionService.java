package com.cognizant.trafretro.service;

import com.cognizant.trafretro.common.ApiException;
import com.cognizant.trafretro.domain.entity.Board;
import com.cognizant.trafretro.domain.entity.Card;
import com.cognizant.trafretro.domain.entity.HandRaise;
import com.cognizant.trafretro.domain.entity.User;
import com.cognizant.trafretro.realtime.RealtimeEventPublisher;
import com.cognizant.trafretro.repository.CardRepository;
import com.cognizant.trafretro.repository.HandRaiseRepository;
import com.cognizant.trafretro.repository.ReactionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

@Service
@Transactional
public class ReactionService {

    private final ReactionRepository reactionRepository;
    private final HandRaiseRepository handRaiseRepository;
    private final CardRepository cardRepository;
    private final AuthorizationService authz;
    private final UserService userService;
    private final RealtimeEventPublisher events;

    public ReactionService(ReactionRepository reactionRepository, HandRaiseRepository handRaiseRepository,
                           CardRepository cardRepository, AuthorizationService authz,
                           UserService userService, RealtimeEventPublisher events) {
        this.reactionRepository = reactionRepository;
        this.handRaiseRepository = handRaiseRepository;
        this.cardRepository = cardRepository;
        this.authz = authz;
        this.userService = userService;
        this.events = events;
    }

    /** React with an emote, either board-level (cardId null) or on a specific card. */
    public void addReaction(Long boardId, Long userId, String emoji, Long cardId) {
        Board board = authz.requireBoardAccess(boardId, userId);
        User user = userService.getById(userId);
        Card card = null;
        if (cardId != null) {
            card = cardRepository.findById(cardId)
                    .orElseThrow(() -> ApiException.notFound("Card not found"));
            if (!card.getBoard().getId().equals(boardId)) {
                throw ApiException.badRequest("Card does not belong to this board");
            }
        }
        reactionRepository.save(com.cognizant.trafretro.domain.entity.Reaction.builder()
                .board(board).card(card).user(user).emoji(emoji).build());

        events.publish(boardId, "reaction.added", Map.of(
                "emoji", emoji,
                "cardId", cardId != null ? cardId : "",
                "userId", userId,
                "displayName", user.getDisplayName()));
    }

    /** Raise or lower the current user's hand. Latest state per user per board. */
    public void setHand(Long boardId, Long userId, boolean raised) {
        Board board = authz.requireBoardAccess(boardId, userId);
        User user = userService.getById(userId);
        HandRaise hand = handRaiseRepository.findByBoardIdAndUserId(boardId, userId)
                .orElseGet(() -> HandRaise.builder().board(board).user(user).build());
        hand.setRaised(raised);
        handRaiseRepository.save(hand);

        events.publish(boardId, "hand.raised", Map.of(
                "userId", userId,
                "displayName", user.getDisplayName(),
                "raised", raised));
    }
}
