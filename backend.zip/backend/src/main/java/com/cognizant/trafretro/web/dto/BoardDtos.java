package com.cognizant.trafretro.web.dto;

import com.cognizant.trafretro.domain.enums.BoardPhase;
import com.cognizant.trafretro.domain.enums.BoardStatus;
import com.cognizant.trafretro.domain.enums.WorkspaceRole;
import jakarta.validation.constraints.*;

import java.time.Instant;
import java.util.List;

public final class BoardDtos {

    private BoardDtos() {
    }

    /** Provide either a templateId (apply a built-in/custom template) or an explicit columns list. */
    public record CreateBoardRequest(
            @NotBlank @Size(max = 200) String name,
            @NotNull Long workspaceId,
            Long templateId,
            List<@NotBlank String> columns) {
    }

    /** PATCH board: rename and/or reconfigure columns (full replacement list). */
    public record UpdateBoardRequest(
            @Size(max = 200) String name,
            List<@NotBlank String> columns) {
    }

    public record ColumnResponse(Long id, String name, int position) {
    }

    public record BoardSummaryResponse(Long id, String name, Long workspaceId,
                                       BoardStatus status, BoardPhase phase,
                                       Instant createdAt, Instant archivedAt) {
    }

    public record BoardDetailResponse(Long id, String name, Long workspaceId,
                                      BoardStatus status, BoardPhase phase,
                                      boolean allowDownvote, boolean hideVotesUntilReveal,
                                      boolean votesRevealed, WorkspaceRole myRole,
                                      List<ColumnResponse> columns, List<CardResponse> cards,
                                      Instant createdAt) {
    }

    public record CardResponse(Long id, Long boardId, Long columnId,
                               Long authorUserId, String authorName, String text,
                               int position,
                               Long upvotes, Long downvotes, String myVote,
                               long commentCount,
                               Instant createdAt, Instant updatedAt) {
    }

    public record CreateCardRequest(@NotNull Long columnId, @NotBlank String text) {
    }

    /** Edit text and/or move between columns. */
    public record UpdateCardRequest(String text, Long columnId, Integer position) {
    }
}
