package com.cognizant.trafretro.service;

import com.cognizant.trafretro.domain.entity.Board;
import com.cognizant.trafretro.domain.entity.PollResponse;
import com.cognizant.trafretro.domain.enums.PollStatus;
import com.cognizant.trafretro.repository.ActionItemRepository;
import com.cognizant.trafretro.repository.CardRepository;
import com.cognizant.trafretro.repository.CardVoteRepository;
import com.cognizant.trafretro.repository.PollRepository;
import com.cognizant.trafretro.repository.PollResponseRepository;
import com.cognizant.trafretro.repository.VoteTally;
import com.cognizant.trafretro.web.dto.ActionItemDtos.ActionItemResponse;
import com.cognizant.trafretro.web.dto.CollaborationDtos.SummaryCard;
import com.cognizant.trafretro.web.dto.CollaborationDtos.SummaryPoll;
import com.cognizant.trafretro.web.dto.CollaborationDtos.SummaryResponse;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/** Builds the read-only post-retro summary: top-voted cards + poll results + action items. */
@Service
@Transactional(readOnly = true)
public class SummaryService {

    private static final int TOP_N = 10;

    private final CardRepository cardRepository;
    private final CardVoteRepository voteRepository;
    private final ActionItemRepository actionItemRepository;
    private final PollRepository pollRepository;
    private final PollResponseRepository pollResponseRepository;
    private final AuthorizationService authz;

    public SummaryService(CardRepository cardRepository, CardVoteRepository voteRepository,
                          ActionItemRepository actionItemRepository, PollRepository pollRepository,
                          PollResponseRepository pollResponseRepository, AuthorizationService authz) {
        this.cardRepository = cardRepository;
        this.voteRepository = voteRepository;
        this.actionItemRepository = actionItemRepository;
        this.pollRepository = pollRepository;
        this.pollResponseRepository = pollResponseRepository;
        this.authz = authz;
    }

    public SummaryResponse summary(Long boardId, Long userId) {
        Board board = authz.requireBoardAccess(boardId, userId);

        Map<Long, long[]> tally = voteRepository.tallyByBoard(boardId).stream()
                .collect(Collectors.toMap(VoteTally::getCardId,
                        t -> new long[]{t.getUpvotes(), t.getDownvotes()}));

        List<SummaryCard> topCards = cardRepository
                .findByBoardIdAndDeletedAtIsNullOrderByColumnIdAscPositionAsc(boardId).stream()
                .map(card -> {
                    long[] t = tally.getOrDefault(card.getId(), new long[]{0, 0});
                    return new SummaryCard(card.getId(), card.getColumn().getId(),
                            card.getText(), t[0], t[1]);
                })
                // Rank by net score (upvotes - downvotes), highest first.
                .sorted(Comparator.comparingLong((SummaryCard c) -> c.upvotes() - c.downvotes()).reversed())
                .limit(TOP_N)
                .toList();

        // Poll outcomes (only revealed/closed polls — unrevealed results stay private).
        List<SummaryPoll> polls = pollRepository.findByBoardIdOrderByCreatedAtDesc(boardId).stream()
                .filter(p -> p.getStatus() == PollStatus.REVEALED || p.getStatus() == PollStatus.CLOSED)
                .map(p -> {
                    List<PollResponse> responses = pollResponseRepository.findByPollId(p.getId());
                    int[] dist = new int[5];
                    int sum = 0;
                    for (PollResponse r : responses) {
                        int s = Math.min(5, Math.max(1, r.getScore()));
                        dist[s - 1]++;
                        sum += s;
                    }
                    double avg = responses.isEmpty() ? 0.0 : (double) sum / responses.size();
                    return new SummaryPoll(p.getId(), p.getTitle(), p.getStatus().name(),
                            avg, responses.size(), dist);
                })
                .toList();

        List<ActionItemResponse> actionItems = actionItemRepository
                .dashboard(null, null, boardId).stream()
                .map(ActionItemResponse::from)
                .toList();

        return new SummaryResponse(board.getId(), board.getName(), topCards, polls, actionItems);
    }
}
