package com.cognizant.trafretro.service;

import com.cognizant.trafretro.common.ApiException;
import com.cognizant.trafretro.domain.entity.Board;
import com.cognizant.trafretro.domain.entity.WorkspaceMember;
import com.cognizant.trafretro.domain.enums.WorkspaceRole;
import com.cognizant.trafretro.repository.BoardRepository;
import com.cognizant.trafretro.repository.WorkspaceMemberRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Row-level authorization checks (HLD section 10): workspace membership and Facilitator
 * privileges are verified here in the service layer, in addition to the API-layer security.
 */
@Service
@Transactional(readOnly = true)
public class AuthorizationService {

    private final WorkspaceMemberRepository memberRepository;
    private final BoardRepository boardRepository;

    public AuthorizationService(WorkspaceMemberRepository memberRepository, BoardRepository boardRepository) {
        this.memberRepository = memberRepository;
        this.boardRepository = boardRepository;
    }

    /** Returns the membership row or throws 403 if the user is not in the workspace. */
    public WorkspaceMember requireMembership(Long workspaceId, Long userId) {
        return memberRepository.findByWorkspaceIdAndUserId(workspaceId, userId)
                .orElseThrow(() -> ApiException.forbidden("You are not a member of this workspace"));
    }

    /** Throws 403 unless the user is a FACILITATOR in the workspace. */
    public void requireFacilitator(Long workspaceId, Long userId) {
        WorkspaceMember member = requireMembership(workspaceId, userId);
        if (member.getRole() != WorkspaceRole.FACILITATOR) {
            throw ApiException.forbidden("Only a Facilitator can perform this action");
        }
    }

    public WorkspaceRole roleOf(Long workspaceId, Long userId) {
        return requireMembership(workspaceId, userId).getRole();
    }

    public boolean isMember(Long workspaceId, Long userId) {
        return memberRepository.existsByWorkspaceIdAndUserId(workspaceId, userId);
    }

    public boolean isFacilitator(Long workspaceId, Long userId) {
        return memberRepository.findByWorkspaceIdAndUserId(workspaceId, userId)
                .map(m -> m.getRole() == WorkspaceRole.FACILITATOR)
                .orElse(false);
    }

    /** Loads a board the user may access (any workspace member), or throws 403/404. */
    public Board requireBoardAccess(Long boardId, Long userId) {
        Board board = boardRepository.findById(boardId)
                .orElseThrow(() -> ApiException.notFound("Board not found"));
        requireMembership(board.getWorkspace().getId(), userId);
        return board;
    }

    /** Loads a board the user facilitates, or throws 403/404. */
    public Board requireBoardFacilitator(Long boardId, Long userId) {
        Board board = boardRepository.findById(boardId)
                .orElseThrow(() -> ApiException.notFound("Board not found"));
        requireFacilitator(board.getWorkspace().getId(), userId);
        return board;
    }
}
