package com.cognizant.trafretro.service;

import com.cognizant.trafretro.common.ApiException;
import com.cognizant.trafretro.domain.entity.Card;
import com.cognizant.trafretro.domain.entity.Comment;
import com.cognizant.trafretro.realtime.RealtimeEventPublisher;
import com.cognizant.trafretro.repository.CardRepository;
import com.cognizant.trafretro.repository.CommentRepository;
import com.cognizant.trafretro.web.dto.CommentDtos.CommentResponse;
import com.cognizant.trafretro.web.dto.CommentDtos.CreateCommentRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class CommentService {

    private final CommentRepository commentRepository;
    private final CardRepository cardRepository;
    private final AuthorizationService authz;
    private final UserService userService;
    private final RealtimeEventPublisher events;

    public CommentService(CommentRepository commentRepository, CardRepository cardRepository,
                          AuthorizationService authz, UserService userService,
                          RealtimeEventPublisher events) {
        this.commentRepository = commentRepository;
        this.cardRepository = cardRepository;
        this.authz = authz;
        this.userService = userService;
        this.events = events;
    }

    /** All roles may comment and reply on any card. */
    public CommentResponse addComment(Long cardId, Long userId, CreateCommentRequest req) {
        Card card = loadCard(cardId);
        authz.requireBoardAccess(card.getBoard().getId(), userId);

        Comment parent = null;
        if (req.parentCommentId() != null) {
            parent = commentRepository.findById(req.parentCommentId())
                    .orElseThrow(() -> ApiException.notFound("Parent comment not found"));
            if (!parent.getCard().getId().equals(cardId)) {
                throw ApiException.badRequest("Parent comment belongs to a different card");
            }
        }

        Comment comment = commentRepository.save(Comment.builder()
                .card(card)
                .parent(parent)
                .author(userService.getById(userId))
                .text(req.text())
                .build());
        CommentResponse resp = CommentResponse.from(comment);
        events.publish(card.getBoard().getId(), "comment.added", resp);
        return resp;
    }

    @Transactional(readOnly = true)
    public List<CommentResponse> listForCard(Long cardId, Long userId) {
        Card card = loadCard(cardId);
        authz.requireBoardAccess(card.getBoard().getId(), userId);
        return commentRepository.findByCardIdAndDeletedAtIsNullOrderByCreatedAtAsc(cardId).stream()
                .map(CommentResponse::from)
                .toList();
    }

    private Card loadCard(Long cardId) {
        Card card = cardRepository.findById(cardId)
                .orElseThrow(() -> ApiException.notFound("Card not found"));
        if (card.getDeletedAt() != null) {
            throw ApiException.notFound("Card not found");
        }
        return card;
    }
}
