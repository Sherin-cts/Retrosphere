package com.cognizant.trafretro.repository;

import com.cognizant.trafretro.domain.entity.Board;
import com.cognizant.trafretro.domain.enums.BoardStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface BoardRepository extends JpaRepository<Board, Long> {

    Optional<Board> findByIdAndArchivedAtIsNull(Long id);

    List<Board> findByWorkspaceIdAndStatusOrderByCreatedAtDesc(Long workspaceId, BoardStatus status);

    List<Board> findByWorkspaceIdOrderByCreatedAtDesc(Long workspaceId);
}
