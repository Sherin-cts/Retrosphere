package com.cognizant.trafretro.repository;

import com.cognizant.trafretro.domain.entity.PollResponse;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PollResponseRepository extends JpaRepository<PollResponse, Long> {

    List<PollResponse> findByPollId(Long pollId);

    Optional<PollResponse> findByPollIdAndUserId(Long pollId, Long userId);

    long countByPollId(Long pollId);
}
