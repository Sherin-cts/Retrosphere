package com.cognizant.trafretro.domain.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.Instant;

/** Auth identity (email/password). Maps to the {@code users} table. */
@Entity
@Table(name = "trafretro_users", uniqueConstraints = @UniqueConstraint(name = "uk_users_email", columnNames = "email"))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String email;

    @Column(name = "password_hash", nullable = false)
    private String passwordHash;

    @Column(name = "display_name", nullable = false)
    private String displayName;

    /** Per-user UI preference: "light" or "dark". */
    @Column(name = "theme_pref")
    private String themePref;

    private String timezone;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    /** Soft-delete marker; non-null means the account is logically deleted. */
    @Column(name = "deleted_at")
    private Instant deletedAt;
}
