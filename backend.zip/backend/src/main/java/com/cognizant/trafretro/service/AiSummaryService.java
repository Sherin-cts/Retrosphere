package com.cognizant.trafretro.service;

import com.cognizant.trafretro.domain.entity.Card;
import com.cognizant.trafretro.repository.CardRepository;
import com.cognizant.trafretro.web.dto.CollaborationDtos.AiColumnSummary;
import com.cognizant.trafretro.web.dto.CollaborationDtos.AiSummaryResponse;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Offline smart summary — no external API required.
 * Uses semantic theme detection + keyword frequency analysis
 * to produce structured, human-readable retrospective summaries.
 */
@Service
@Transactional(readOnly = true)
public class AiSummaryService {

    private static final Set<String> STOP_WORDS = Set.of(
        "a","an","the","and","or","but","in","on","at","to","for","of","with",
        "is","are","was","were","be","been","have","has","had","do","does","did",
        "will","would","could","should","may","might","can","it","its","this",
        "that","these","those","we","our","us","i","my","me","you","your","they",
        "their","them","he","she","not","no","more","also","very","just","like",
        "well","still","even","then","than","so","up","out","if","about","from",
        "need","want","make","get","use","keep","start","stop","continue","thing"
    );

    // Semantic theme categories mapped to keywords
    private static final Map<String, List<String>> THEME_MAP = new LinkedHashMap<>();
    static {
        THEME_MAP.put("Code Quality",       List.of("code","review","refactor","clean","debt","quality","coverage","test","testing","bug","bugs","fix","sonar","lint","standard","smell"));
        THEME_MAP.put("Communication",      List.of("communication","meeting","meetings","sync","standup","alignment","feedback","update","share","talk","inform","unclear","misunderstanding","transparency"));
        THEME_MAP.put("Process & Workflow", List.of("process","workflow","sprint","agile","scrum","velocity","planning","backlog","ticket","story","estimation","delivery","deadline","release","pipeline","ci","cd","deploy","automation","bottleneck"));
        THEME_MAP.put("Team Collaboration", List.of("team","collaborate","collaboration","pair","pairing","knowledge","support","help","mentor","onboard","cross","together","ownership","responsibility","accountability","morale"));
        THEME_MAP.put("Tools & Technology", List.of("tool","tools","platform","infrastructure","environment","setup","configuration","jenkins","jira","git","docker","kubernetes","cloud","performance","slow","build","error","exception","stack","framework","library","upgrade"));
        THEME_MAP.put("Documentation",      List.of("document","documentation","docs","wiki","readme","guide","comment","runbook","instructions","outdated","missing","written","knowledge","base"));
        THEME_MAP.put("Work-Life Balance",  List.of("workload","overtime","stress","burnout","balance","pressure","focus","distraction","blocked","blocking","dependency","capacity","bandwidth","overloaded","rush","deadline","crunch"));
        THEME_MAP.put("Testing",            List.of("test","tests","testing","unit","integration","regression","automation","coverage","flaky","manual","qa","quality","assertion","mock","selenium","cypress"));
    }

    private final CardRepository       cardRepository;
    private final AuthorizationService authz;

    public AiSummaryService(CardRepository cardRepository, AuthorizationService authz) {
        this.cardRepository = cardRepository;
        this.authz          = authz;
    }

    public AiSummaryResponse generate(Long boardId, Long userId) {
        var board = authz.requireBoardAccess(boardId, userId);

        List<Card> cards = cardRepository
                .findByBoardIdAndDeletedAtIsNullOrderByColumnIdAscPositionAsc(boardId);

        Map<String, List<String>> byColumn = new LinkedHashMap<>();
        for (Card c : cards) {
            byColumn.computeIfAbsent(c.getColumn().getName(), k -> new ArrayList<>()).add(c.getText());
        }

        if (byColumn.isEmpty()) {
            return new AiSummaryResponse(
                    List.of(),
                    "No cards were found on this board — nothing to summarise yet.",
                    board.getName());
        }

        List<AiColumnSummary> cols = byColumn.entrySet().stream()
                .map(e -> summariseColumn(e.getKey(), e.getValue()))
                .collect(Collectors.toList());

        return new AiSummaryResponse(cols, buildOverallInsight(board.getName(), cols, byColumn), board.getName());
    }

    // ── column summary ────────────────────────────────────────────────────────

    private AiColumnSummary summariseColumn(String colName, List<String> texts) {
        List<String> themes  = detectThemes(texts);
        String       summary = buildSummary(colName, texts, themes);
        return new AiColumnSummary(colName, themes, summary, texts.size());
    }

    private List<String> detectThemes(List<String> texts) {
        String combined = texts.stream().map(String::toLowerCase).collect(Collectors.joining(" "));

        // Score each semantic theme category
        Map<String, Integer> scores = new LinkedHashMap<>();
        for (Map.Entry<String, List<String>> entry : THEME_MAP.entrySet()) {
            int score = (int) entry.getValue().stream().filter(combined::contains).count();
            if (score > 0) scores.put(entry.getKey(), score);
        }

        List<String> themes = scores.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                .limit(3)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());

        // Fallback to keyword frequency if no semantic match
        if (themes.size() < 2) {
            topKeywords(texts, 3 - themes.size()).stream()
                    .filter(k -> !themes.contains(k))
                    .forEach(themes::add);
        }

        return themes.isEmpty() ? List.of("General Feedback") : themes;
    }

    private List<String> topKeywords(List<String> texts, int limit) {
        Map<String, Integer> freq = new LinkedHashMap<>();
        for (String t : texts) {
            for (String w : t.toLowerCase().split("[^a-z]+")) {
                if (w.length() > 4 && !STOP_WORDS.contains(w)) freq.merge(w, 1, Integer::sum);
            }
        }
        return freq.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                .limit(limit).map(e -> cap(e.getKey())).collect(Collectors.toList());
    }

    private String buildSummary(String col, List<String> texts, List<String> themes) {
        int size = texts.size();

        // Find most repeated word across cards (signals team priority)
        Map<String, Long> wFreq = texts.stream()
                .flatMap(t -> Arrays.stream(t.toLowerCase().split("[^a-z]+")))
                .filter(w -> w.length() > 4 && !STOP_WORDS.contains(w))
                .collect(Collectors.groupingBy(w -> w, Collectors.counting()));

        Optional<String> hotWord = wFreq.entrySet().stream()
                .filter(e -> e.getValue() > 1)
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey);

        // Representative card — longest (most descriptive)
        String topCard = texts.stream().max(Comparator.comparingInt(String::length)).orElse("");
        String second  = texts.stream().filter(t -> !t.equals(topCard))
                .max(Comparator.comparingInt(String::length)).orElse("");

        StringBuilder sb = new StringBuilder();

        // Sentence 1 — context + themes
        sb.append("The team added ").append(size).append(size == 1 ? " card" : " cards")
          .append(" to \"").append(col).append("\"");
        if (!themes.isEmpty()) {
            sb.append(", focusing on ").append(themes.get(0));
            if (themes.size() > 1) sb.append(" and ").append(themes.get(1));
        }
        sb.append(". ");

        // Sentence 2 — representative feedback
        if (size == 1) {
            sb.append("The feedback was: \"").append(topCard.trim()).append("\". ");
        } else {
            sb.append("Key feedback included: \"").append(topCard.trim()).append("\"");
            if (!second.isEmpty()) sb.append(" and \"").append(second.trim()).append("\"");
            sb.append(". ");
        }

        // Sentence 3 — pattern or consensus signal
        if (hotWord.isPresent()) {
            sb.append("The recurring mention of \"").append(hotWord.get())
              .append("\" signals this is a high-priority concern for the team.");
        } else if (size >= 3) {
            sb.append("The volume of feedback here indicates strong team consensus on this area.");
        }

        return sb.toString().trim();
    }

    // ── overall insight ───────────────────────────────────────────────────────

    private String buildOverallInsight(String boardName, List<AiColumnSummary> cols,
                                        Map<String, List<String>> byColumn) {
        int total   = cols.stream().mapToInt(AiColumnSummary::cardCount).sum();
        int colCnt  = cols.size();

        AiColumnSummary busiest  = cols.stream().max(Comparator.comparingInt(AiColumnSummary::cardCount)).orElse(cols.get(0));
        AiColumnSummary quietest = cols.stream().min(Comparator.comparingInt(AiColumnSummary::cardCount)).orElse(cols.get(0));

        // Words appearing across multiple columns = team-wide concern
        Map<String, Long> crossFreq = byColumn.values().stream()
                .flatMap(Collection::stream)
                .flatMap(t -> Arrays.stream(t.toLowerCase().split("[^a-z]+")))
                .filter(w -> w.length() > 4 && !STOP_WORDS.contains(w))
                .collect(Collectors.groupingBy(w -> w, Collectors.counting()));

        List<String> crossWords = crossFreq.entrySet().stream()
                .filter(e -> e.getValue() > 1)
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .limit(3).map(e -> "\"" + e.getKey() + "\"")
                .collect(Collectors.toList());

        // All unique themes
        List<String> allThemes = cols.stream()
                .flatMap(c -> c.themes().stream()).distinct().limit(4)
                .collect(Collectors.toList());

        StringBuilder sb = new StringBuilder();

        sb.append("The \"").append(boardName).append("\" retrospective generated ")
          .append(total).append(total == 1 ? " card" : " cards").append(" across ")
          .append(colCnt).append(colCnt == 1 ? " column" : " columns").append(", reflecting ")
          .append(total >= 10 ? "strong" : total >= 5 ? "good" : "early").append(" team engagement. ");

        sb.append("The \"").append(busiest.columnName()).append("\" column received the most input (")
          .append(busiest.cardCount()).append(busiest.cardCount() == 1 ? " card" : " cards")
          .append("), making it the team's primary focus this sprint. ");

        if (!crossWords.isEmpty()) {
            sb.append("The word").append(crossWords.size() > 1 ? "s" : "").append(" ")
              .append(String.join(", ", crossWords))
              .append(" appeared across multiple columns — a strong signal of a team-wide theme worth addressing. ");
        } else if (!allThemes.isEmpty()) {
            sb.append("Dominant themes this sprint were: ").append(String.join(", ", allThemes)).append(". ");
        }

        if (quietest.cardCount() == 0 && !quietest.columnName().equals(busiest.columnName())) {
            sb.append("The \"").append(quietest.columnName())
              .append("\" column had no cards — consider prompting the team to reflect on this area next retro.");
        } else {
            sb.append("Overall, the team showed a healthy balance of recognition and improvement mindset.");
        }

        return sb.toString();
    }

    private static String cap(String w) {
        return w.isEmpty() ? w : Character.toUpperCase(w.charAt(0)) + w.substring(1);
    }
}
