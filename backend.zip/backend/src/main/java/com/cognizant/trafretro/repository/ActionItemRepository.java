package com.cognizant.trafretro.repository;

import com.cognizant.trafretro.domain.entity.ActionItem;
import com.cognizant.trafretro.domain.enums.ActionItemStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ActionItemRepository extends JpaRepository<ActionItem, Long> {

    /**
     * Cross-board dashboard query. All filters optional (null = ignore). Returns items
     * either created by, or assigned to, the relevant user as filtered.
     */
    @Query("""
            select distinct ai from ActionItem ai
            left join ai.assignees a
            where (:assigneeId is null or a.id = :assigneeId)
              and (:status is null or ai.status = :status)
              and (:boardId is null or ai.board.id = :boardId)
            order by ai.dueDate asc nulls last, ai.createdAt desc
            """)
    List<ActionItem> dashboard(@Param("assigneeId") Long assigneeId,
                               @Param("status") ActionItemStatus status,
                               @Param("boardId") Long boardId);

    /**
     * "My action items" = items ASSIGNED to the user (the things they must act on).
     * Items the user merely created (e.g. a Facilitator who logged a task for someone else)
     * are intentionally excluded so the personal dashboard isn't cluttered.
     */
    @Query("""
            select distinct ai from ActionItem ai
            join ai.assignees a
            where a.id = :userId
            order by ai.dueDate asc nulls last, ai.createdAt desc
            """)
    List<ActionItem> findForUser(@Param("userId") Long userId);
}
