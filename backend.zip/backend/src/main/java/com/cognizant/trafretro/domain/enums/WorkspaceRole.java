package com.cognizant.trafretro.domain.enums;

/** Workspace-scoped role. A user can be a FACILITATOR in one workspace and a MEMBER in another. */
public enum WorkspaceRole {
    FACILITATOR,
    MEMBER
}
