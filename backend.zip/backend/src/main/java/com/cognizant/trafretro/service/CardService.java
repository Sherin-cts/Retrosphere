package com.cognizant.trafretro.service;

import com.cognizant.trafretro.common.ApiException;
import com.cognizant.trafretro.domain.entity.*;
import com.cognizant.trafretro.domain.enums.VoteDirection;
import com.cognizant.trafretro.domain.enums.WorkspaceRole;
import com.cognizant.trafretro.realtime.RealtimeEventPublisher;
import com.cognizant.trafretro.repository.*;
import com.cognizant.trafretro.web.dto.BoardDtos.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

@Service
@Transactional
public class CardService {

    private final CardRepository cardRepository;
    private final BoardColumnRepository columnRepository;
    private final CardVoteRepository voteRepository;
    private final CommentRepository commentRepository;
    private final AuthorizationService authz;
    private final UserService userService;
    private final BoardService boardService;
    private final CardMapper cardMapper;
    private final RealtimeEventPublisher events;

    public CardService(CardRepository cardRepository, BoardColumnRepository columnRepository,
                       CardVoteRepository voteRepository, CommentRepository commentRepository,
                       AuthorizationService authz, UserService userService, BoardService boardService,
                       CardMapper cardMapper, RealtimeEventPublisher events) {
        this.cardRepository = cardRepository;
        this.columnRepository = columnRepository;
        this.voteRepository = voteRepository;
        this.commentRepository = commentRepository;
        this.authz = authz;
        this.userService = userService;
        this.boardService = boardService;
        this.cardMapper = cardMapper;
        this.events = events;
    }

    /** Any workspace member may add a card. */
    public CardResponse addCard(Long boardId, Long userId, CreateCardRequest req) {
        Board board = authz.requireBoardAccess(boardId, userId);
        BoardColumn column = loadColumnInBoard(req.columnId(), boardId);
        long count = cardRepository.findByBoardIdAndDeletedAtIsNullOrderByColumnIdAscPositionAsc(boardId)
                .stream().filter(c -> c.getColumn().getId().equals(column.getId())).count();
        Card card = cardRepository.save(Card.builder()
                .board(board)
                .column(column)
                .author(userService.getById(userId))
                .text(req.text())
                .position((int) count)
                .build());
        CardResponse resp = buildResponse(card, userId, showVotes(board));
        events.publish(boardId, "card.created", resp);
        return resp;
    }

    /** Edit text and/or move a card. Members may edit their own; Facilitators may edit any. */
    public CardResponse updateCard(Long cardId, Long userId, UpdateCardRequest req) {
        Card card = loadCard(cardId);
        Board board = card.getBoard();
        requireCardEditPermission(card, userId);

        boolean moved = false;
        if (req.text() != null && !req.text().isBlank()) {
            card.setText(req.text());
        }
        if (req.columnId() != null && !req.columnId().equals(card.getColumn().getId())) {
            card.setColumn(loadColumnInBoard(req.columnId(), board.getId()));
            moved = true;
        }
        if (req.position() != null) {
            card.setPosition(req.position());
        }
        card.setUpdatedAt(Instant.now());
        cardRepository.save(card);

        CardResponse resp = buildResponse(card, userId, showVotes(board));
        events.publish(board.getId(), moved ? "card.moved" : "card.updated", resp);
        return resp;
    }

    public void deleteCard(Long cardId, Long userId) {
        Card card = loadCard(cardId);
        requireCardEditPermission(card, userId);
        card.setDeletedAt(Instant.now());
        cardRepository.save(card);
        events.publish(card.getBoard().getId(), "card.deleted",
                java.util.Map.of("cardId", cardId));
    }

    @Transactional(readOnly = true)
    public List<CardResponse> search(Long boardId, Long userId, String search, Long columnId) {
        Board board = authz.requireBoardAccess(boardId, userId);
        boolean show = showVotes(board);
        return cardRepository.search(boardId,
                        (search != null && search.isBlank()) ? null : search, columnId).stream()
                .map(c -> buildResponse(c, userId, show))
                .toList();
    }

    // --- helpers -----------------------------------------------------------

    private CardResponse buildResponse(Card card, Long userId, boolean showVotes) {
        long up = voteRepository.countByCardIdAndDirection(card.getId(), VoteDirection.UP);
        long down = voteRepository.countByCardIdAndDirection(card.getId(), VoteDirection.DOWN);
        String myVote = voteRepository.findByCardIdAndUserId(card.getId(), userId)
                .map(v -> v.getDirection().name()).orElse(null);
        long comments = commentRepository.countByCardIdAndDeletedAtIsNull(card.getId());
        return cardMapper.toResponse(card, up, down, myVote, showVotes, comments);
    }

    private boolean showVotes(Board board) {
        // For broadcast/response purposes: hide totals when configured hidden and not yet revealed.
        return !(board.isHideVotesUntilReveal() && !board.isVotesRevealed());
    }

    private Card loadCard(Long cardId) {
        Card card = cardRepository.findById(cardId)
                .orElseThrow(() -> ApiException.notFound("Card not found"));
        if (card.getDeletedAt() != null) {
            throw ApiException.notFound("Card not found");
        }
        return card;
    }

    private BoardColumn loadColumnInBoard(Long columnId, Long boardId) {
        BoardColumn column = columnRepository.findById(columnId)
                .orElseThrow(() -> ApiException.notFound("Column not found"));
        if (!column.getBoard().getId().equals(boardId)) {
            throw ApiException.badRequest("Column does not belong to this board");
        }
        return column;
    }

    /** Author may edit/delete own card; Facilitator may edit/delete any card on the board. */
    private void requireCardEditPermission(Card card, Long userId) {
        if (card.getAuthor().getId().equals(userId)) {
            authz.requireBoardAccess(card.getBoard().getId(), userId);
            return;
        }
        WorkspaceRole role = authz.roleOf(card.getBoard().getWorkspace().getId(), userId);
        if (role != WorkspaceRole.FACILITATOR) {
            throw ApiException.forbidden("You can only edit your own cards");
        }
    }
}
