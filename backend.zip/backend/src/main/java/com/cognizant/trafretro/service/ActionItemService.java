package com.cognizant.trafretro.service;

import com.cognizant.trafretro.common.ApiException;
import com.cognizant.trafretro.domain.entity.*;
import com.cognizant.trafretro.domain.enums.ActionItemStatus;
import com.cognizant.trafretro.domain.enums.Priority;
import com.cognizant.trafretro.realtime.RealtimeEventPublisher;
import com.cognizant.trafretro.repository.ActionItemRepository;
import com.cognizant.trafretro.repository.CardRepository;
import com.cognizant.trafretro.repository.UserRepository;
import com.cognizant.trafretro.web.dto.ActionItemDtos.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
@Transactional
public class ActionItemService {

    private final ActionItemRepository actionItemRepository;
    private final CardRepository cardRepository;
    private final UserRepository userRepository;
    private final AuthorizationService authz;
    private final UserService userService;
    private final RealtimeEventPublisher events;

    public ActionItemService(ActionItemRepository actionItemRepository, CardRepository cardRepository,
                             UserRepository userRepository, AuthorizationService authz,
                             UserService userService, RealtimeEventPublisher events) {
        this.actionItemRepository = actionItemRepository;
        this.cardRepository = cardRepository;
        this.userRepository = userRepository;
        this.authz = authz;
        this.userService = userService;
        this.events = events;
    }

    /** Create an action item directly from a card (Facilitator). */
    public ActionItemResponse createFromCard(Long cardId, Long userId, CreateFromCardRequest req) {
        Card card = cardRepository.findById(cardId)
                .orElseThrow(() -> ApiException.notFound("Card not found"));
        Board board = authz.requireBoardFacilitator(card.getBoard().getId(), userId);
        ActionItem item = ActionItem.builder()
                .board(board)
                .sourceCard(card)
                .title(req.title())
                .description(req.description())
                .dueDate(req.dueDate())
                .priority(req.priority() != null ? req.priority() : Priority.MED)
                .status(ActionItemStatus.OPEN)
                .createdBy(userService.getById(userId))
                .assignees(resolveAssignees(req.assigneeIds()))
                .build();
        return saveAndBroadcast(item, "actionitem.created");
    }

    /** Create a standalone action item on a board (Facilitator). */
    public ActionItemResponse createStandalone(Long userId, CreateStandaloneRequest req) {
        Board board = authz.requireBoardFacilitator(req.boardId(), userId);
        ActionItem item = ActionItem.builder()
                .board(board)
                .title(req.title())
                .description(req.description())
                .dueDate(req.dueDate())
                .priority(req.priority() != null ? req.priority() : Priority.MED)
                .status(ActionItemStatus.OPEN)
                .createdBy(userService.getById(userId))
                .assignees(resolveAssignees(req.assigneeIds()))
                .build();
        return saveAndBroadcast(item, "actionitem.created");
    }

    /** Cross-board dashboard query, scoped to workspaces the caller belongs to. */
    @Transactional(readOnly = true)
    public List<ActionItemResponse> dashboard(Long userId, Long assigneeId, ActionItemStatus status, Long boardId) {
        return actionItemRepository.dashboard(assigneeId, status, boardId).stream()
                .filter(ai -> authz.isMember(ai.getBoard().getWorkspace().getId(), userId))
                .map(ActionItemResponse::from)
                .toList();
    }

    /** Convenience: items created by or assigned to the current user, across all boards. */
    @Transactional(readOnly = true)
    public List<ActionItemResponse> myDashboard(Long userId) {
        return actionItemRepository.findForUser(userId).stream()
                .map(ActionItemResponse::from)
                .toList();
    }

    /**
     * Update an action item. Facilitators may change any field; assignees/creators (Members)
     * may update status and notes (description) only.
     */
    public ActionItemResponse update(Long id, Long userId, UpdateActionItemRequest req) {
        ActionItem item = actionItemRepository.findById(id)
                .orElseThrow(() -> ApiException.notFound("Action item not found"));
        boolean facilitator = authz.isFacilitator(item.getBoard().getWorkspace().getId(), userId);
        boolean ownerOrAssignee = item.getCreatedBy().getId().equals(userId)
                || item.getAssignees().stream().anyMatch(u -> u.getId().equals(userId));

        if (!facilitator && !ownerOrAssignee) {
            throw ApiException.forbidden("You cannot modify this action item");
        }

        if (req.status() != null) {
            item.setStatus(req.status());
        }
        if (req.description() != null) {
            item.setDescription(req.description());
        }
        // Fields below are Facilitator-only.
        if (facilitator) {
            if (req.title() != null && !req.title().isBlank()) {
                item.setTitle(req.title());
            }
            if (req.dueDate() != null) {
                item.setDueDate(req.dueDate());
            }
            if (req.priority() != null) {
                item.setPriority(req.priority());
            }
            if (req.assigneeIds() != null) {
                item.setAssignees(resolveAssignees(req.assigneeIds()));
            }
        } else if (req.title() != null || req.dueDate() != null
                || req.priority() != null || req.assigneeIds() != null) {
            throw ApiException.forbidden("Only a Facilitator can change title, due date, priority, or assignees");
        }

        return saveAndBroadcast(item, "actionitem.updated");
    }

    /** Delete: Facilitator or the item creator only. */
    public void delete(Long id, Long userId) {
        ActionItem item = actionItemRepository.findById(id)
                .orElseThrow(() -> ApiException.notFound("Action item not found"));
        boolean facilitator = authz.isFacilitator(item.getBoard().getWorkspace().getId(), userId);
        boolean creator = item.getCreatedBy().getId().equals(userId);
        if (!facilitator && !creator) {
            throw ApiException.forbidden("Only a Facilitator or the creator can delete this action item");
        }
        Long boardId = item.getBoard().getId();
        actionItemRepository.delete(item);
        events.publish(boardId, "actionitem.deleted", java.util.Map.of("actionItemId", id));
    }

    // --- helpers -----------------------------------------------------------

    private ActionItemResponse saveAndBroadcast(ActionItem item, String eventType) {
        ActionItem saved = actionItemRepository.save(item);
        ActionItemResponse resp = ActionItemResponse.from(saved);
        events.publish(saved.getBoard().getId(), eventType, resp);
        return resp;
    }

    private Set<User> resolveAssignees(List<Long> assigneeIds) {
        Set<User> assignees = new HashSet<>();
        if (assigneeIds != null) {
            for (Long uid : assigneeIds) {
                assignees.add(userRepository.findById(uid)
                        .orElseThrow(() -> ApiException.badRequest("Assignee user " + uid + " not found")));
            }
        }
        return assignees;
    }
}
