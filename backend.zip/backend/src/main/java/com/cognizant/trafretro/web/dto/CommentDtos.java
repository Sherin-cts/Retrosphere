package com.cognizant.trafretro.web.dto;

import com.cognizant.trafretro.domain.entity.Comment;
import jakarta.validation.constraints.NotBlank;

import java.time.Instant;

public final class CommentDtos {

    private CommentDtos() {
    }

    public record CreateCommentRequest(@NotBlank String text, Long parentCommentId) {
    }

    public record CommentResponse(Long id, Long cardId, Long parentCommentId,
                                  Long authorUserId, String authorName, String text, Instant createdAt) {
        public static CommentResponse from(Comment c) {
            return new CommentResponse(
                    c.getId(),
                    c.getCard().getId(),
                    c.getParent() != null ? c.getParent().getId() : null,
                    c.getAuthor().getId(),
                    c.getAuthor().getDisplayName(),
                    c.getText(),
                    c.getCreatedAt());
        }
    }
}
