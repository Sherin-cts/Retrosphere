package com.cognizant.trafretro.domain.enums;

public enum Priority {
    LOW,
    MED,
    HIGH
}
