package com.cognizant.trafretro.service;

import com.cognizant.trafretro.common.ApiException;
import com.cognizant.trafretro.domain.entity.User;
import com.cognizant.trafretro.domain.entity.Workspace;
import com.cognizant.trafretro.domain.entity.WorkspaceMember;
import com.cognizant.trafretro.domain.enums.WorkspaceRole;
import com.cognizant.trafretro.repository.UserRepository;
import com.cognizant.trafretro.repository.WorkspaceMemberRepository;
import com.cognizant.trafretro.repository.WorkspaceRepository;
import com.cognizant.trafretro.web.dto.WorkspaceDtos.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class WorkspaceService {

    private final WorkspaceRepository workspaceRepository;
    private final WorkspaceMemberRepository memberRepository;
    private final UserRepository userRepository;
    private final AuthorizationService authz;

    public WorkspaceService(WorkspaceRepository workspaceRepository,
                            WorkspaceMemberRepository memberRepository,
                            UserRepository userRepository,
                            AuthorizationService authz) {
        this.workspaceRepository = workspaceRepository;
        this.memberRepository = memberRepository;
        this.userRepository = userRepository;
        this.authz = authz;
    }

    /** Creating a workspace makes the caller its owner and a FACILITATOR member. */
    public WorkspaceResponse create(Long userId, CreateWorkspaceRequest req) {
        User owner = userRepository.findById(userId)
                .orElseThrow(() -> ApiException.notFound("User not found"));
        Workspace ws = workspaceRepository.save(Workspace.builder()
                .name(req.name())
                .owner(owner)
                .build());
        memberRepository.save(WorkspaceMember.builder()
                .workspace(ws)
                .user(owner)
                .role(WorkspaceRole.FACILITATOR)
                .build());
        return new WorkspaceResponse(ws.getId(), ws.getName(), owner.getId(),
                WorkspaceRole.FACILITATOR, ws.getCreatedAt());
    }

    @Transactional(readOnly = true)
    public List<WorkspaceResponse> listForUser(Long userId) {
        return workspaceRepository.findAllForUser(userId).stream()
                .map(ws -> new WorkspaceResponse(ws.getId(), ws.getName(), ws.getOwner().getId(),
                        authz.roleOf(ws.getId(), userId), ws.getCreatedAt()))
                .toList();
    }

    /** Rename a workspace (Facilitator only). */
    public WorkspaceResponse update(Long workspaceId, Long requesterId, UpdateWorkspaceRequest req) {
        authz.requireFacilitator(workspaceId, requesterId);
        Workspace ws = workspaceRepository.findByIdAndDeletedAtIsNull(workspaceId)
                .orElseThrow(() -> ApiException.notFound("Workspace not found"));
        ws.setName(req.name());
        workspaceRepository.save(ws);
        return new WorkspaceResponse(ws.getId(), ws.getName(), ws.getOwner().getId(),
                authz.roleOf(ws.getId(), requesterId), ws.getCreatedAt());
    }

    @Transactional(readOnly = true)
    public List<MemberResponse> listMembers(Long workspaceId, Long userId) {
        authz.requireMembership(workspaceId, userId);
        return memberRepository.findByWorkspaceId(workspaceId).stream()
                .map(MemberResponse::from)
                .toList();
    }

    /** Facilitator invites an already-registered user into the workspace. */
    public MemberResponse inviteMember(Long workspaceId, Long requesterId, InviteMemberRequest req) {
        authz.requireFacilitator(workspaceId, requesterId);
        Workspace ws = workspaceRepository.findByIdAndDeletedAtIsNull(workspaceId)
                .orElseThrow(() -> ApiException.notFound("Workspace not found"));
        User invitee = userRepository.findByEmailIgnoreCaseAndDeletedAtIsNull(req.email())
                .orElseThrow(() -> ApiException.notFound(
                        "No registered user with that email. Ask them to register first."));
        if (memberRepository.existsByWorkspaceIdAndUserId(workspaceId, invitee.getId())) {
            throw ApiException.conflict("User is already a member of this workspace");
        }
        WorkspaceMember member = memberRepository.save(WorkspaceMember.builder()
                .workspace(ws)
                .user(invitee)
                .role(req.role())
                .build());
        return MemberResponse.from(member);
    }

    public MemberResponse changeRole(Long workspaceId, Long requesterId, Long targetUserId, ChangeRoleRequest req) {
        authz.requireFacilitator(workspaceId, requesterId);
        Workspace ws = workspaceRepository.findByIdAndDeletedAtIsNull(workspaceId)
                .orElseThrow(() -> ApiException.notFound("Workspace not found"));
        if (ws.getOwner().getId().equals(targetUserId) && req.role() != WorkspaceRole.FACILITATOR) {
            throw ApiException.badRequest("The workspace owner must remain a Facilitator");
        }
        WorkspaceMember member = memberRepository.findByWorkspaceIdAndUserId(workspaceId, targetUserId)
                .orElseThrow(() -> ApiException.notFound("Member not found"));
        member.setRole(req.role());
        return MemberResponse.from(memberRepository.save(member));
    }

    public void removeMember(Long workspaceId, Long requesterId, Long targetUserId) {
        authz.requireFacilitator(workspaceId, requesterId);
        Workspace ws = workspaceRepository.findByIdAndDeletedAtIsNull(workspaceId)
                .orElseThrow(() -> ApiException.notFound("Workspace not found"));
        if (ws.getOwner().getId().equals(targetUserId)) {
            throw ApiException.badRequest("The workspace owner cannot be removed");
        }
        WorkspaceMember member = memberRepository.findByWorkspaceIdAndUserId(workspaceId, targetUserId)
                .orElseThrow(() -> ApiException.notFound("Member not found"));
        memberRepository.delete(member);
    }

    /**
     * Upserts a workspace membership (used by board invite redemption). Existing members keep
     * their current role; new members are added with the supplied role.
     */
    public void ensureMembership(Workspace workspace, User user, WorkspaceRole role) {
        if (!memberRepository.existsByWorkspaceIdAndUserId(workspace.getId(), user.getId())) {
            memberRepository.save(WorkspaceMember.builder()
                    .workspace(workspace)
                    .user(user)
                    .role(role)
                    .build());
        }
    }
}
