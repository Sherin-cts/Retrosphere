package com.cognizant.trafretro.domain.enums;

public enum TimerAction {
    START,
    PAUSE,
    RESET
}
