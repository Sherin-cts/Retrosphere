package com.cognizant.trafretro.repository;

import com.cognizant.trafretro.domain.entity.InviteEmail;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface InviteEmailRepository extends JpaRepository<InviteEmail, Long> {

    Optional<InviteEmail> findByToken(String token);
}
