package com.cognizant.trafretro.service;

import com.cognizant.trafretro.domain.entity.Card;
import com.cognizant.trafretro.web.dto.BoardDtos.CardResponse;
import org.springframework.stereotype.Component;

/** Builds {@link CardResponse} payloads, applying vote-visibility rules. */
@Component
public class CardMapper {

    /**
     * @param showVotes when false (votes hidden from members until reveal), the totals are nulled out.
     * @param myVote    the caller's own vote direction ("UP"/"DOWN") or null.
     */
    public CardResponse toResponse(Card card, long upvotes, long downvotes, String myVote,
                                   boolean showVotes, long commentCount) {
        return new CardResponse(
                card.getId(),
                card.getBoard().getId(),
                card.getColumn().getId(),
                card.getAuthor().getId(),
                card.getAuthor().getDisplayName(),
                card.getText(),
                card.getPosition(),
                showVotes ? upvotes : null,
                showVotes ? downvotes : null,
                myVote,
                commentCount,
                card.getCreatedAt(),
                card.getUpdatedAt());
    }
}
