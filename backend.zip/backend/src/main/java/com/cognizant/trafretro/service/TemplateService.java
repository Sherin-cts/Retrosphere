package com.cognizant.trafretro.service;

import com.cognizant.trafretro.common.ApiException;
import com.cognizant.trafretro.domain.entity.Template;
import com.cognizant.trafretro.domain.entity.Workspace;
import com.cognizant.trafretro.repository.TemplateRepository;
import com.cognizant.trafretro.repository.WorkspaceRepository;
import com.cognizant.trafretro.web.dto.TemplateDtos.CreateTemplateRequest;
import com.cognizant.trafretro.web.dto.TemplateDtos.TemplateResponse;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class TemplateService {

    private final TemplateRepository templateRepository;
    private final WorkspaceRepository workspaceRepository;
    private final AuthorizationService authz;
    private final ObjectMapper objectMapper;

    public TemplateService(TemplateRepository templateRepository,
                           WorkspaceRepository workspaceRepository,
                           AuthorizationService authz,
                           ObjectMapper objectMapper) {
        this.templateRepository = templateRepository;
        this.workspaceRepository = workspaceRepository;
        this.authz = authz;
        this.objectMapper = objectMapper;
    }

    /** Built-in templates plus any custom templates for the workspace the user belongs to. */
    @Transactional(readOnly = true)
    public List<TemplateResponse> listAvailable(Long workspaceId, Long userId) {
        authz.requireMembership(workspaceId, userId);
        List<TemplateResponse> result = new ArrayList<>();
        templateRepository.findByBuiltInTrue().forEach(t -> result.add(toResponse(t)));
        templateRepository.findByWorkspaceId(workspaceId).forEach(t -> result.add(toResponse(t)));
        return result;
    }

    public TemplateResponse createCustom(Long workspaceId, Long userId, CreateTemplateRequest req) {
        authz.requireFacilitator(workspaceId, userId);
        Workspace ws = workspaceRepository.findByIdAndDeletedAtIsNull(workspaceId)
                .orElseThrow(() -> ApiException.notFound("Workspace not found"));
        Template t = Template.builder()
                .name(req.name())
                .builtIn(false)
                .workspace(ws)
                .columnsJson(writeColumns(req.columns()))
                .build();
        return toResponse(templateRepository.save(t));
    }

    public List<String> columnsOf(Long templateId) {
        Template t = templateRepository.findById(templateId)
                .orElseThrow(() -> ApiException.notFound("Template not found"));
        return readColumns(t.getColumnsJson());
    }

    public TemplateResponse toResponse(Template t) {
        return new TemplateResponse(t.getId(), t.getName(), t.isBuiltIn(), readColumns(t.getColumnsJson()));
    }

    public List<String> readColumns(String json) {
        try {
            return objectMapper.readValue(json, new TypeReference<List<String>>() {});
        } catch (Exception e) {
            throw ApiException.badRequest("Malformed template columns: " + e.getMessage());
        }
    }

    public String writeColumns(List<String> columns) {
        try {
            return objectMapper.writeValueAsString(columns);
        } catch (Exception e) {
            throw ApiException.badRequest("Could not serialize columns: " + e.getMessage());
        }
    }
}
