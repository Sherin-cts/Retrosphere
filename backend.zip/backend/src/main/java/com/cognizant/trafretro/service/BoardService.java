package com.cognizant.trafretro.service;

import com.cognizant.trafretro.common.ApiException;
import com.cognizant.trafretro.domain.entity.*;
import com.cognizant.trafretro.domain.enums.BoardPhase;
import com.cognizant.trafretro.domain.enums.BoardStatus;
import com.cognizant.trafretro.domain.enums.VoteDirection;
import com.cognizant.trafretro.domain.enums.WorkspaceRole;
import com.cognizant.trafretro.realtime.RealtimeEventPublisher;
import com.cognizant.trafretro.repository.*;
import com.cognizant.trafretro.web.dto.BoardDtos.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.*;

@Service
@Transactional
public class BoardService {

    private final BoardRepository boardRepository;
    private final BoardColumnRepository columnRepository;
    private final CardRepository cardRepository;
    private final CardVoteRepository voteRepository;
    private final CommentRepository commentRepository;
    private final TemplateRepository templateRepository;
    private final WorkspaceRepository workspaceRepository;
    private final TemplateService templateService;
    private final AuthorizationService authz;
    private final CardMapper cardMapper;
    private final RealtimeEventPublisher events;
    private final UserService userService;

    public BoardService(BoardRepository boardRepository, BoardColumnRepository columnRepository,
                        CardRepository cardRepository, CardVoteRepository voteRepository,
                        CommentRepository commentRepository,
                        TemplateRepository templateRepository, WorkspaceRepository workspaceRepository,
                        TemplateService templateService, AuthorizationService authz,
                        CardMapper cardMapper, RealtimeEventPublisher events, UserService userService) {
        this.boardRepository = boardRepository;
        this.columnRepository = columnRepository;
        this.cardRepository = cardRepository;
        this.voteRepository = voteRepository;
        this.commentRepository = commentRepository;
        this.templateRepository = templateRepository;
        this.workspaceRepository = workspaceRepository;
        this.templateService = templateService;
        this.authz = authz;
        this.cardMapper = cardMapper;
        this.events = events;
        this.userService = userService;
    }

    /** Create a board (Facilitator only). Columns come from a template or an explicit list. */
    public BoardDetailResponse create(Long userId, CreateBoardRequest req) {
        authz.requireFacilitator(req.workspaceId(), userId);
        Workspace ws = workspaceRepository.findByIdAndDeletedAtIsNull(req.workspaceId())
                .orElseThrow(() -> ApiException.notFound("Workspace not found"));

        List<String> columnNames;
        Template template = null;
        if (req.templateId() != null) {
            template = templateRepository.findById(req.templateId())
                    .orElseThrow(() -> ApiException.notFound("Template not found"));
            columnNames = templateService.readColumns(template.getColumnsJson());
        } else if (req.columns() != null && !req.columns().isEmpty()) {
            columnNames = req.columns();
        } else {
            throw ApiException.badRequest("Provide either a templateId or a non-empty columns list");
        }

        Board board = boardRepository.save(Board.builder()
                .workspace(ws)
                .name(req.name())
                .template(template)
                .createdBy(userService.getById(userId))
                .build());
        persistColumns(board, columnNames);

        return getDetail(board.getId(), userId);
    }

    @Transactional(readOnly = true)
    public List<BoardSummaryResponse> listByWorkspace(Long workspaceId, Long userId, BoardStatus status) {
        authz.requireMembership(workspaceId, userId);
        return boardRepository.findByWorkspaceIdAndStatusOrderByCreatedAtDesc(workspaceId, status).stream()
                .map(this::toSummary)
                .toList();
    }

    @Transactional(readOnly = true)
    public BoardDetailResponse getDetail(Long boardId, Long userId) {
        Board board = authz.requireBoardAccess(boardId, userId);
        WorkspaceRole role = authz.roleOf(board.getWorkspace().getId(), userId);
        boolean showVotes = canSeeVotes(board, role);

        List<ColumnResponse> columns = columnRepository.findByBoardIdOrderByPositionAsc(boardId).stream()
                .map(c -> new ColumnResponse(c.getId(), c.getName(), c.getPosition()))
                .toList();

        // Per-card tallies computed in the DB, plus this user's own votes.
        Map<Long, long[]> tally = new HashMap<>();
        voteRepository.tallyByBoard(boardId)
                .forEach(t -> tally.put(t.getCardId(), new long[]{t.getUpvotes(), t.getDownvotes()}));
        Map<Long, VoteDirection> myVotes = new HashMap<>();
        voteRepository.findByUserIdAndCardBoardId(userId, boardId)
                .forEach(v -> myVotes.put(v.getCard().getId(), v.getDirection()));

        // Comment counts per card, computed in one grouped query.
        Map<Long, Long> commentCounts = new HashMap<>();
        for (Object[] row : commentRepository.countsByBoard(boardId)) {
            commentCounts.put((Long) row[0], (Long) row[1]);
        }

        List<CardResponse> cards = cardRepository
                .findByBoardIdAndDeletedAtIsNullOrderByColumnIdAscPositionAsc(boardId).stream()
                .map(card -> {
                    long[] t = tally.getOrDefault(card.getId(), new long[]{0, 0});
                    VoteDirection mine = myVotes.get(card.getId());
                    return cardMapper.toResponse(card, t[0], t[1],
                            mine != null ? mine.name() : null, showVotes,
                            commentCounts.getOrDefault(card.getId(), 0L));
                })
                .toList();

        return new BoardDetailResponse(board.getId(), board.getName(), board.getWorkspace().getId(),
                board.getStatus(), board.getPhase(), board.isAllowDownvote(), board.isHideVotesUntilReveal(),
                board.isVotesRevealed(), role, columns, cards, board.getCreatedAt());
    }

    /** Rename and/or reconfigure columns (Facilitator only). */
    public BoardDetailResponse update(Long boardId, Long userId, UpdateBoardRequest req) {
        Board board = authz.requireBoardFacilitator(boardId, userId);
        if (req.name() != null && !req.name().isBlank()) {
            board.setName(req.name());
        }
        if (req.columns() != null && !req.columns().isEmpty()) {
            reconfigureColumns(board, req.columns());
        }
        boardRepository.save(board);
        return getDetail(boardId, userId);
    }

    /** Soft-delete (archive). Hard delete is handled by a background retention job. */
    public void archive(Long boardId, Long userId) {
        Board board = authz.requireBoardFacilitator(boardId, userId);
        board.setStatus(BoardStatus.ARCHIVED);
        board.setArchivedAt(Instant.now());
        boardRepository.save(board);
        events.publish(boardId, "board.archived", Map.of("boardId", boardId));
    }

    /** Advance the session phase (Facilitator only) and broadcast it. */
    public BoardDetailResponse changePhase(Long boardId, Long userId, BoardPhase phase) {
        Board board = authz.requireBoardFacilitator(boardId, userId);
        board.setPhase(phase);
        boardRepository.save(board);
        events.publish(boardId, "phase.changed", Map.of("boardId", boardId, "phase", phase.name()));
        return getDetail(boardId, userId);
    }

    // --- helpers -----------------------------------------------------------

    /** Votes are visible to Facilitators always, and to Members unless hidden until reveal. */
    public boolean canSeeVotes(Board board, WorkspaceRole role) {
        if (role == WorkspaceRole.FACILITATOR) {
            return true;
        }
        return !(board.isHideVotesUntilReveal() && !board.isVotesRevealed());
    }

    private void persistColumns(Board board, List<String> names) {
        int pos = 0;
        for (String name : names) {
            columnRepository.save(BoardColumn.builder()
                    .board(board)
                    .name(name)
                    .position(pos++)
                    .build());
        }
    }

    /**
     * Replace the column set by name list, matched positionally. Existing columns are renamed,
     * extras created. Trailing columns dropped from the list are removed only if they hold no cards.
     */
    private void reconfigureColumns(Board board, List<String> names) {
        List<BoardColumn> existing = columnRepository.findByBoardIdOrderByPositionAsc(board.getId());
        for (int i = 0; i < names.size(); i++) {
            if (i < existing.size()) {
                BoardColumn col = existing.get(i);
                col.setName(names.get(i));
                col.setPosition(i);
                columnRepository.save(col);
            } else {
                columnRepository.save(BoardColumn.builder()
                        .board(board).name(names.get(i)).position(i).build());
            }
        }
        for (int i = names.size(); i < existing.size(); i++) {
            BoardColumn col = existing.get(i);
            boolean hasCards = cardRepository
                    .findByBoardIdAndDeletedAtIsNullOrderByColumnIdAscPositionAsc(board.getId())
                    .stream().anyMatch(c -> c.getColumn().getId().equals(col.getId()));
            if (hasCards) {
                throw ApiException.badRequest(
                        "Cannot remove column '" + col.getName() + "' because it still has cards");
            }
            columnRepository.delete(col);
        }
    }

    private BoardSummaryResponse toSummary(Board b) {
        return new BoardSummaryResponse(b.getId(), b.getName(), b.getWorkspace().getId(),
                b.getStatus(), b.getPhase(), b.getCreatedAt(), b.getArchivedAt());
    }
}
