package com.cognizant.trafretro.domain.enums;

public enum VoteDirection {
    UP,
    DOWN
}
