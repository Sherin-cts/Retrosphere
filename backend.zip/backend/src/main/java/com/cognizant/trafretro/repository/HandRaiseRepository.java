package com.cognizant.trafretro.repository;

import com.cognizant.trafretro.domain.entity.HandRaise;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface HandRaiseRepository extends JpaRepository<HandRaise, Long> {

    Optional<HandRaise> findByBoardIdAndUserId(Long boardId, Long userId);
}
