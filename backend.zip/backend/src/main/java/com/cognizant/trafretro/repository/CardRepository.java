package com.cognizant.trafretro.repository;

import com.cognizant.trafretro.domain.entity.Card;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CardRepository extends JpaRepository<Card, Long> {

    List<Card> findByBoardIdAndDeletedAtIsNullOrderByColumnIdAscPositionAsc(Long boardId);

    /** Search/filter cards within a board. Both params are optional (null = ignore). */
    @Query("""
            select c from Card c
            where c.board.id = :boardId
              and c.deletedAt is null
              and (:columnId is null or c.column.id = :columnId)
              and (:search is null or lower(c.text) like lower(concat('%', :search, '%')))
            order by c.column.id asc, c.position asc
            """)
    List<Card> search(@Param("boardId") Long boardId,
                      @Param("search") String search,
                      @Param("columnId") Long columnId);
}
