package com.cognizant.trafretro.config;

import com.cognizant.trafretro.domain.entity.Template;
import com.cognizant.trafretro.repository.TemplateRepository;
import com.cognizant.trafretro.service.TemplateService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.ApplicationArguments;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/** Seeds the built-in column templates on startup if none exist yet. */
@Component
public class BuiltInTemplateSeeder implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(BuiltInTemplateSeeder.class);

    private static final Map<String, List<String>> BUILT_INS = Map.of(
            "Start-Stop-Continue", List.of("Start", "Stop", "Continue"),
            "Went Well-Improve-Action Items", List.of("Went Well", "To Improve", "Action Items"),
            "Mad-Sad-Glad", List.of("Mad", "Sad", "Glad"),
            "4Ls", List.of("Liked", "Learned", "Lacked", "Longed For")
    );

    private final TemplateRepository templateRepository;
    private final TemplateService templateService;

    public BuiltInTemplateSeeder(TemplateRepository templateRepository, TemplateService templateService) {
        this.templateRepository = templateRepository;
        this.templateService = templateService;
    }

    @Override
    public void run(ApplicationArguments args) {
        if (!templateRepository.findByBuiltInTrue().isEmpty()) {
            return;
        }
        BUILT_INS.forEach((name, columns) -> templateRepository.save(Template.builder()
                .name(name)
                .builtIn(true)
                .workspace(null)
                .columnsJson(templateService.writeColumns(columns))
                .build()));
        log.info("Seeded {} built-in retrospective templates", BUILT_INS.size());
    }
}
