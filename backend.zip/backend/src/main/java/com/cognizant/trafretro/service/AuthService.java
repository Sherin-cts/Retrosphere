package com.cognizant.trafretro.service;

import com.cognizant.trafretro.common.ApiException;
import com.cognizant.trafretro.domain.entity.RefreshToken;
import com.cognizant.trafretro.domain.entity.User;
import com.cognizant.trafretro.repository.RefreshTokenRepository;
import com.cognizant.trafretro.repository.UserRepository;
import com.cognizant.trafretro.security.JwtService;
import com.cognizant.trafretro.web.dto.AuthDtos.*;
import com.cognizant.trafretro.web.dto.UserDtos.UserResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;

@Service
@Transactional
public class AuthService {

    private final UserRepository userRepository;
    private final RefreshTokenRepository refreshTokenRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;
    private final long refreshTtlSeconds;

    public AuthService(UserRepository userRepository,
                       RefreshTokenRepository refreshTokenRepository,
                       PasswordEncoder passwordEncoder,
                       JwtService jwtService,
                       AuthenticationManager authenticationManager,
                       @Value("${trafretro.jwt.refresh-token-ttl-seconds}") long refreshTtlSeconds) {
        this.userRepository = userRepository;
        this.refreshTokenRepository = refreshTokenRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
        this.authenticationManager = authenticationManager;
        this.refreshTtlSeconds = refreshTtlSeconds;
    }

    public UserResponse register(RegisterRequest req) {
        if (userRepository.existsByEmailIgnoreCase(req.email())) {
            throw ApiException.conflict("An account with that email already exists");
        }
        User user = User.builder()
                .email(req.email().toLowerCase())
                .passwordHash(passwordEncoder.encode(req.password()))
                .displayName(req.displayName())
                .themePref("light")
                .build();
        return UserResponse.from(userRepository.save(user));
    }

    public TokenResponse login(LoginRequest req) {
        // Delegates credential verification to the AuthenticationManager (BadCredentials -> 401).
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(req.email(), req.password()));
        User user = userRepository.findByEmailIgnoreCaseAndDeletedAtIsNull(req.email())
                .orElseThrow(() -> ApiException.unauthorized("Invalid email or password"));
        return issueTokens(user);
    }

    /** Validates and rotates the refresh token (the old one is revoked, a new one issued). */
    public TokenResponse refresh(RefreshRequest req) {
        RefreshToken existing = refreshTokenRepository.findById(req.refreshToken())
                .orElseThrow(() -> ApiException.unauthorized("Invalid refresh token"));
        if (existing.isRevoked() || existing.getExpiresAt().isBefore(Instant.now())) {
            throw ApiException.unauthorized("Refresh token expired or revoked");
        }
        existing.setRevoked(true);
        refreshTokenRepository.save(existing);
        return issueTokens(existing.getUser());
    }

    public void logout(LogoutRequest req) {
        refreshTokenRepository.findById(req.refreshToken()).ifPresent(rt -> {
            rt.setRevoked(true);
            refreshTokenRepository.save(rt);
        });
    }

    private TokenResponse issueTokens(User user) {
        String accessToken = jwtService.generateAccessToken(user.getId(), user.getEmail());
        RefreshToken refreshToken = RefreshToken.builder()
                .user(user)
                .expiresAt(Instant.now().plusSeconds(refreshTtlSeconds))
                .revoked(false)
                .build();
        refreshToken = refreshTokenRepository.save(refreshToken);
        return new TokenResponse(accessToken, refreshToken.getId(), "Bearer",
                jwtService.getAccessTtlSeconds(), UserResponse.from(user));
    }
}
