package com.cognizant.trafretro.web.controller;

import com.cognizant.trafretro.security.SecurityUtils;
import com.cognizant.trafretro.service.AiSummaryService;
import com.cognizant.trafretro.service.BoardService;
import com.cognizant.trafretro.service.InviteService;
import com.cognizant.trafretro.service.SummaryService;
import com.cognizant.trafretro.service.TimerService;
import com.cognizant.trafretro.web.dto.BoardDtos.BoardDetailResponse;
import com.cognizant.trafretro.web.dto.CollaborationDtos.*;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/** REST endpoints for live-session control: invites, timer, phase, and the post-retro summary. */
@RestController
@RequestMapping("/api/v1/boards/{boardId}")
@PreAuthorize("isAuthenticated()")
public class SessionController {

    private final InviteService inviteService;
    private final TimerService timerService;
    private final BoardService boardService;
    private final SummaryService summaryService;
    private final AiSummaryService aiSummaryService;

    public SessionController(InviteService inviteService, TimerService timerService,
                             BoardService boardService, SummaryService summaryService,
                             AiSummaryService aiSummaryService) {
        this.inviteService    = inviteService;
        this.timerService     = timerService;
        this.boardService     = boardService;
        this.summaryService   = summaryService;
        this.aiSummaryService = aiSummaryService;
    }

    @PostMapping("/invite-link")
    public InviteLinkResponse createInviteLink(@PathVariable Long boardId,
                                               @RequestBody(required = false) InviteLinkRequest req) {
        return inviteService.createLink(boardId, SecurityUtils.currentUserId(), req);
    }

    @PostMapping("/invite-email")
    public ResponseEntity<Void> sendInviteEmails(@PathVariable Long boardId,
                                                 @Valid @RequestBody InviteEmailRequest req) {
        inviteService.sendEmails(boardId, SecurityUtils.currentUserId(), req);
        return ResponseEntity.accepted().build();
    }

    @PostMapping("/join")
    public JoinResponse join(@PathVariable Long boardId, @RequestParam String token) {
        return inviteService.join(boardId, SecurityUtils.currentUserId(), token);
    }

    @PostMapping("/timer")
    public TimerStateResponse timer(@PathVariable Long boardId, @Valid @RequestBody TimerRequest req) {
        return timerService.apply(boardId, SecurityUtils.currentUserId(), req);
    }

    @GetMapping("/timer")
    public ResponseEntity<TimerStateResponse> timerState(@PathVariable Long boardId) {
        TimerStateResponse state = timerService.currentState(boardId, SecurityUtils.currentUserId());
        return state == null ? ResponseEntity.noContent().build() : ResponseEntity.ok(state);
    }

    @PostMapping("/phase")
    public BoardDetailResponse phase(@PathVariable Long boardId, @Valid @RequestBody PhaseRequest req) {
        return boardService.changePhase(boardId, SecurityUtils.currentUserId(), req.phase());
    }

    @GetMapping("/summary")
    public SummaryResponse summary(@PathVariable Long boardId) {
        return summaryService.summary(boardId, SecurityUtils.currentUserId());
    }

    /** Calls the Claude AI to generate themed column summaries + overall insight. */
    @PostMapping("/summary/ai")
    public AiSummaryResponse generateAiSummary(@PathVariable Long boardId) {
        return aiSummaryService.generate(boardId, SecurityUtils.currentUserId());
    }
}
