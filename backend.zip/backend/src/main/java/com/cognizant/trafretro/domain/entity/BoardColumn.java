package com.cognizant.trafretro.domain.entity;

import jakarta.persistence.*;
import lombok.*;

/** A categorisation bucket within a board. Ordered left-to-right by position. Maps to {@code columns}. */
@Entity
@Table(name = "trafretro_columns")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BoardColumn {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "board_id", nullable = false)
    private Board board;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private int position;
}
