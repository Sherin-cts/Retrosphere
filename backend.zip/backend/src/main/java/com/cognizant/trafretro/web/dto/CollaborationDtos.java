package com.cognizant.trafretro.web.dto;

import com.cognizant.trafretro.domain.enums.BoardPhase;
import com.cognizant.trafretro.domain.enums.TimerAction;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.time.Instant;
import java.util.List;

public final class CollaborationDtos {

    private CollaborationDtos() {
    }

    public record InviteLinkRequest(@Positive Integer expiresInMinutes) {
    }

    public record InviteLinkResponse(String token, String url, Instant expiresAt) {
    }

    public record InviteEmailRequest(@NotEmpty List<String> emails) {
    }

    public record JoinResponse(Long boardId, Long workspaceId, String message) {
    }

    public record TimerRequest(@NotNull TimerAction action, Integer durationSeconds) {
    }

    public record TimerStateResponse(TimerAction action, Integer durationSeconds, Instant occurredAt) {
    }

    public record PhaseRequest(@NotNull BoardPhase phase) {
    }

    /** Sent over STOMP to /app/board/{boardId}/reaction. */
    public record ReactionMessage(String emoji, Long cardId) {
    }

    /** Sent over STOMP to /app/board/{boardId}/hand. */
    public record HandMessage(boolean raised) {
    }

    // --- Post-retro summary -------------------------------------------------

    public record SummaryCard(Long cardId, Long columnId, String text, long upvotes, long downvotes) {
    }

    /** A revealed/closed poll's outcome for the summary (e.g. the "How are you feeling?" sentiment poll). */
    public record SummaryPoll(Long id, String title, String status,
                              double average, long responseCount, int[] distribution) {
    }

    public record SummaryResponse(Long boardId, String name,
                                  List<SummaryCard> topVotedCards,
                                  List<SummaryPoll> polls,
                                  List<ActionItemDtos.ActionItemResponse> actionItems) {
    }

    // --- AI-generated summary -----------------------------------------------

    public record AiColumnSummary(String columnName, List<String> themes,
                                  String summary, int cardCount) {
    }

    public record AiSummaryResponse(List<AiColumnSummary> columns,
                                    String overallInsight,
                                    String boardName) {
    }
}
