package com.cognizant.trafretro.web.controller;

import com.cognizant.trafretro.security.SecurityUtils;
import com.cognizant.trafretro.service.PollService;
import com.cognizant.trafretro.web.dto.PollDtos.CreatePollRequest;
import com.cognizant.trafretro.web.dto.PollDtos.PollView;
import com.cognizant.trafretro.web.dto.PollDtos.RespondRequest;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
@PreAuthorize("isAuthenticated()")
public class PollController {

    private final PollService pollService;

    public PollController(PollService pollService) {
        this.pollService = pollService;
    }

    /** Facilitator creates a poll on the board. */
    @PostMapping("/boards/{boardId}/polls")
    public ResponseEntity<PollView> create(@PathVariable Long boardId,
                                           @Valid @RequestBody CreatePollRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(pollService.create(boardId, SecurityUtils.currentUserId(), req));
    }

    /** Member/Facilitator submits or updates their response (upsert). */
    @PutMapping("/polls/{pollId}/respond")
    public PollView respond(@PathVariable Long pollId, @Valid @RequestBody RespondRequest req) {
        return pollService.respond(pollId, SecurityUtils.currentUserId(), req);
    }

    @PatchMapping("/polls/{pollId}/reveal")
    public PollView reveal(@PathVariable Long pollId) {
        return pollService.reveal(pollId, SecurityUtils.currentUserId());
    }

    @PatchMapping("/polls/{pollId}/close")
    public PollView close(@PathVariable Long pollId) {
        return pollService.close(pollId, SecurityUtils.currentUserId());
    }

    /** Poll history for the board (active + closed). */
    @GetMapping("/boards/{boardId}/polls")
    public List<PollView> list(@PathVariable Long boardId) {
        return pollService.listForBoard(boardId, SecurityUtils.currentUserId());
    }
}
