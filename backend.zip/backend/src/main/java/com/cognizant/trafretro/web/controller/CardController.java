package com.cognizant.trafretro.web.controller;

import com.cognizant.trafretro.security.SecurityUtils;
import com.cognizant.trafretro.service.CardService;
import com.cognizant.trafretro.service.CommentService;
import com.cognizant.trafretro.web.dto.BoardDtos.*;
import com.cognizant.trafretro.web.dto.CommentDtos.CommentResponse;
import com.cognizant.trafretro.web.dto.CommentDtos.CreateCommentRequest;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
@PreAuthorize("isAuthenticated()")
public class CardController {

    private final CardService cardService;
    private final CommentService commentService;

    public CardController(CardService cardService, CommentService commentService) {
        this.cardService = cardService;
        this.commentService = commentService;
    }

    @PostMapping("/boards/{boardId}/cards")
    public ResponseEntity<CardResponse> addCard(@PathVariable Long boardId,
                                                @Valid @RequestBody CreateCardRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(cardService.addCard(boardId, SecurityUtils.currentUserId(), req));
    }

    /** Search and filter cards within a board. */
    @GetMapping("/boards/{boardId}/cards")
    public List<CardResponse> searchCards(@PathVariable Long boardId,
                                          @RequestParam(required = false) String search,
                                          @RequestParam(required = false) Long columnId) {
        return cardService.search(boardId, SecurityUtils.currentUserId(), search, columnId);
    }

    @PatchMapping("/cards/{cardId}")
    public CardResponse updateCard(@PathVariable Long cardId,
                                   @Valid @RequestBody UpdateCardRequest req) {
        return cardService.updateCard(cardId, SecurityUtils.currentUserId(), req);
    }

    @DeleteMapping("/cards/{cardId}")
    public ResponseEntity<Void> deleteCard(@PathVariable Long cardId) {
        cardService.deleteCard(cardId, SecurityUtils.currentUserId());
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/cards/{cardId}/comments")
    public ResponseEntity<CommentResponse> addComment(@PathVariable Long cardId,
                                                      @Valid @RequestBody CreateCommentRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(commentService.addComment(cardId, SecurityUtils.currentUserId(), req));
    }

    @GetMapping("/cards/{cardId}/comments")
    public List<CommentResponse> listComments(@PathVariable Long cardId) {
        return commentService.listForCard(cardId, SecurityUtils.currentUserId());
    }
}
