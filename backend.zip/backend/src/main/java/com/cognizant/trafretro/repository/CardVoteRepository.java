package com.cognizant.trafretro.repository;

import com.cognizant.trafretro.domain.entity.CardVote;
import com.cognizant.trafretro.domain.enums.VoteDirection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface CardVoteRepository extends JpaRepository<CardVote, Long> {

    Optional<CardVote> findByCardIdAndUserId(Long cardId, Long userId);

    long countByCardIdAndDirection(Long cardId, VoteDirection direction);

    List<CardVote> findByUserIdAndCardBoardId(Long userId, Long boardId);

    void deleteByCardBoardId(Long boardId);

    /** Per-card up/down totals for a board, computed in the database. */
    @Query("""
            select c.id as cardId,
                   sum(case when v.direction = com.cognizant.trafretro.domain.enums.VoteDirection.UP then 1 else 0 end) as upvotes,
                   sum(case when v.direction = com.cognizant.trafretro.domain.enums.VoteDirection.DOWN then 1 else 0 end) as downvotes
            from Card c
            left join CardVote v on v.card = c
            where c.board.id = :boardId and c.deletedAt is null
            group by c.id
            """)
    List<VoteTally> tallyByBoard(@Param("boardId") Long boardId);
}
