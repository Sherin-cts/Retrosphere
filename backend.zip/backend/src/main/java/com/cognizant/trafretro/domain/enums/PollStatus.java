package com.cognizant.trafretro.domain.enums;

/** Lifecycle of a poll: OPEN (collecting, hidden) -> REVEALED (results visible) -> CLOSED (archived). */
public enum PollStatus {
    OPEN,
    REVEALED,
    CLOSED
}
