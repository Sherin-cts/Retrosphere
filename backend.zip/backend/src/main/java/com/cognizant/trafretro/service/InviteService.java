package com.cognizant.trafretro.service;

import com.cognizant.trafretro.common.ApiException;
import com.cognizant.trafretro.domain.entity.*;
import com.cognizant.trafretro.domain.enums.WorkspaceRole;
import com.cognizant.trafretro.repository.BoardRepository;
import com.cognizant.trafretro.repository.InviteEmailRepository;
import com.cognizant.trafretro.repository.InviteLinkRepository;
import com.cognizant.trafretro.web.dto.CollaborationDtos.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;

@Service
@Transactional
public class InviteService {

    private static final int DEFAULT_LINK_TTL_MINUTES = 1440; // 24h

    private final InviteLinkRepository inviteLinkRepository;
    private final InviteEmailRepository inviteEmailRepository;
    private final BoardRepository boardRepository;
    private final AuthorizationService authz;
    private final UserService userService;
    private final WorkspaceService workspaceService;
    private final MailService mailService;
    private final String appBaseUrl;

    public InviteService(InviteLinkRepository inviteLinkRepository, InviteEmailRepository inviteEmailRepository,
                         BoardRepository boardRepository, AuthorizationService authz, UserService userService,
                         WorkspaceService workspaceService, MailService mailService,
                         @Value("${trafretro.app.base-url}") String appBaseUrl) {
        this.inviteLinkRepository = inviteLinkRepository;
        this.inviteEmailRepository = inviteEmailRepository;
        this.boardRepository = boardRepository;
        this.authz = authz;
        this.userService = userService;
        this.workspaceService = workspaceService;
        this.mailService = mailService;
        this.appBaseUrl = appBaseUrl;
    }

    /** Facilitator generates a shareable link. Redeemers are always provisioned as MEMBER. */
    public InviteLinkResponse createLink(Long boardId, Long userId, InviteLinkRequest req) {
        Board board = authz.requireBoardFacilitator(boardId, userId);
        int minutes = req != null && req.expiresInMinutes() != null
                ? req.expiresInMinutes() : DEFAULT_LINK_TTL_MINUTES;
        InviteLink link = InviteLink.builder()
                .board(board)
                .createdBy(userService.getById(userId))
                .expiresAt(Instant.now().plus(minutes, ChronoUnit.MINUTES))
                .revoked(false)
                .build();
        link = inviteLinkRepository.save(link);
        return new InviteLinkResponse(link.getToken(), joinUrl(boardId, link.getToken()), link.getExpiresAt());
    }

    /** Facilitator sends email invitations. Invited users are always provisioned as MEMBER. */
    public void sendEmails(Long boardId, Long userId, InviteEmailRequest req) {
        Board board = authz.requireBoardFacilitator(boardId, userId);
        for (String email : req.emails()) {
            InviteEmail invite = inviteEmailRepository.save(InviteEmail.builder()
                    .board(board)
                    .email(email)
                    .build());
            mailService.sendInvite(email, board.getName(), joinUrl(boardId, invite.getToken()));
        }
    }

    /**
     * Accept an invite token and join the board. Validates the token, derives the workspace
     * from the board, and upserts a MEMBER workspace_members row for the authenticated user.
     * This is the sole mechanism by which link/email invitees gain workspace membership.
     */
    public JoinResponse join(Long boardId, Long userId, String token) {
        Board board = boardRepository.findById(boardId)
                .orElseThrow(() -> ApiException.notFound("Board not found"));
        validateToken(board, token);

        User user = userService.getById(userId);
        workspaceService.ensureMembership(board.getWorkspace(), user, WorkspaceRole.MEMBER);
        return new JoinResponse(boardId, board.getWorkspace().getId(), "Joined as MEMBER");
    }

    // --- helpers -----------------------------------------------------------

    private void validateToken(Board board, String token) {
        if (token == null || token.isBlank()) {
            throw ApiException.badRequest("Missing invite token");
        }
        // Try link token first, then email token.
        InviteLink link = inviteLinkRepository.findById(token).orElse(null);
        if (link != null) {
            if (!link.getBoard().getId().equals(board.getId())) {
                throw ApiException.badRequest("Token does not match this board");
            }
            if (link.isRevoked() || link.getExpiresAt().isBefore(Instant.now())) {
                throw ApiException.badRequest("Invite link is expired or revoked");
            }
            return;
        }
        InviteEmail emailInvite = inviteEmailRepository.findByToken(token)
                .orElseThrow(() -> ApiException.badRequest("Invalid invite token"));
        if (!emailInvite.getBoard().getId().equals(board.getId())) {
            throw ApiException.badRequest("Token does not match this board");
        }
        emailInvite.setAcceptedAt(Instant.now());
        inviteEmailRepository.save(emailInvite);
    }

    private String joinUrl(Long boardId, String token) {
        return appBaseUrl + "/boards/" + boardId + "/join?token=" + token;
    }
}
