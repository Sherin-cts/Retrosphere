package com.cognizant.trafretro.web.controller;

import com.cognizant.trafretro.security.SecurityUtils;
import com.cognizant.trafretro.service.UserService;
import com.cognizant.trafretro.web.dto.UserDtos.UpdatePreferencesRequest;
import com.cognizant.trafretro.web.dto.UserDtos.UserResponse;
import com.cognizant.trafretro.web.dto.UserDtos.UserSearchResult;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/users")
@PreAuthorize("isAuthenticated()")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/me")
    public UserResponse me() {
        return userService.getMe(SecurityUtils.currentUserId());
    }

    /** Search active users by name or email (for the add-participant picker). */
    @GetMapping("/search")
    public List<UserSearchResult> search(@RequestParam("q") String q) {
        return userService.search(q);
    }

    @PatchMapping("/me/preferences")
    public UserResponse updatePreferences(@Valid @RequestBody UpdatePreferencesRequest req) {
        return userService.updatePreferences(SecurityUtils.currentUserId(), req);
    }
}
