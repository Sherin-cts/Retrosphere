package com.cognizant.trafretro.service;

import com.cognizant.trafretro.common.ApiException;
import com.cognizant.trafretro.domain.entity.Board;
import com.cognizant.trafretro.domain.entity.Card;
import com.cognizant.trafretro.domain.entity.CardVote;
import com.cognizant.trafretro.domain.enums.VoteDirection;
import com.cognizant.trafretro.domain.enums.WorkspaceRole;
import com.cognizant.trafretro.realtime.RealtimeEventPublisher;
import com.cognizant.trafretro.repository.BoardRepository;
import com.cognizant.trafretro.repository.CardRepository;
import com.cognizant.trafretro.repository.CardVoteRepository;
import com.cognizant.trafretro.repository.VoteTally;
import com.cognizant.trafretro.web.dto.VoteDtos.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class VoteService {

    private final CardVoteRepository voteRepository;
    private final CardRepository cardRepository;
    private final BoardRepository boardRepository;
    private final AuthorizationService authz;
    private final BoardService boardService;
    private final UserService userService;
    private final RealtimeEventPublisher events;

    public VoteService(CardVoteRepository voteRepository, CardRepository cardRepository,
                       BoardRepository boardRepository, AuthorizationService authz,
                       BoardService boardService, UserService userService,
                       RealtimeEventPublisher events) {
        this.voteRepository = voteRepository;
        this.cardRepository = cardRepository;
        this.boardRepository = boardRepository;
        this.authz = authz;
        this.boardService = boardService;
        this.userService = userService;
        this.events = events;
    }

    /** Facilitator toggles downvoting and hide-until-reveal. */
    public VoteConfigResponse updateConfig(Long boardId, Long userId, VoteConfigRequest req) {
        Board board = authz.requireBoardFacilitator(boardId, userId);
        if (req.allowDownvote() != null) {
            board.setAllowDownvote(req.allowDownvote());
        }
        if (req.hideUntilReveal() != null) {
            board.setHideVotesUntilReveal(req.hideUntilReveal());
        }
        boardRepository.save(board);
        events.publish(boardId, "voteconfig.changed", configResponse(board));
        return configResponse(board);
    }

    /**
     * Cast or flip a vote. Upsert semantics: inserts if the user has not yet voted, updates the
     * direction otherwise. Calling with the same direction twice is a no-op (idempotent).
     */
    public VoteResult cast(Long cardId, Long userId, CastVoteRequest req) {
        VoteDirection direction = parseDirection(req.direction());
        Card card = loadCard(cardId);
        Board board = card.getBoard();
        WorkspaceRole role = authz.roleOf(board.getWorkspace().getId(), userId);

        if (direction == VoteDirection.DOWN && !board.isAllowDownvote()) {
            throw ApiException.badRequest("Downvoting is disabled on this board");
        }

        CardVote vote = voteRepository.findByCardIdAndUserId(cardId, userId).orElse(null);
        if (vote == null) {
            vote = CardVote.builder()
                    .card(card)
                    .user(userService.getById(userId))
                    .direction(direction)
                    .build();
            voteRepository.save(vote);
        } else if (vote.getDirection() != direction) {
            vote.setDirection(direction);
            voteRepository.save(vote);
        }
        // same direction -> no-op
        return broadcastAndBuild(card, board, role, direction.name());
    }

    /** Withdraw the current user's vote on a card. */
    public VoteResult withdraw(Long cardId, Long userId) {
        Card card = loadCard(cardId);
        Board board = card.getBoard();
        WorkspaceRole role = authz.roleOf(board.getWorkspace().getId(), userId);
        voteRepository.findByCardIdAndUserId(cardId, userId).ifPresent(voteRepository::delete);
        return broadcastAndBuild(card, board, role, null);
    }

    /** Current totals per card. Members only see totals when visibility rules allow. */
    @Transactional(readOnly = true)
    public TallyResponse tally(Long boardId, Long userId) {
        Board board = authz.requireBoardAccess(boardId, userId);
        WorkspaceRole role = authz.roleOf(board.getWorkspace().getId(), userId);
        boolean show = boardService.canSeeVotes(board, role);
        List<CardTally> tallies = voteRepository.tallyByBoard(boardId).stream()
                .map(t -> new CardTally(t.getCardId(),
                        show ? t.getUpvotes() : null,
                        show ? t.getDownvotes() : null))
                .toList();
        return new TallyResponse(boardId, board.isVotesRevealed(), tallies);
    }

    /** Facilitator reveals results: flips the flag and broadcasts the full tally to everyone. */
    public TallyResponse reveal(Long boardId, Long userId) {
        Board board = authz.requireBoardFacilitator(boardId, userId);
        board.setVotesRevealed(true);
        boardRepository.save(board);
        List<CardTally> tallies = voteRepository.tallyByBoard(boardId).stream()
                .map(t -> new CardTally(t.getCardId(), t.getUpvotes(), t.getDownvotes()))
                .toList();
        TallyResponse response = new TallyResponse(boardId, true, tallies);
        events.publish(boardId, "vote.revealed", response);
        return response;
    }

    // --- helpers -----------------------------------------------------------

    private VoteResult broadcastAndBuild(Card card, Board board, WorkspaceRole role, String myVote) {
        long up = voteRepository.countByCardIdAndDirection(card.getId(), VoteDirection.UP);
        long down = voteRepository.countByCardIdAndDirection(card.getId(), VoteDirection.DOWN);
        boolean show = !(board.isHideVotesUntilReveal() && !board.isVotesRevealed());

        // Broadcast carries totals only when visible to participants generally.
        Map<String, Object> event = new HashMap<>();
        event.put("cardId", card.getId());
        if (show) {
            event.put("upvotes", up);
            event.put("downvotes", down);
        }
        events.publish(board.getId(), "vote.changed", event);

        boolean callerSees = boardService.canSeeVotes(board, role);
        return new VoteResult(card.getId(), myVote,
                callerSees ? up : null, callerSees ? down : null);
    }

    private VoteConfigResponse configResponse(Board b) {
        return new VoteConfigResponse(b.getId(), b.isAllowDownvote(),
                b.isHideVotesUntilReveal(), b.isVotesRevealed());
    }

    private VoteDirection parseDirection(String raw) {
        try {
            return VoteDirection.valueOf(raw.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw ApiException.badRequest("direction must be 'up' or 'down'");
        }
    }

    private Card loadCard(Long cardId) {
        Card card = cardRepository.findById(cardId)
                .orElseThrow(() -> ApiException.notFound("Card not found"));
        if (card.getDeletedAt() != null) {
            throw ApiException.notFound("Card not found");
        }
        return card;
    }
}
