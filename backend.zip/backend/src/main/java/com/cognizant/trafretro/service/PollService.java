package com.cognizant.trafretro.service;

import com.cognizant.trafretro.common.ApiException;
import com.cognizant.trafretro.domain.entity.Board;
import com.cognizant.trafretro.domain.entity.Poll;
import com.cognizant.trafretro.domain.entity.PollResponse;
import com.cognizant.trafretro.domain.enums.PollStatus;
import com.cognizant.trafretro.realtime.RealtimeEventPublisher;
import com.cognizant.trafretro.repository.PollRepository;
import com.cognizant.trafretro.repository.PollResponseRepository;
import com.cognizant.trafretro.web.dto.PollDtos.CreatePollRequest;
import com.cognizant.trafretro.web.dto.PollDtos.PollView;
import com.cognizant.trafretro.web.dto.PollDtos.RespondRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class PollService {

    private final PollRepository pollRepository;
    private final PollResponseRepository responseRepository;
    private final AuthorizationService authz;
    private final UserService userService;
    private final RealtimeEventPublisher events;

    public PollService(PollRepository pollRepository, PollResponseRepository responseRepository,
                       AuthorizationService authz, UserService userService, RealtimeEventPublisher events) {
        this.pollRepository = pollRepository;
        this.responseRepository = responseRepository;
        this.authz = authz;
        this.userService = userService;
        this.events = events;
    }

    /** Facilitator creates a poll (allowed in any phase; multiple may be open at once). */
    public PollView create(Long boardId, Long userId, CreatePollRequest req) {
        Board board = authz.requireBoardFacilitator(boardId, userId);
        Poll poll = pollRepository.save(Poll.builder()
                .board(board)
                .createdBy(userService.getById(userId))
                .title(req.title())
                .status(PollStatus.OPEN)
                .build());
        broadcast(poll, "poll.created");
        return toView(poll, userId, true);
    }

    /** Member or Facilitator submits/updates their response. Allowed until the poll is CLOSED. */
    public PollView respond(Long pollId, Long userId, RespondRequest req) {
        Poll poll = loadPoll(pollId);
        authz.requireMembership(poll.getBoard().getWorkspace().getId(), userId);
        if (poll.getStatus() == PollStatus.CLOSED) {
            throw ApiException.badRequest("This poll is closed");
        }
        PollResponse response = responseRepository.findByPollIdAndUserId(pollId, userId)
                .orElseGet(() -> PollResponse.builder().poll(poll).user(userService.getById(userId)).build());
        response.setScore(req.score());
        responseRepository.save(response);
        broadcast(poll, "poll.response");
        return toView(poll, userId, authz.isFacilitator(poll.getBoard().getWorkspace().getId(), userId));
    }

    /** Facilitator reveals results to everyone. */
    public PollView reveal(Long pollId, Long userId) {
        Poll poll = loadPoll(pollId);
        authz.requireFacilitator(poll.getBoard().getWorkspace().getId(), userId);
        poll.setStatus(PollStatus.REVEALED);
        poll.setRevealedAt(Instant.now());
        pollRepository.save(poll);
        broadcast(poll, "poll.revealed");
        return toView(poll, userId, true);
    }

    /** Facilitator closes (archives) the poll. */
    public PollView close(Long pollId, Long userId) {
        Poll poll = loadPoll(pollId);
        authz.requireFacilitator(poll.getBoard().getWorkspace().getId(), userId);
        poll.setStatus(PollStatus.CLOSED);
        poll.setClosedAt(Instant.now());
        pollRepository.save(poll);
        broadcast(poll, "poll.closed");
        return toView(poll, userId, true);
    }

    /** All polls on the board (panel = OPEN/REVEALED, history = CLOSED), filtered per caller. */
    @Transactional(readOnly = true)
    public List<PollView> listForBoard(Long boardId, Long userId) {
        Board board = authz.requireBoardAccess(boardId, userId);
        boolean facilitator = authz.isFacilitator(board.getWorkspace().getId(), userId);
        return pollRepository.findByBoardIdOrderByCreatedAtDesc(boardId).stream()
                .map(p -> toView(p, userId, facilitator))
                .toList();
    }

    // --- helpers -----------------------------------------------------------

    /** Broadcast a lightweight event; clients refetch the (permission-filtered) poll list. */
    private void broadcast(Poll poll, String type) {
        events.publish(poll.getBoard().getId(), type,
                Map.of("pollId", poll.getId(), "status", poll.getStatus().name()));
    }

    private PollView toView(Poll poll, Long userId, boolean facilitator) {
        Integer myScore = responseRepository.findByPollIdAndUserId(poll.getId(), userId)
                .map(PollResponse::getScore).orElse(null);
        boolean revealedToAll = poll.getStatus() == PollStatus.REVEALED || poll.getStatus() == PollStatus.CLOSED;
        // The Facilitator sees full results from the start; members only after reveal.
        boolean resultsVisible = facilitator || revealedToAll;

        Long responseCount = null;
        Double average = null;
        int[] distribution = null;
        int[] scores = null;

        if (resultsVisible) {
            responseCount = responseRepository.countByPollId(poll.getId());
        }
        if (resultsVisible) {
            List<PollResponse> responses = responseRepository.findByPollId(poll.getId());
            distribution = new int[5];
            List<Integer> scoreList = new ArrayList<>();
            int sum = 0;
            for (PollResponse r : responses) {
                int s = Math.min(5, Math.max(1, r.getScore()));
                distribution[s - 1]++;
                scoreList.add(s);
                sum += s;
            }
            average = responses.isEmpty() ? 0.0 : (double) sum / responses.size();
            Collections.shuffle(scoreList); // anonymise order
            scores = scoreList.stream().mapToInt(Integer::intValue).toArray();
        }

        return new PollView(poll.getId(), poll.getBoard().getId(), poll.getTitle(), poll.getStatus(),
                poll.getCreatedBy().getId(), poll.getCreatedAt(), poll.getRevealedAt(), poll.getClosedAt(),
                myScore, responseCount, average, distribution, scores);
    }

    private Poll loadPoll(Long pollId) {
        return pollRepository.findById(pollId)
                .orElseThrow(() -> ApiException.notFound("Poll not found"));
    }
}
