package com.cognizant.trafretro.web.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;

import java.util.List;

public final class TemplateDtos {

    private TemplateDtos() {
    }

    public record TemplateResponse(Long id, String name, boolean builtIn, List<String> columns) {
    }

    public record CreateTemplateRequest(
            @NotBlank String name,
            @NotEmpty List<@NotBlank String> columns) {
    }
}
