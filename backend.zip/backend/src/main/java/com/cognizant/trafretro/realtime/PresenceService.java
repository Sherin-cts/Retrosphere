package com.cognizant.trafretro.realtime;

import com.cognizant.trafretro.domain.entity.Board;
import com.cognizant.trafretro.repository.BoardRepository;
import com.cognizant.trafretro.repository.UserRepository;
import com.cognizant.trafretro.security.UserPrincipal;
import com.cognizant.trafretro.service.AuthorizationService;
import org.springframework.context.event.EventListener;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.web.socket.messaging.SessionDisconnectEvent;
import org.springframework.web.socket.messaging.SessionSubscribeEvent;

import java.security.Principal;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tracks who is "currently in" each board by listening to STOMP subscribe/disconnect events,
 * and broadcasts the live roster (presence.updated) whenever it changes — like the avatar
 * row in a video call.
 */
@Service
public class PresenceService {

    /** A participant currently connected to a board. */
    public record Participant(Long userId, String displayName, String role) {}

    private record SessionInfo(Long boardId, Long userId) {}

    // sessionId -> which board/user that WebSocket session belongs to.
    private final Map<String, SessionInfo> sessions = new ConcurrentHashMap<>();

    private final RealtimeEventPublisher events;
    private final UserRepository userRepository;
    private final BoardRepository boardRepository;
    private final AuthorizationService authz;

    public PresenceService(RealtimeEventPublisher events, UserRepository userRepository,
                           BoardRepository boardRepository, AuthorizationService authz) {
        this.events = events;
        this.userRepository = userRepository;
        this.boardRepository = boardRepository;
        this.authz = authz;
    }

    @EventListener
    public void onSubscribe(SessionSubscribeEvent event) {
        StompHeaderAccessor accessor = StompHeaderAccessor.wrap(event.getMessage());
        String destination = accessor.getDestination();
        if (destination == null || !destination.startsWith("/topic/board/")) {
            return;
        }
        Long boardId = parseBoardId(destination);
        Long userId = userId(accessor.getUser());
        if (boardId == null || userId == null) {
            return;
        }
        sessions.put(accessor.getSessionId(), new SessionInfo(boardId, userId));
        broadcastRoster(boardId);
    }

    @EventListener
    public void onDisconnect(SessionDisconnectEvent event) {
        SessionInfo info = sessions.remove(event.getSessionId());
        if (info != null) {
            broadcastRoster(info.boardId());
        }
    }

    private void broadcastRoster(Long boardId) {
        Board board = boardRepository.findById(boardId).orElse(null);
        Long workspaceId = board != null ? board.getWorkspace().getId() : null;

        // Distinct users currently subscribed to this board.
        List<Participant> roster = sessions.values().stream()
                .filter(s -> s.boardId().equals(boardId))
                .map(SessionInfo::userId)
                .distinct()
                .map(uid -> {
                    String name = userRepository.findById(uid)
                            .map(u -> u.getDisplayName()).orElse("Unknown");
                    String role = (workspaceId != null && authz.isFacilitator(workspaceId, uid))
                            ? "FACILITATOR" : "MEMBER";
                    return new Participant(uid, name, role);
                })
                .toList();

        events.publish(boardId, "presence.updated", roster);
    }

    private Long parseBoardId(String destination) {
        try {
            return Long.valueOf(destination.substring("/topic/board/".length()));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private Long userId(Principal principal) {
        if (principal instanceof Authentication auth
                && auth.getPrincipal() instanceof UserPrincipal up) {
            return up.getId();
        }
        return null;
    }
}
