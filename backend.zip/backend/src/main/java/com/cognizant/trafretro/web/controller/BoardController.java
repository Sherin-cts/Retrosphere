package com.cognizant.trafretro.web.controller;

import com.cognizant.trafretro.security.SecurityUtils;
import com.cognizant.trafretro.service.BoardService;
import com.cognizant.trafretro.web.dto.BoardDtos.*;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/boards")
@PreAuthorize("isAuthenticated()")
public class BoardController {

    private final BoardService boardService;

    public BoardController(BoardService boardService) {
        this.boardService = boardService;
    }

    @PostMapping
    public ResponseEntity<BoardDetailResponse> create(@Valid @RequestBody CreateBoardRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(boardService.create(SecurityUtils.currentUserId(), req));
    }

    @GetMapping("/{boardId}")
    public BoardDetailResponse get(@PathVariable Long boardId) {
        return boardService.getDetail(boardId, SecurityUtils.currentUserId());
    }

    @PatchMapping("/{boardId}")
    public BoardDetailResponse update(@PathVariable Long boardId,
                                      @Valid @RequestBody UpdateBoardRequest req) {
        return boardService.update(boardId, SecurityUtils.currentUserId(), req);
    }

    /** Soft-delete (archive). Hard-delete is performed by a background retention job. */
    @DeleteMapping("/{boardId}")
    public ResponseEntity<Void> archive(@PathVariable Long boardId) {
        boardService.archive(boardId, SecurityUtils.currentUserId());
        return ResponseEntity.noContent().build();
    }
}
