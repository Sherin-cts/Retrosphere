package com.cognizant.trafretro.repository;

import com.cognizant.trafretro.domain.entity.TimerEvent;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface TimerEventRepository extends JpaRepository<TimerEvent, Long> {

    /** Most recent timer event for a board, used to rehydrate timer state on reconnect. */
    Optional<TimerEvent> findTopByBoardIdOrderByOccurredAtDesc(Long boardId);
}
