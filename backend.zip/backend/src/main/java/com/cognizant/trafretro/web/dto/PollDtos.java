package com.cognizant.trafretro.web.dto;

import com.cognizant.trafretro.domain.enums.PollStatus;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.time.Instant;

public final class PollDtos {

    private PollDtos() {
    }

    public record CreatePollRequest(@NotBlank @Size(max = 200) String title) {
    }

    public record RespondRequest(@Min(1) @Max(5) int score) {
    }

    /**
     * Role- and status-aware view of a poll:
     * <ul>
     *   <li>OPEN: members see only their own {@code myScore}; the Facilitator additionally sees {@code responseCount}.
     *   <li>REVEALED/CLOSED: everyone sees {@code average}, {@code distribution} (counts for 1..5) and the
     *       anonymous {@code scores} list. Results fields are null before reveal.
     * </ul>
     */
    public record PollView(
            Long id,
            Long boardId,
            String title,
            PollStatus status,
            Long createdByUserId,
            Instant createdAt,
            Instant revealedAt,
            Instant closedAt,
            Integer myScore,
            Long responseCount,
            Double average,
            int[] distribution,
            int[] scores) {
    }
}
