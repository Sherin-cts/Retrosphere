package com.cognizant.trafretro.web.dto;

import com.cognizant.trafretro.domain.entity.ActionItem;
import com.cognizant.trafretro.domain.entity.User;
import com.cognizant.trafretro.domain.enums.ActionItemStatus;
import com.cognizant.trafretro.domain.enums.Priority;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.Instant;
import java.time.LocalDate;
import java.util.List;

public final class ActionItemDtos {

    private ActionItemDtos() {
    }

    /** POST /cards/{cardId}/action-items */
    public record CreateFromCardRequest(
            @NotBlank @Size(max = 500) String title,
            String description,
            List<Long> assigneeIds,
            LocalDate dueDate,
            Priority priority) {
    }

    /** POST /action-items (standalone) */
    public record CreateStandaloneRequest(
            @NotNull Long boardId,
            @NotBlank @Size(max = 500) String title,
            String description,
            List<Long> assigneeIds,
            LocalDate dueDate,
            Priority priority) {
    }

    /** PATCH /action-items/{id} — every field optional. */
    public record UpdateActionItemRequest(
            @Size(max = 500) String title,
            String description,
            List<Long> assigneeIds,
            LocalDate dueDate,
            Priority priority,
            ActionItemStatus status) {
    }

    public record AssigneeInfo(Long userId, String displayName, String email) {
        public static AssigneeInfo from(User u) {
            return new AssigneeInfo(u.getId(), u.getDisplayName(), u.getEmail());
        }
    }

    public record ActionItemResponse(Long id, Long boardId, Long sourceCardId, String title,
                                     String description, LocalDate dueDate, Priority priority,
                                     ActionItemStatus status, List<AssigneeInfo> assignees,
                                     Long createdByUserId, Instant createdAt, Instant updatedAt) {
        public static ActionItemResponse from(ActionItem ai) {
            return new ActionItemResponse(
                    ai.getId(),
                    ai.getBoard().getId(),
                    ai.getSourceCard() != null ? ai.getSourceCard().getId() : null,
                    ai.getTitle(),
                    ai.getDescription(),
                    ai.getDueDate(),
                    ai.getPriority(),
                    ai.getStatus(),
                    ai.getAssignees().stream().map(AssigneeInfo::from).toList(),
                    ai.getCreatedBy().getId(),
                    ai.getCreatedAt(),
                    ai.getUpdatedAt());
        }
    }
}
