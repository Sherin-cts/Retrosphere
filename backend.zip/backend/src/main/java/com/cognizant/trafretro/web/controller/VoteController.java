package com.cognizant.trafretro.web.controller;

import com.cognizant.trafretro.security.SecurityUtils;
import com.cognizant.trafretro.service.VoteService;
import com.cognizant.trafretro.web.dto.VoteDtos.*;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
@PreAuthorize("isAuthenticated()")
public class VoteController {

    private final VoteService voteService;

    public VoteController(VoteService voteService) {
        this.voteService = voteService;
    }

    @PatchMapping("/boards/{boardId}/vote-config")
    public VoteConfigResponse updateConfig(@PathVariable Long boardId,
                                           @RequestBody VoteConfigRequest req) {
        return voteService.updateConfig(boardId, SecurityUtils.currentUserId(), req);
    }

    /** Cast or flip a vote (upsert, idempotent on same direction). */
    @PutMapping("/cards/{cardId}/votes")
    public VoteResult cast(@PathVariable Long cardId, @Valid @RequestBody CastVoteRequest req) {
        return voteService.cast(cardId, SecurityUtils.currentUserId(), req);
    }

    @DeleteMapping("/cards/{cardId}/votes")
    public VoteResult withdraw(@PathVariable Long cardId) {
        return voteService.withdraw(cardId, SecurityUtils.currentUserId());
    }

    @GetMapping("/boards/{boardId}/votes/tally")
    public TallyResponse tally(@PathVariable Long boardId) {
        return voteService.tally(boardId, SecurityUtils.currentUserId());
    }

    @PostMapping("/boards/{boardId}/votes/reveal")
    public TallyResponse reveal(@PathVariable Long boardId) {
        return voteService.reveal(boardId, SecurityUtils.currentUserId());
    }
}
