package com.cognizant.trafretro.domain.enums;

/** Stage of a retrospective session. */
public enum BoardPhase {
    GATHER,
    VOTE,
    DISCUSS,
    CLOSED
}
