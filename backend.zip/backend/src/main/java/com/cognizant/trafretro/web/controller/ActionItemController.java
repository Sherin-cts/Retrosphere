package com.cognizant.trafretro.web.controller;

import com.cognizant.trafretro.domain.enums.ActionItemStatus;
import com.cognizant.trafretro.security.SecurityUtils;
import com.cognizant.trafretro.service.ActionItemService;
import com.cognizant.trafretro.web.dto.ActionItemDtos.*;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
@PreAuthorize("isAuthenticated()")
public class ActionItemController {

    private final ActionItemService actionItemService;

    public ActionItemController(ActionItemService actionItemService) {
        this.actionItemService = actionItemService;
    }

    @PostMapping("/cards/{cardId}/action-items")
    public ResponseEntity<ActionItemResponse> createFromCard(@PathVariable Long cardId,
                                                             @Valid @RequestBody CreateFromCardRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(actionItemService.createFromCard(cardId, SecurityUtils.currentUserId(), req));
    }

    @PostMapping("/action-items")
    public ResponseEntity<ActionItemResponse> createStandalone(@Valid @RequestBody CreateStandaloneRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(actionItemService.createStandalone(SecurityUtils.currentUserId(), req));
    }

    /** Cross-board dashboard query. */
    @GetMapping("/action-items")
    public List<ActionItemResponse> dashboard(@RequestParam(required = false) Long assigneeId,
                                              @RequestParam(required = false) ActionItemStatus status,
                                              @RequestParam(required = false) Long boardId) {
        return actionItemService.dashboard(SecurityUtils.currentUserId(), assigneeId, status, boardId);
    }

    @PatchMapping("/action-items/{id}")
    public ActionItemResponse update(@PathVariable Long id,
                                     @Valid @RequestBody UpdateActionItemRequest req) {
        return actionItemService.update(id, SecurityUtils.currentUserId(), req);
    }

    @DeleteMapping("/action-items/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        actionItemService.delete(id, SecurityUtils.currentUserId());
        return ResponseEntity.noContent().build();
    }

    /** Convenience endpoint for the current user's dashboard. */
    @GetMapping("/users/me/action-items")
    public List<ActionItemResponse> myActionItems() {
        return actionItemService.myDashboard(SecurityUtils.currentUserId());
    }
}
