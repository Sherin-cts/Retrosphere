package com.cognizant.trafretro.web.controller;

import com.cognizant.trafretro.common.ApiException;
import com.cognizant.trafretro.security.UserPrincipal;
import com.cognizant.trafretro.service.ReactionService;
import com.cognizant.trafretro.web.dto.CollaborationDtos.HandMessage;
import com.cognizant.trafretro.web.dto.CollaborationDtos.ReactionMessage;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;

import java.security.Principal;

/**
 * STOMP message handlers for live participation events. Clients SEND to
 * /app/board/{boardId}/reaction and /app/board/{boardId}/hand; the service broadcasts
 * the resulting event to /topic/board/{boardId}.
 */
@Controller
public class RealtimeController {

    private final ReactionService reactionService;

    public RealtimeController(ReactionService reactionService) {
        this.reactionService = reactionService;
    }

    @MessageMapping("/board/{boardId}/reaction")
    public void reaction(@DestinationVariable Long boardId, ReactionMessage msg, Principal principal) {
        reactionService.addReaction(boardId, userId(principal), msg.emoji(), msg.cardId());
    }

    @MessageMapping("/board/{boardId}/hand")
    public void hand(@DestinationVariable Long boardId, HandMessage msg, Principal principal) {
        reactionService.setHand(boardId, userId(principal), msg.raised());
    }

    private Long userId(Principal principal) {
        if (principal instanceof Authentication auth
                && auth.getPrincipal() instanceof UserPrincipal up) {
            return up.getId();
        }
        throw ApiException.unauthorized("WebSocket session is not authenticated");
    }
}
