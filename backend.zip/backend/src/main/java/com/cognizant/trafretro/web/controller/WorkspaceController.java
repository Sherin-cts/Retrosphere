package com.cognizant.trafretro.web.controller;

import com.cognizant.trafretro.domain.enums.BoardStatus;
import com.cognizant.trafretro.security.SecurityUtils;
import com.cognizant.trafretro.service.BoardService;
import com.cognizant.trafretro.service.WorkspaceService;
import com.cognizant.trafretro.web.dto.BoardDtos.BoardSummaryResponse;
import com.cognizant.trafretro.web.dto.WorkspaceDtos.*;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/workspaces")
@PreAuthorize("isAuthenticated()")
public class WorkspaceController {

    private final WorkspaceService workspaceService;
    private final BoardService boardService;

    public WorkspaceController(WorkspaceService workspaceService, BoardService boardService) {
        this.workspaceService = workspaceService;
        this.boardService = boardService;
    }

    @PostMapping
    public ResponseEntity<WorkspaceResponse> create(@Valid @RequestBody CreateWorkspaceRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(workspaceService.create(SecurityUtils.currentUserId(), req));
    }

    @GetMapping
    public List<WorkspaceResponse> list() {
        return workspaceService.listForUser(SecurityUtils.currentUserId());
    }

    @PatchMapping("/{id}")
    public WorkspaceResponse update(@PathVariable Long id,
                                    @Valid @RequestBody UpdateWorkspaceRequest req) {
        return workspaceService.update(id, SecurityUtils.currentUserId(), req);
    }

    @GetMapping("/{id}/members")
    public List<MemberResponse> members(@PathVariable Long id) {
        return workspaceService.listMembers(id, SecurityUtils.currentUserId());
    }

    @PostMapping("/{id}/members")
    public ResponseEntity<MemberResponse> invite(@PathVariable Long id,
                                                 @Valid @RequestBody InviteMemberRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(workspaceService.inviteMember(id, SecurityUtils.currentUserId(), req));
    }

    @PatchMapping("/{id}/members/{userId}")
    public MemberResponse changeRole(@PathVariable Long id, @PathVariable Long userId,
                                     @Valid @RequestBody ChangeRoleRequest req) {
        return workspaceService.changeRole(id, SecurityUtils.currentUserId(), userId, req);
    }

    @DeleteMapping("/{id}/members/{userId}")
    public ResponseEntity<Void> removeMember(@PathVariable Long id, @PathVariable Long userId) {
        workspaceService.removeMember(id, SecurityUtils.currentUserId(), userId);
        return ResponseEntity.noContent().build();
    }

    /** Board history per workspace. status = active | archived (default active). */
    @GetMapping("/{id}/boards")
    public List<BoardSummaryResponse> boards(@PathVariable Long id,
                                             @RequestParam(defaultValue = "active") String status) {
        BoardStatus boardStatus = "archived".equalsIgnoreCase(status)
                ? BoardStatus.ARCHIVED : BoardStatus.ACTIVE;
        return boardService.listByWorkspace(id, SecurityUtils.currentUserId(), boardStatus);
    }
}
