package com.cognizant.trafretro.service;

import com.cognizant.trafretro.domain.entity.Board;
import com.cognizant.trafretro.domain.entity.TimerEvent;
import com.cognizant.trafretro.realtime.RealtimeEventPublisher;
import com.cognizant.trafretro.repository.TimerEventRepository;
import com.cognizant.trafretro.web.dto.CollaborationDtos.TimerRequest;
import com.cognizant.trafretro.web.dto.CollaborationDtos.TimerStateResponse;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.Map;

@Service
@Transactional
public class TimerService {

    private final TimerEventRepository timerEventRepository;
    private final AuthorizationService authz;
    private final UserService userService;
    private final RealtimeEventPublisher events;

    public TimerService(TimerEventRepository timerEventRepository, AuthorizationService authz,
                        UserService userService, RealtimeEventPublisher events) {
        this.timerEventRepository = timerEventRepository;
        this.authz = authz;
        this.userService = userService;
        this.events = events;
    }

    /** Start / pause / reset the session timer (Facilitator only). Appends to the timer log. */
    public TimerStateResponse apply(Long boardId, Long userId, TimerRequest req) {
        Board board = authz.requireBoardFacilitator(boardId, userId);
        TimerEvent event = timerEventRepository.save(TimerEvent.builder()
                .board(board)
                .action(req.action())
                .durationSeconds(req.durationSeconds())
                .actor(userService.getById(userId))
                .build());

        Map<String, Object> payload = new HashMap<>();
        payload.put("action", event.getAction().name());
        payload.put("durationSeconds", event.getDurationSeconds());
        payload.put("serverTime", event.getOccurredAt());
        events.publish(boardId, "timer.tick", payload);

        return new TimerStateResponse(event.getAction(), event.getDurationSeconds(), event.getOccurredAt());
    }

    /** Latest timer state, used by reconnecting clients to rehydrate. */
    @Transactional(readOnly = true)
    public TimerStateResponse currentState(Long boardId, Long userId) {
        authz.requireBoardAccess(boardId, userId);
        return timerEventRepository.findTopByBoardIdOrderByOccurredAtDesc(boardId)
                .map(e -> new TimerStateResponse(e.getAction(), e.getDurationSeconds(), e.getOccurredAt()))
                .orElse(null);
    }
}
