package com.cognizant.trafretro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrafretroApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrafretroApplication.class, args);
	}

}
