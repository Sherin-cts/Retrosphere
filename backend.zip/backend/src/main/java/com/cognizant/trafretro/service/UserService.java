package com.cognizant.trafretro.service;

import com.cognizant.trafretro.common.ApiException;
import com.cognizant.trafretro.domain.entity.User;
import com.cognizant.trafretro.repository.UserRepository;
import com.cognizant.trafretro.web.dto.UserDtos.UpdatePreferencesRequest;
import com.cognizant.trafretro.web.dto.UserDtos.UserResponse;
import com.cognizant.trafretro.web.dto.UserDtos.UserSearchResult;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class UserService {

    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Transactional(readOnly = true)
    public User getById(Long userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> ApiException.notFound("User not found"));
    }

    @Transactional(readOnly = true)
    public UserResponse getMe(Long userId) {
        return UserResponse.from(getById(userId));
    }

    /** Search active users by name/email; returns up to 10 minimal profiles. Blank query -> empty. */
    @Transactional(readOnly = true)
    public List<UserSearchResult> search(String query) {
        if (query == null || query.trim().length() < 2) {
            return List.of();
        }
        return userRepository.search(query.trim(), PageRequest.of(0, 10)).stream()
                .map(UserSearchResult::from)
                .toList();
    }

    public UserResponse updatePreferences(Long userId, UpdatePreferencesRequest req) {
        User user = getById(userId);
        if (req.theme() != null) {
            user.setThemePref(req.theme());
        }
        if (req.timezone() != null) {
            user.setTimezone(req.timezone());
        }
        return UserResponse.from(userRepository.save(user));
    }
}
