package com.cognizant.trafretro.repository;

import com.cognizant.trafretro.domain.entity.InviteLink;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InviteLinkRepository extends JpaRepository<InviteLink, String> {
}
