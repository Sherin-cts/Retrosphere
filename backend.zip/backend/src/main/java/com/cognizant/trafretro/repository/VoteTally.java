package com.cognizant.trafretro.repository;

/** Projection for per-card vote totals computed directly in the database. */
public interface VoteTally {
    Long getCardId();
    long getUpvotes();
    long getDownvotes();
}
