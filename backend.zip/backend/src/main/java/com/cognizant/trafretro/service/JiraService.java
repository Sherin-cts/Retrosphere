package com.cognizant.trafretro.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class JiraService {

    private static final Logger log = LoggerFactory.getLogger(JiraService.class);

    @Value("${jira.base-url:}") private String baseUrl;
    @Value("${jira.email:}")    private String email;
    @Value("${jira.api-token:}") private String apiToken;
    @Value("${jira.project-key:TRAF}") private String projectKey;
    @Value("${jira.jql:}") private String jql;   // ← add this

    private final ObjectMapper mapper = new ObjectMapper();

    public boolean isConfigured() {
        return baseUrl != null && !baseUrl.isBlank()
            && apiToken != null && !apiToken.isBlank();

    }

    public Map<String, Object> getSummary() {
        if (!isConfigured()) {
            return Map.of("error", "Jira is not configured on this server.");
        }
        try {
            String effectiveJql = (jql != null && !jql.isBlank()) ? jql : "project=" + projectKey + " ORDER BY created DESC";
            String url        = baseUrl + "/rest/api/2/search?jql=" + java.net.URLEncoder.encode(effectiveJql, "UTF-8") + "&maxResults=100&fields=summary,status,issuetype,priority";
            String authHeader = "Bearer " + apiToken;


            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Authorization", authHeader)
                    .header("Accept", "application/json")
                    .GET()
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                log.error("Jira API returned {}: {}", response.statusCode(), response.body());
                return Map.of("error", "Jira API error: HTTP " + response.statusCode());
            }

            return parseIssues(response.body());

        } catch (Exception e) {
            log.error("Jira connection failed", e);
            return Map.of("error", "Could not connect to Jira: " + e.getMessage());
        }
    }

    private Map<String, Object> parseIssues(String json) throws Exception {
        JsonNode root   = mapper.readTree(json);
        JsonNode issues = root.path("issues");

        int bugs = 0, tasks = 0, stories = 0;
        int toDo = 0, inProgress = 0, inReview = 0, done = 0;

        for (JsonNode issue : issues) {
            String type   = issue.path("fields").path("issuetype").path("name").asText("");
            String status = issue.path("fields").path("status").path("name").asText("");

            switch (type.toLowerCase()) {
                case "bug"   -> bugs++;
                case "task"  -> tasks++;
                case "story" -> stories++;
            }

            switch (status.toLowerCase()) {
                case "to do"       -> toDo++;
                case "in progress" -> inProgress++;
                case "in review"   -> inReview++;
                case "done"        -> done++;
            }
        }

        int total = bugs + tasks + stories;

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("projectKey",  projectKey);
        result.put("total",       total);
        result.put("bugs",        bugs);
        result.put("tasks",       tasks);
        result.put("stories",     stories);
        result.put("toDo",        toDo);
        result.put("inProgress",  inProgress);
        result.put("inReview",    inReview);
        result.put("done",        done);
        result.put("boardUrl",    baseUrl + "/jira/software/projects/" + projectKey + "/boards");
        return result;
    }
}
