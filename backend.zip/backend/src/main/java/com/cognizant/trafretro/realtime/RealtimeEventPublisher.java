package com.cognizant.trafretro.realtime;

import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Component;

/** Broadcasts board events to all participants subscribed to /topic/board/{boardId}. */
@Component
public class RealtimeEventPublisher {

    private final SimpMessagingTemplate messagingTemplate;

    public RealtimeEventPublisher(SimpMessagingTemplate messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }

    public void publish(Long boardId, String type, Object payload) {
        messagingTemplate.convertAndSend("/topic/board/" + boardId, BoardEvent.of(type, payload));
    }
}
