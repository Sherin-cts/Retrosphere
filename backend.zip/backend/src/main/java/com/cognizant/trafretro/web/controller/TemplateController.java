package com.cognizant.trafretro.web.controller;

import com.cognizant.trafretro.security.SecurityUtils;
import com.cognizant.trafretro.service.TemplateService;
import com.cognizant.trafretro.web.dto.TemplateDtos.CreateTemplateRequest;
import com.cognizant.trafretro.web.dto.TemplateDtos.TemplateResponse;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/workspaces/{workspaceId}/templates")
@PreAuthorize("isAuthenticated()")
public class TemplateController {

    private final TemplateService templateService;

    public TemplateController(TemplateService templateService) {
        this.templateService = templateService;
    }

    @GetMapping
    public List<TemplateResponse> list(@PathVariable Long workspaceId) {
        return templateService.listAvailable(workspaceId, SecurityUtils.currentUserId());
    }

    @PostMapping
    public ResponseEntity<TemplateResponse> create(@PathVariable Long workspaceId,
                                                   @Valid @RequestBody CreateTemplateRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(templateService.createCustom(workspaceId, SecurityUtils.currentUserId(), req));
    }
}
