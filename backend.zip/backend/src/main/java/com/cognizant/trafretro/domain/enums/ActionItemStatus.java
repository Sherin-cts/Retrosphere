package com.cognizant.trafretro.domain.enums;

/** Action item workflow: OPEN -> IN_PROGRESS -> DONE (or CANCELLED). */
public enum ActionItemStatus {
    OPEN,
    IN_PROGRESS,
    DONE,
    CANCELLED
}
