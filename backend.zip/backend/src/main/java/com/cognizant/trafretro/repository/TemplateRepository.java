package com.cognizant.trafretro.repository;

import com.cognizant.trafretro.domain.entity.Template;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TemplateRepository extends JpaRepository<Template, Long> {

    List<Template> findByBuiltInTrue();

    List<Template> findByWorkspaceId(Long workspaceId);

    Optional<Template> findByNameAndBuiltInTrue(String name);
}
