package com.cognizant.trafretro.repository;

import com.cognizant.trafretro.domain.entity.BoardColumn;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BoardColumnRepository extends JpaRepository<BoardColumn, Long> {

    List<BoardColumn> findByBoardIdOrderByPositionAsc(Long boardId);

    void deleteByBoardId(Long boardId);
}
