package com.cognizant.trafretro.domain.entity;

import jakarta.persistence.*;
import lombok.*;

/**
 * A column template. Built-in templates have a null workspace; custom templates are
 * workspace-scoped. {@code columnsJson} is a JSON array of column names.
 */
@Entity
@Table(name = "trafretro_templates")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Template {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(name = "is_built_in", nullable = false)
    private boolean builtIn;

    /** Null for built-in templates; set for workspace-scoped custom templates. */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "workspace_id")
    private Workspace workspace;

    /** JSON array of column names, e.g. ["Start","Stop","Continue"]. */
    @Lob
    @Column(name = "columns_json", nullable = false)
    private String columnsJson;
}
