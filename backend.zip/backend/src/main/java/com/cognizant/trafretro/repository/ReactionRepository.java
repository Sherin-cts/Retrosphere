package com.cognizant.trafretro.repository;

import com.cognizant.trafretro.domain.entity.Reaction;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReactionRepository extends JpaRepository<Reaction, Long> {
}
