package com.cognizant.trafretro.domain.entity;

import com.cognizant.trafretro.domain.enums.VoteDirection;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.Instant;

/**
 * One vote row per (user, card). The UNIQUE(card_id, user_id) constraint is the sole
 * enforcement mechanism for "one vote per user per card". Maps to {@code card_votes}.
 */
@Entity
@Table(name = "trafretro_card_votes",
        uniqueConstraints = @UniqueConstraint(name = "uk_card_vote", columnNames = {"card_id", "user_id"}))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CardVote {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "card_id", nullable = false)
    private Card card;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 8)
    private VoteDirection direction;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;
}
