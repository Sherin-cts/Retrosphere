package com.cognizant.trafretro.web.dto;

import com.cognizant.trafretro.domain.entity.User;
import jakarta.validation.constraints.Pattern;

public final class UserDtos {

    private UserDtos() {
    }

    public record UserResponse(Long id, String email, String displayName, String themePref, String timezone) {
        public static UserResponse from(User u) {
            return new UserResponse(u.getId(), u.getEmail(), u.getDisplayName(), u.getThemePref(), u.getTimezone());
        }
    }

    /** PATCH /users/me/preferences */
    public record UpdatePreferencesRequest(
            @Pattern(regexp = "light|dark", message = "theme must be 'light' or 'dark'") String theme,
            String timezone) {
    }

    /** Minimal public profile returned by the user-search picker (no preferences exposed). */
    public record UserSearchResult(Long id, String displayName, String email) {
        public static UserSearchResult from(User u) {
            return new UserSearchResult(u.getId(), u.getDisplayName(), u.getEmail());
        }
    }
}
