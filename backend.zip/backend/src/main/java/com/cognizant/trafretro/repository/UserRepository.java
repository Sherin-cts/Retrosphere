package com.cognizant.trafretro.repository;

import com.cognizant.trafretro.domain.entity.User;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmailIgnoreCaseAndDeletedAtIsNull(String email);

    boolean existsByEmailIgnoreCase(String email);

    /**
     * Search active users whose display name (or email) STARTS WITH the query — e.g. "ra"
     * matches "Rahul", "Rajesh". Used by the add-by-name picker.
     */
    @Query("""
            select u from User u
            where u.deletedAt is null
              and (lower(u.displayName) like lower(concat(:q, '%'))
                   or lower(u.email) like lower(concat(:q, '%')))
            order by u.displayName asc
            """)
    List<User> search(@Param("q") String q, Pageable pageable);
}
