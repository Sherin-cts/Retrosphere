# TrafRetro — Backend

Spring Boot 3.5 (Java 21) REST + WebSocket API for the TrafRetro collaborative agile
retrospective platform, implementing all five modules of the HLD v1.

- **REST** under `/api/v1/**`
- **WebSocket** (STOMP over SockJS) at `/ws`
- **Persistence** Oracle Database (default) or embedded H2 (dev)
- **Auth** JWT access tokens (15 min) + rotating refresh tokens (7 days), BCrypt cost 12

## Prerequisites

- JDK 21+ (you have JDK 24 — fine)
- Oracle Database running locally (for the default profile)
- No Maven install needed — use the bundled **Maven Wrapper** (`mvnw` / `mvnw.cmd`)

## Running

### Option A — IntelliJ (recommended, matches your usual workflow)
1. **File → Open** and select this `backend` folder (it contains `pom.xml`).
2. IntelliJ downloads dependencies automatically.
3. Set your Oracle credentials (see below), then run `TrafretroApplication`.

### Option B — command line
```bash
./mvnw spring-boot:run                      # Oracle profile (default)
./mvnw spring-boot:run -Dspring-boot.run.profiles=h2   # zero-setup, in-memory H2
```

## Database configuration

The default profile connects to Oracle. The **schema is managed by Flyway** — the
migrations in `src/main/resources/db/migration` (`V1__init_schema.sql`, …) run on
startup, and Hibernate only validates the entities against it (`ddl-auto=validate`).
Create the Oracle user first with `db/oracle/00_create_schema.sql`, then let Flyway
build the tables. Defaults are `localhost:1521`, user `system`, service name `trafretro`.
Override via env vars:

| Variable | Default | Purpose |
|---|---|---|
| `DB_HOST` / `DB_PORT` | localhost / 1521 | Oracle host/port |
| `DB_NAME` | trafretro | service name |
| `DB_USERNAME` / `DB_PASSWORD` | system / (none) | credentials |
| `JWT_SECRET` | (dev placeholder) | **set a long random value in any real env** |
| `SPA_ORIGIN` | http://localhost:5173 | allowed CORS origin(s) |
| `SERVER_PORT` | 8080 | HTTP port |

> No Oracle handy? Run the **`h2`** profile — it boots with no external dependencies and an
> H2 console at `/h2-console`.

## Built-in data

On first startup, four built-in column templates are seeded: *Start-Stop-Continue*,
*Went Well-Improve-Action Items*, *Mad-Sad-Glad*, *4Ls*.

## Quick smoke test

```bash
# Register
curl -X POST localhost:8080/api/v1/auth/register \
  -H 'Content-Type: application/json' \
  -d '{"email":"alice@example.com","password":"password123","displayName":"Alice"}'

# Login -> returns accessToken + refreshToken
curl -X POST localhost:8080/api/v1/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"alice@example.com","password":"password123"}'

# Use the access token as: Authorization: Bearer <accessToken>
```

## API surface (per HLD)

| Module | Base paths |
|---|---|
| Team & User Mgmt | `/api/v1/auth/*`, `/api/v1/users/me*`, `/api/v1/workspaces/**` |
| Retrospective Board | `/api/v1/boards/**`, `/api/v1/cards/**`, `/api/v1/workspaces/{id}/templates` |
| Voting | `/api/v1/cards/{id}/votes`, `/api/v1/boards/{id}/vote-config`, `/votes/tally`, `/votes/reveal` |
| Action Items | `/api/v1/action-items/**`, `/api/v1/cards/{id}/action-items`, `/api/v1/users/me/action-items` |
| Collaboration / Real-time | `/api/v1/boards/{id}/{invite-link,invite-email,join,timer,phase,summary}`, WS `/ws` + `/topic/board/{id}` |

## Architecture notes

- **Roles are workspace-scoped** (`FACILITATOR` / `MEMBER`). Spring Security guards every
  endpoint with `@PreAuthorize("isAuthenticated()")`; fine-grained role/ownership checks live
  in `AuthorizationService` (service layer), as specified in the HLD.
- **Real-time**: Spring's in-memory simple broker (single instance). The STOMP `CONNECT`
  frame is authenticated via JWT in `StompAuthChannelInterceptor`. All board mutations
  broadcast events (`card.*`, `vote.*`, `reaction.added`, `hand.raised`, `timer.tick`,
  `phase.changed`, …) to `/topic/board/{boardId}`.
- **Soft-delete** (`deleted_at` / archive) on user-visible aggregates; `timer_events` is an
  append-only log used to rehydrate timer state on reconnect.
