-- =====================================================================================
-- TrafRetro — Oracle deployment bootstrap (run ONCE by a DBA / privileged user).
--
-- Flyway creates the TABLES automatically from db/migration/V*.sql, but it first needs
-- a schema (Oracle "user") to connect to with the right privileges. This script creates
-- that account. Run it as SYSTEM (or SYS as sysdba) against the target PDB/service.
--
--   sqlplus system/<pwd>@//<host>:1521/<service_name> @00_create_schema.sql
--
-- Then point the app at it via env vars:
--   DB_USERNAME=trafretro   DB_PASSWORD=<the password below>   DB_NAME=<service_name>
-- =====================================================================================

-- If you are on a multitenant instance, make sure you are in the right PDB first:
--   ALTER SESSION SET CONTAINER = XEPDB1;

-- Drop-and-recreate is convenient for non-prod. Comment this out for production.
-- BEGIN EXECUTE IMMEDIATE 'DROP USER trafretro CASCADE'; EXCEPTION WHEN OTHERS THEN NULL; END;
-- /

CREATE USER trafretro IDENTIFIED BY "Change_Me_123"
    DEFAULT TABLESPACE users
    TEMPORARY TABLESPACE temp
    QUOTA UNLIMITED ON users;

-- Privileges the app (and Flyway) need to create/manage its own objects.
GRANT CREATE SESSION      TO trafretro;
GRANT CREATE TABLE        TO trafretro;
GRANT CREATE SEQUENCE     TO trafretro;   -- identity columns use a backing sequence
GRANT CREATE VIEW         TO trafretro;

-- (No CREATE ANY / DBA privileges — the app only ever touches its own schema.)
